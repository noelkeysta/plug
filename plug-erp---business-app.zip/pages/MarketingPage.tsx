
import React, { useState, useMemo } from 'react';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { MarketingCampaign, MarketingCampaignStatus, UserRole } from '../types';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import AddCampaignModal from '../components/marketing/AddCampaignModal';
import { formatCurrency } from '../utils/formatters';
import { format, formatDistanceToNowStrict } from 'date-fns';
import { PlusCircle, Calendar, DollarSign, Target } from 'lucide-react';

const MarketingPage: React.FC = () => {
    const { data } = useData();
    const { marketingCampaigns = [] } = data || {};
    const { currentUser } = useAuth();
    const { themeClasses, isDarkMode } = useTheme();
    const { currency } = useCurrency();
    const [isAddModalOpen, setAddModalOpen] = useState(false);

    const canManageCampaigns = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.ACCOUNTANT].includes(currentUser.role);
    
    const sortedCampaigns = useMemo(() => {
        return [...marketingCampaigns].sort((a,b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
    }, [marketingCampaigns]);

    const getStatusBadge = (status: MarketingCampaignStatus) => {
        const statusClasses = {
            [MarketingCampaignStatus.PLANNING]: isDarkMode ? 'bg-blue-500/30 text-blue-300' : 'bg-blue-100 text-blue-700',
            [MarketingCampaignStatus.ACTIVE]: isDarkMode ? 'bg-emerald-500/30 text-emerald-300' : 'bg-emerald-100 text-emerald-700',
            [MarketingCampaignStatus.COMPLETED]: isDarkMode ? 'bg-slate-500/30 text-slate-300' : 'bg-slate-200 text-slate-600',
            [MarketingCampaignStatus.CANCELLED]: isDarkMode ? 'bg-red-500/30 text-red-300' : 'bg-red-100 text-red-700',
        };
        return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusClasses[status]}`}>{status}</span>;
    }

    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <div className="flex justify-between items-center flex-wrap gap-4">
                <PageHeader title="Marketing Hub" subtitle="Track and manage campaigns" />
                 {canManageCampaigns && (
                    <button onClick={() => setAddModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                        <PlusCircle size={20} /> Create Campaign
                    </button>
                )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {sortedCampaigns.map(campaign => (
                    <Card key={campaign.id} className="flex flex-col">
                        <div className="flex justify-between items-start">
                             <h3 className="text-xl font-bold mb-2">{campaign.name}</h3>
                             {getStatusBadge(campaign.status)}
                        </div>
                        <p className={`text-sm font-semibold mb-4 ${themeClasses.textGradient}`}>{campaign.type}</p>
                        
                        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{campaign.description}</p>

                        <div className="mt-auto pt-6 space-y-3">
                             <div className="flex items-center gap-2 text-sm">
                                <DollarSign size={16} className={isDarkMode ? 'text-amber-400' : 'text-blue-600'}/>
                                <strong>Budget:</strong> {formatCurrency(campaign.budget, currency)}
                             </div>
                              <div className="flex items-center gap-2 text-sm">
                                <Target size={16} className={isDarkMode ? 'text-amber-400' : 'text-blue-600'}/>
                                <strong>Actual Spend:</strong> {formatCurrency(campaign.actualSpend, currency)}
                             </div>
                             <div className="flex items-center gap-2 text-sm">
                                <Calendar size={16} className={isDarkMode ? 'text-amber-400' : 'text-blue-600'}/>
                                <strong>Timeline:</strong> {format(campaign.startDate, 'dd MMM')} - {format(campaign.endDate, 'dd MMM yyyy')} ({formatDistanceToNowStrict(campaign.endDate, {addSuffix: true})})
                             </div>
                        </div>
                    </Card>
                ))}
            </div>

            <Modal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} title="Create New Campaign">
                <AddCampaignModal onClose={() => setAddModalOpen(false)} />
            </Modal>
        </div>
    );
};

export default MarketingPage;
