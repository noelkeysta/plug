import React, { useState, useEffect, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import Card from '../components/ui/Card';
import { User } from '../types';
import { KeyRound, ShieldAlert } from 'lucide-react';

const LoginPage: React.FC = () => {
  const { currentUser, users, login } = useAuth();
  const { themeClasses, isDarkMode } = useTheme();
  const { settings } = useSettings();
  const navigate = useNavigate();

  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (currentUser) {
      navigate('/');
    }
  }, [currentUser, navigate]);

  const handleFormSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    if (!employeeId || !password) {
        setError('Please enter both Employee ID and Password.');
        return;
    }
    const success = await login(employeeId, password);
    if (!success) {
      setError('Invalid Employee ID or Password.');
    }
    // Successful navigation is handled by the useEffect hook watching currentUser
  };

  const handleCardClick = (user: User) => {
    setEmployeeId(user.employeeId);
    setPassword('password123'); // Temporary password for all users
    setError('');
  };

  const inputClasses = `w-full mt-1 p-3 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="text-center mb-10">
        <h1 className="text-6xl font-bold bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 bg-clip-text text-transparent drop-shadow-lg">
          {settings.companyName}
        </h1>
        <p className={`text-xl mt-2 ${isDarkMode ? 'text-blue-400' : 'text-blue-700'} font-medium`}>
          Enterprise Resource Planning
        </p>
      </div>

      <Card className="max-w-md w-full !p-8 !rounded-2xl">
        <form onSubmit={handleFormSubmit} className="space-y-6">
          <h2 className="text-2xl font-bold text-center">Log In</h2>
          <div>
            <label htmlFor="employeeId" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Employee ID</label>
            <input 
              type="text" 
              id="employeeId" 
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
              className={inputClasses} 
              placeholder="e.g., EMP-001"
              autoFocus
            />
          </div>
          <div>
            <label htmlFor="password" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Password</label>
            <input 
              type="password" 
              id="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={inputClasses}
              placeholder="••••••••"
            />
          </div>
          {error && (
            <div className="flex items-center gap-2 text-red-400 bg-red-500/10 p-3 rounded-lg">
                <ShieldAlert size={20} />
                <span className="text-sm font-semibold">{error}</span>
            </div>
          )}
          <button
            type="submit"
            className={`w-full flex items-center justify-center gap-2 py-3 mt-4 rounded-full font-bold text-lg transition-transform duration-200 hover:scale-105 ${themeClasses.button} disabled:opacity-50`}
            disabled={!employeeId || !password}
          >
            <KeyRound size={20} />
            Log In
          </button>
        </form>
      </Card>
      
      <div className="text-center my-8 w-full max-w-4xl">
        <div className="relative">
            <div className="absolute inset-0 flex items-center">
                <div className={`w-full border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-300'}`}></div>
            </div>
            <div className="relative flex justify-center text-sm">
                <span className={`px-2 ${isDarkMode ? 'bg-slate-900 text-slate-500' : 'bg-slate-100 text-slate-500'}`}>Or Quick Select a Profile</span>
            </div>
        </div>
      </div>
      
      <div className="w-full max-w-4xl">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {users.map(user => (
            <Card
              key={user.id}
              onClick={() => handleCardClick(user)}
              className="text-center p-4 !rounded-xl group cursor-pointer hover:!border-amber-500/50 hover:scale-105 transition-all duration-300"
            >
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold shadow-lg text-2xl group-hover:scale-110 transition-transform duration-300">
                {user.avatar}
              </div>
              <p className="font-bold text-base">{user.name}</p>
              <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {user.role}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LoginPage;