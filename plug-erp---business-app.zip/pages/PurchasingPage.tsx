
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { useAuth } from '../contexts/AuthContext';
import { UserRole, PurchaseOrder, PurchaseOrderStatus, Supplier } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { PlusCircle, Inbox } from 'lucide-react';
import { useSearch } from '../contexts/SearchContext';
import Modal from '../components/ui/Modal';
import Pagination from '../components/ui/Pagination';
import AddPurchaseOrderModal from '../components/purchasing/AddPurchaseOrderModal';
import ConfirmationModal from '../components/ui/ConfirmationModal';
import { useCurrency } from '../contexts/CurrencyContext';
import { useNotifier } from '../contexts/NotificationContext';
import { formatCurrency } from '../utils/formatters';
import { format } from 'date-fns';
import { receivePurchaseOrder } from '../services/mockDataService';


const PurchasingPage: React.FC = () => {
  const { data, refreshData } = useData();
  const purchaseOrders = data?.purchaseOrders || [];
  const suppliers = data?.suppliers || [];
  const { currentUser } = useAuth();
  const { isDarkMode, themeClasses } = useTheme();
  const { searchQuery } = useSearch();
  const { currency } = useCurrency();
  const { notifySuccess, notifyError } = useNotifier();

  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [selectedPoId, setSelectedPoId] = useState<string | null>(null);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const [statusFilter, setStatusFilter] = useState('All');
  const [supplierFilter, setSupplierFilter] = useState('all');

  const canManagePurchasing = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER].includes(currentUser.role);
  
  const supplierMap = useMemo(() => {
    return suppliers.reduce((acc, supplier) => {
        acc[supplier.id] = supplier;
        return acc;
    }, {} as Record<number, Supplier>);
  }, [suppliers]);

  const filteredItems = useMemo(() => {
    let items = purchaseOrders;

    if (searchQuery) {
        items = items.filter(po =>
            po.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
            (supplierMap[po.supplierId]?.name.toLowerCase().includes(searchQuery.toLowerCase()))
        );
    }

    if (statusFilter !== 'All') {
        items = items.filter(po => po.status === statusFilter);
    }
    
    if (supplierFilter !== 'all') {
        items = items.filter(po => po.supplierId === Number(supplierFilter));
    }
    
    return items.sort((a,b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime());
  }, [purchaseOrders, searchQuery, statusFilter, supplierFilter, supplierMap]);

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const currentItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter, supplierFilter]);

  const confirmReceiveOrder = (orderId: string) => {
    setSelectedPoId(orderId);
    setConfirmModalOpen(true);
  }

  const handleReceiveOrder = () => {
      if (!currentUser || !selectedPoId) return;
      const result = receivePurchaseOrder(selectedPoId, currentUser.id);
      if (result) {
          notifySuccess(`Order ${selectedPoId} received and inventory updated.`);
          refreshData();
      } else {
          notifyError('Failed to receive order. It might not be in "Shipped" status.');
      }
      setConfirmModalOpen(false);
      setSelectedPoId(null);
  }

  const getStatusBadge = (status: PurchaseOrderStatus) => {
    const statusClasses = {
        [PurchaseOrderStatus.PENDING]: isDarkMode ? 'bg-yellow-500/30 text-yellow-300' : 'bg-yellow-100 text-yellow-700',
        [PurchaseOrderStatus.SHIPPED]: isDarkMode ? 'bg-blue-500/30 text-blue-300' : 'bg-blue-100 text-blue-700',
        [PurchaseOrderStatus.RECEIVED]: isDarkMode ? 'bg-emerald-500/30 text-emerald-300' : 'bg-emerald-100 text-emerald-700',
        [PurchaseOrderStatus.CANCELLED]: isDarkMode ? 'bg-red-500/30 text-red-300' : 'bg-red-100 text-red-700',
    }
    return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusClasses[status]}`}>{status}</span>;
  }

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-8">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <PageHeader title="Purchasing" />
        {canManagePurchasing && (
          <button onClick={() => setAddModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
            <PlusCircle size={20} />
            Add Purchase Order
          </button>
        )}
      </div>
      
      <Card className="!p-4 flex flex-col md:flex-row gap-4">
          <div className="flex-grow">
              <label htmlFor="status-filter" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Filter by Status</label>
              <select 
                id="status-filter"
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className={`w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`}
              >
                  <option value="All" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>All Statuses</option>
                  {Object.values(PurchaseOrderStatus).map(status => (
                      <option key={status} value={status} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{status}</option>
                  ))}
              </select>
          </div>
          <div className="flex-grow">
              <label htmlFor="supplier-filter" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Filter by Supplier</label>
              <select 
                id="supplier-filter"
                value={supplierFilter}
                onChange={e => setSupplierFilter(e.target.value)}
                className={`w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`}
              >
                  <option value="all" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>All Suppliers</option>
                  {suppliers.map(s => (
                      <option key={s.id} value={s.id} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{s.name}</option>
                  ))}
              </select>
          </div>
      </Card>

      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
              <tr>
                <th className="p-4">PO ID</th>
                <th className="p-4">Supplier</th>
                <th className="p-4">Order Date</th>
                <th className="p-4">Expected Delivery</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Total Cost</th>
                {canManagePurchasing && <th className="p-4 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {currentItems.map((po) => (
                <tr key={po.id} className={`border-b ${isDarkMode ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-200 hover:bg-slate-200/50'}`}>
                  <td className="p-4 font-mono text-sm">{po.id}</td>
                  <td className="p-4 font-semibold">{supplierMap[po.supplierId]?.name || 'Unknown'}</td>
                  <td className="p-4">{format(new Date(po.orderDate), 'dd MMM yyyy')}</td>
                  <td className="p-4">{format(new Date(po.expectedDeliveryDate), 'dd MMM yyyy')}</td>
                  <td className="p-4">{getStatusBadge(po.status)}</td>
                  <td className={`p-4 text-right font-medium ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    {formatCurrency(po.totalCost, currency)}
                  </td>
                  {canManagePurchasing && (
                    <td className="p-4 text-center">
                      {po.status === PurchaseOrderStatus.SHIPPED && (
                        <button 
                          onClick={() => confirmReceiveOrder(po.id)}
                          className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-full font-semibold transition-colors ${isDarkMode ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30' : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'}`}
                        >
                          <Inbox size={14} /> Receive
                        </button>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination 
            currentPage={currentPage}
            totalPages={totalPages > 0 ? totalPages : 1}
            onPageChange={setCurrentPage}
            itemsCount={filteredItems.length}
            itemsPerPage={itemsPerPage}
        />
      </Card>
      
      <Modal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} title="Create Purchase Order" size="xl">
        <AddPurchaseOrderModal 
          onClose={() => setAddModalOpen(false)} 
          user={currentUser}
        />
      </Modal>

      <Modal isOpen={isConfirmModalOpen} onClose={() => setConfirmModalOpen(false)} title="Confirm Order Reception">
        <ConfirmationModal
          onConfirm={handleReceiveOrder}
          onCancel={() => setConfirmModalOpen(false)}
          title={`Receive Order ${selectedPoId}?`}
          message="Are you sure? This action will add all items from this purchase order to your inventory and cannot be undone."
        />
      </Modal>
    </div>
  );
};

export default PurchasingPage;
