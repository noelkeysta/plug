

import React, { useState, useMemo } from 'react';
import { useData } from '../contexts/DataContext';
import { useNotifier } from '../contexts/NotificationContext';
import { useTheme } from '../contexts/ThemeContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { Notification, NotificationType } from '../types';
import { formatDistanceToNow } from 'date-fns';
import { Bell, AlertCircle, CheckCircle, Package } from 'lucide-react';

const NotificationsPage: React.FC = () => {
  const { data } = useData();
  const { markAsRead, markAllAsRead } = useNotifier();
  const { isDarkMode, themeClasses } = useTheme();
  
  const notifications = useMemo(() => 
    [...(data?.notifications || [])].sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()), 
  [data?.notifications]);

  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const filteredNotifications = useMemo(() => {
    if (filter === 'unread') {
      return notifications.filter(n => !n.isRead);
    }
    return notifications;
  }, [notifications, filter]);

  const getNotificationIcon = (type: Notification['type']) => {
    const className = "w-6 h-6 flex-shrink-0";
    switch (type) {
        case NotificationType.LOW_STOCK: return <AlertCircle className={`${className} text-yellow-400`} />;
        case NotificationType.OUT_OF_STOCK: return <AlertCircle className={`${className} text-red-400`} />;
        case NotificationType.PO_SHIPPED: return <Package className={`${className} text-blue-400`} />;
        case NotificationType.PENDING_PO: return <Package className={`${className} text-yellow-500`} />;
        case NotificationType.PO_RECEIVED: return <CheckCircle className={`${className} text-emerald-400`} />;
        case NotificationType.PAYROLL_PROCESSED: return <CheckCircle className={`${className} text-emerald-400`} />;
        default: return <Bell className={className} />;
    }
  };

  const FilterButton: React.FC<{buttonFilter: 'all' | 'unread', label: string}> = ({ buttonFilter, label }) => (
    <button
        onClick={() => setFilter(buttonFilter)}
        className={`px-4 py-2 font-semibold rounded-full transition-all duration-300
            ${filter === buttonFilter
                ? themeClasses.button 
                : isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'
            }`
        }
    >
        {label}
    </button>
  );

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-8">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <PageHeader title="Notifications" subtitle="All system alerts and updates" />
        <button onClick={markAllAsRead} className="text-sm font-semibold text-amber-400 hover:underline">
          Mark all as read
        </button>
      </div>

      <Card className="!p-4 flex items-center justify-center gap-2">
        <FilterButton buttonFilter="all" label="All" />
        <FilterButton buttonFilter="unread" label="Unread" />
      </Card>

      <div className="space-y-4 max-w-4xl mx-auto">
        {filteredNotifications.length > 0 ? (
          filteredNotifications.map(n => (
            <Card
              key={n.id}
              onClick={() => markAsRead(n.id)}
              className={`!p-4 flex items-start gap-4 cursor-pointer transition-all duration-300 ${n.isRead ? 'opacity-60 hover:opacity-100' : 'border-amber-500/30'}`}
            >
              <div className="mt-1">{getNotificationIcon(n.type)}</div>
              <div className="flex-grow">
                <p className={`${!n.isRead ? 'font-bold' : ''}`}>{n.message}</p>
                <p className={`text-xs mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {n.actorName && <span className="font-semibold">{n.actorName}</span>}
                  {n.actorName ? ' • ' : ''}
                  {formatDistanceToNow(n.timestamp, { addSuffix: true })}
                </p>
              </div>
            </Card>
          ))
        ) : (
          <Card className="text-center !py-20">
            <Bell size={48} className="mx-auto text-slate-500 mb-4" />
            <h3 className="text-xl font-bold">All caught up!</h3>
            <p className="text-slate-400">You have no {filter} notifications.</p>
          </Card>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;