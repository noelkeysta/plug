

import React, { useMemo, useState } from 'react';
import { DollarSign, ShoppingCart, Users, TrendingUp, SlidersHorizontal, Archive, Receipt } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { NOW, STARTUP_DATE } from '../services/mockDataService';
import PageHeader from '../components/ui/PageHeader';
import KpiCard from '../components/dashboard/KpiCard';
import LiveTransactions from '../components/dashboard/LiveTransactions';
import TopProducts from '../components/dashboard/TopProducts';
import SalesChart, { SalesData } from '../components/dashboard/SalesChart';
import RoleFocusWidget from '../components/dashboard/RoleFocusWidget';
import AlertsWidget from '../components/dashboard/AlertsWidget';
import { TransactionType, UserRole, Product, InventoryItem } from '../types';
import {
  format,
  endOfDay,
  endOfMonth,
  isWithinInterval,
  eachHourOfInterval,
  eachDayOfInterval,
  eachMonthOfInterval,
  getYear,
  getMonth,
  differenceInDays,
  addDays,
  endOfWeek as endOfWeekFns,
} from 'date-fns';
import sub from 'date-fns/sub';
import set from 'date-fns/set';
import startOfWeek from 'date-fns/startOfWeek';
import { useCurrency } from '../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { useDashboardSettings } from '../contexts/DashboardSettingsContext';
import Modal from '../components/ui/Modal';
import CustomizeDashboardModal from '../components/dashboard/CustomizeDashboardModal';
import Card from '../components/ui/Card';
import { useTheme } from '../contexts/ThemeContext';

type Period = 'Today' | 'This Week' | 'This Month' | 'This Year' | 'All Time';

const getDateRanges = (period: Period) => {
  const now = NOW;

  const startOfDay = (date: Date): Date => {
    return set(date, { hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
  };
  
  const localStartOfWeek = (date: Date): Date => {
    return startOfWeek(date, { weekStartsOn: 1 }); // Monday
  };
  
  const startOfMonth = (date: Date): Date => {
    return startOfDay(set(date, { date: 1 }));
  };
  
  const endOfWeek = (date: Date): Date => {
      return endOfWeekFns(date, { weekStartsOn: 1 }); // Monday
  }

  switch (period) {
    case 'Today':
      return {
        current: { start: startOfDay(now), end: now },
        previous: { start: startOfDay(sub(now, { days: 1 })), end: endOfDay(sub(now, { days: 1 })) },
      };
    case 'This Week':
      return {
        current: { start: localStartOfWeek(now), end: now },
        previous: { start: localStartOfWeek(sub(now, { weeks: 1 })), end: endOfWeek(sub(now, { weeks: 1 })) },
      };
    case 'This Year': {
        const nowYear = getYear(now);
        const nowMonth = getMonth(now); // 0-indexed, June is 5
        
        // Financial year starts in June.
        const financialYearStartYear = nowMonth >= 5 ? nowYear : nowYear - 1;
        const currentFYStart = set(new Date(financialYearStartYear, 5, 1), { hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
        
        const previousFYStart = set(new Date(financialYearStartYear - 1, 5, 1), { hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
        
        // To get the same relative end date in the previous year for comparison
        const daysIntoFY = differenceInDays(now, currentFYStart);
        const previousFYEnd = addDays(previousFYStart, daysIntoFY);

        return {
            current: { start: currentFYStart, end: now },
            // Compare with the same partial period in the previous financial year
            previous: { start: previousFYStart, end: endOfDay(previousFYEnd) },
        };
    }
    case 'All Time':
        return {
            current: { start: STARTUP_DATE, end: now },
            previous: { start: new Date(0), end: new Date(0) }, // No previous period for all time
        }
    case 'This Month':
    default:
      return {
        current: { start: startOfMonth(now), end: now },
        previous: { start: startOfMonth(sub(now, { months: 1 })), end: endOfMonth(sub(now, { months: 1 })) },
      };
  }
};

const formatPointsChange = (change: number): string => {
    if (isNaN(change) || !isFinite(change)) return 'N/A';
    const sign = change >= 0 ? '+' : '';
    return `${sign}${change.toFixed(1)}pp vs. prior period`;
};

const DashboardPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { currency } = useCurrency();
  const { themeClasses, isDarkMode } = useTheme();
  const { data } = useData();
  const { kpiSettings, setKpiOrder } = useDashboardSettings();

  const [isCustomizeModalOpen, setCustomizeModalOpen] = useState(false);
  const [period, setPeriod] = useState<Period>('This Month');

  const productMap = useMemo(() => {
    if (!data?.products) return {};
    return data.products.reduce((acc, p) => ({...acc, [p.id]: p}), {} as Record<string, Product>);
  }, [data?.products]);
  
  const dashboardData = useMemo(() => {
    if (!data || !data.settings) return null;
    const { transactions, products, inventoryItems, settings } = data;
    
    const { current, previous } = getDateRanges(period);

    const calculateMetrics = (range: { start: Date, end: Date }) => {
        if (period === 'All Time' && range.start.getTime() === 0 && range.end.getTime() === 0) {
           return { preTaxRevenue: 0, cogs: 0, totalOrders: 0 };
        }
        
        const filteredTransactions = transactions.filter(t => isWithinInterval(t.timestamp, range));
        
        const preTaxRevenue = filteredTransactions
            .filter(t => t.type === TransactionType.SALE)
            .reduce((sum, t) => {
                const preTaxAmount = t.totalAmount / (1 + settings.taxRate / 100);
                return sum + preTaxAmount;
            }, 0);

        const soldItemSerials = new Set(filteredTransactions.flatMap(t => t.type === 'sale' ? t.items.map(i => i.serialNumber) : []));
        const cogs = inventoryItems
          .filter(item => soldItemSerials.has(item.id))
          .reduce((sum, item) => sum + item.cost, 0);

        const totalOrders = filteredTransactions.filter(t => t.type === 'sale').length;
        
        return { preTaxRevenue, cogs, totalOrders };
    }

    const currentMetrics = calculateMetrics(current);
    const previousMetrics = calculateMetrics(previous);

    const getChange = (currentVal: number, previousVal: number): number => {
        if (previousVal === 0) return currentVal > 0 ? 100 : 0;
        if (period === 'All Time') return 0;
        return ((currentVal - previousVal) / previousVal) * 100;
    };

    const netRevenue = currentMetrics.preTaxRevenue;
    const netRevenueChange = getChange(netRevenue, previousMetrics.preTaxRevenue);
    
    const grossProfit = netRevenue - currentMetrics.cogs;
    const grossProfitMargin = netRevenue > 0 ? (grossProfit / netRevenue) * 100 : 0;

    const previousGrossProfit = previousMetrics.preTaxRevenue - previousMetrics.cogs;
    const previousGrossProfitMargin = previousMetrics.preTaxRevenue > 0 ? (previousGrossProfit / previousMetrics.preTaxRevenue) * 100 : 0;
    const grossProfitMarginChange = grossProfitMargin - previousGrossProfitMargin;

    const totalOrdersChange = getChange(currentMetrics.totalOrders, previousMetrics.totalOrders);
    
    const calculateInventoryValueAt = (date: Date, allInventory: InventoryItem[]) => {
      return allInventory
          .filter(item => {
              const addedAt = new Date(item.addedAt);
              if (addedAt > date) return false;
              if (item.soldAt) {
                  const soldAt = new Date(item.soldAt);
                  if (soldAt <= date) return false;
              }
              return true;
          })
          .reduce((sum, item) => sum + item.cost, 0);
    };

    const inventoryValue = inventoryItems.filter(i => i.status === 'available').reduce((sum, i) => sum + i.cost, 0);
    const previousInventoryValue = period !== 'All Time' ? calculateInventoryValueAt(previous.end, inventoryItems) : 0;
    const inventoryValueChange = getChange(inventoryValue, previousInventoryValue);
    
    const currentAov = currentMetrics.totalOrders > 0 ? currentMetrics.preTaxRevenue / currentMetrics.totalOrders : 0;
    const previousAov = previousMetrics.totalOrders > 0 ? previousMetrics.preTaxRevenue / previousMetrics.totalOrders : 0;
    const aovChange = getChange(currentAov, previousAov);


    const periodTransactions = transactions.filter(t => isWithinInterval(t.timestamp, current));

    const salesByProduct = periodTransactions
      .flatMap(t => t.type === 'sale' ? t.items : [])
      .reduce((acc, item) => {
        acc[item.productId] = (acc[item.productId] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

    const topProductsData = Object.entries(salesByProduct)
      .map(([productId, unitsSold]) => {
        const product = products.find(p => p.id === productId);
        if (!product) return null;
        return { ...product, unitsSold, revenue: unitsSold * product.price, progress: Math.min(100, (unitsSold / 50) * 100) };
      })
      .filter(Boolean)
      .sort((a, b) => (b?.revenue ?? 0) - (a?.revenue ?? 0))
      .slice(0, 5) as (Product & { unitsSold: number; revenue: number; progress: number })[];
      
    let salesChartData: SalesData[] = [];
    let salesChartTitle = '';

    if (period === 'Today') {
        salesChartTitle = 'Revenue Today by Hour';
        const hours = eachHourOfInterval({ start: current.start, end: current.end });
        salesChartData = hours.map(hour => ({ name: format(hour, 'ha'), total: periodTransactions.filter(t => t.timestamp.getHours() === hour.getHours()).reduce((sum, t) => sum + t.totalAmount, 0) }));
    } else if (period === 'This Week') {
        salesChartTitle = 'Revenue This Week by Day';
        const days = eachDayOfInterval({ start: current.start, end: current.end });
        salesChartData = days.map(day => ({ name: format(day, 'E'), total: periodTransactions.filter(t => format(t.timestamp, 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd')).reduce((sum, t) => sum + t.totalAmount, 0) }));
    } else if (period === 'This Month') {
        salesChartTitle = 'Revenue This Month by Day';
        const days = eachDayOfInterval({ start: current.start, end: current.end });
        salesChartData = days.map(day => ({ name: format(day, 'd'), total: periodTransactions.filter(t => format(t.timestamp, 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd')).reduce((sum, t) => sum + t.totalAmount, 0) }));
    } else {
        salesChartTitle = period === 'This Year' ? 'Revenue This Financial Year by Month' : 'Revenue by Month';
        const months = eachMonthOfInterval({ start: current.start, end: current.end });
        salesChartData = months.map(month => ({ name: format(month, 'MMM'), total: periodTransactions.filter(t => format(t.timestamp, 'yyyy-MM') === format(month, 'yyyy-MM')).reduce((sum, t) => sum + t.totalAmount, 0) }));
    }

    return { 
        netRevenue, 
        totalOrders: currentMetrics.totalOrders, 
        inventoryValue,
        topProductsData, 
        salesChartData,
        grossProfitMargin,
        netRevenueChange,
        totalOrdersChange,
        salesChartTitle,
        grossProfitMarginChange,
        inventoryValueChange,
        aov: currentAov,
        aovChange,
    };
  }, [data, period, currency]);
  
  const sortedTransactions = useMemo(() => {
    if (!data) return [];
    return [...data.transactions].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }, [data]);

  const formatChange = (change: number) => {
      if (period === 'All Time') return '—';
      const sign = change >= 0 ? '+' : '';
      return `${sign}${change.toFixed(1)}% vs. prior period`;
  }

  const allKpis = useMemo(() => {
    if (!dashboardData) return [];
    return [
      { id: 'netRevenue', title: 'Net Revenue', value: formatCurrency(dashboardData.netRevenue, currency), change: formatChange(dashboardData.netRevenueChange), positive: dashboardData.netRevenueChange >= 0, icon: DollarSign, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT, UserRole.SALES_MANAGER] },
      { id: 'grossProfitMargin', title: 'Gross Profit Margin', value: `${dashboardData.grossProfitMargin.toFixed(1)}%`, change: period === 'All Time' ? '—' : formatPointsChange(dashboardData.grossProfitMarginChange), positive: dashboardData.grossProfitMarginChange >= 0, icon: TrendingUp, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT] },
      { id: 'totalOrders', title: 'Total Orders', value: dashboardData.totalOrders.toLocaleString(), change: formatChange(dashboardData.totalOrdersChange), positive: dashboardData.totalOrdersChange >= 0, icon: ShoppingCart, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER] },
      { id: 'aov', title: 'Avg. Order Value', value: formatCurrency(dashboardData.aov, currency), change: formatChange(dashboardData.aovChange), positive: dashboardData.aovChange >= 0, icon: Receipt, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT, UserRole.SALES_MANAGER] },
      { id: 'inventoryValue', title: 'Inventory Value', value: formatCurrency(dashboardData.inventoryValue, currency), change: formatChange(dashboardData.inventoryValueChange), positive: dashboardData.inventoryValueChange >= 0, icon: Archive, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER, UserRole.ACCOUNTANT] },
  ]}, [dashboardData, currency, period]);

  const visibleKpis = useMemo(() => {
    if (!currentUser || !allKpis) return [];
    const userKpis = allKpis.filter(kpi => kpi.roles.includes(currentUser.role) && kpiSettings.visibility[kpi.id]);
    const kpiMap = userKpis.reduce((acc, kpi) => ({ ...acc, [kpi.id]: kpi }), {} as Record<string, (typeof allKpis)[0]>);
    return kpiSettings.order.map(id => kpiMap[id]).filter(Boolean) as (typeof allKpis[0])[];
  }, [currentUser, allKpis, kpiSettings]);
  
  if (!data || !dashboardData) {
      return <div>Loading...</div>; // Or a proper loading spinner
  }

  const PeriodButton: React.FC<{buttonPeriod: Period}> = ({ buttonPeriod }) => (
    <button
        onClick={() => setPeriod(buttonPeriod)}
        className={`px-4 py-2 font-semibold rounded-full transition-all duration-300
            ${period === buttonPeriod
                ? themeClasses.button 
                : isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'
            }`
        }
    >
        {buttonPeriod}
    </button>
  );

  return (
    <main className="flex-1 overflow-y-auto p-6 space-y-8">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <PageHeader title="Dashboard" subtitle={`Data for: ${period === 'This Year' ? 'Current Financial Year' : period}`} />
        <button 
          onClick={() => setCustomizeModalOpen(true)}
          className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-colors duration-300 border-2 ${isDarkMode ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'}`}
        >
          <SlidersHorizontal size={20} />
          Customize
        </button>
      </div>

      <Card className="!p-4 flex gap-2 flex-wrap justify-center">
        {(['Today', 'This Week', 'This Month', 'This Year', 'All Time'] as Period[]).map(p => 
            <PeriodButton key={p} buttonPeriod={p} />
        )}
      </Card>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {visibleKpis.map((kpi) => (
          <div key={kpi.id}>
            <KpiCard {...kpi} />
          </div>
        ))}
        {visibleKpis.length === 0 && (
            <Card className="sm:col-span-2 lg:col-span-3 xl:col-span-5 text-center">
                <p className="text-slate-400">No KPIs to display.</p>
                <p className="text-slate-500 text-sm">Click "Customize" to enable dashboard widgets.</p>
            </Card>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SalesChart data={dashboardData.salesChartData} title={dashboardData.salesChartTitle} />
        </div>
        <div className="flex flex-col gap-6">
            <AlertsWidget />
            <LiveTransactions transactions={sortedTransactions} productMap={productMap} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TopProducts topProducts={dashboardData.topProductsData} title={`Top Products ${period}`} />
        <RoleFocusWidget />
      </div>

      <Modal isOpen={isCustomizeModalOpen} onClose={() => setCustomizeModalOpen(false)} title="Customize Dashboard">
          <CustomizeDashboardModal onClose={() => setCustomizeModalOpen(false)} />
      </Modal>
    </main>
  );
};

export default DashboardPage;
