

import React, { useState, useMemo, useEffect } from 'react';
import { updateUserSalary, runPayroll } from '../services/mockDataService';
import { User, UserRole, PayrollRun } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { useNotifier } from '../contexts/NotificationContext';
import { formatCurrency } from '../utils/formatters';
import { Briefcase, Check, Play, TrendingUp, TrendingDown, Users, Calendar, Hash } from 'lucide-react';
import { format } from 'date-fns';

import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';

const PayrollPage: React.FC = () => {
    const { currentUser } = useAuth();
    const { data, refreshData } = useData();
    const { isDarkMode, themeClasses } = useTheme();
    const { currency } = useCurrency();
    const { notifySuccess, notifyError } = useNotifier();

    const allUsers = data?.users || [];
    const budgets = data?.budgets || [];
    const payrollRuns = data?.payrollRuns || [];
    
    const canChangeSalaries = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER].includes(currentUser.role);
    const canRunPayroll = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT].includes(currentUser.role);

    const [salaries, setSalaries] = useState<Record<number, number | string>>({});

    useEffect(() => {
        setSalaries(allUsers.reduce((acc, u) => ({ ...acc, [u.id]: u.salary }), {}));
    }, [allUsers]);

    const totalPayroll = useMemo(() => allUsers.reduce((sum, user) => sum + user.salary, 0), [allUsers]);
    const salaryBudget = useMemo(() => budgets.find(b => b.category === 'Salaries')?.amount || 0, [budgets]);
    const variance = salaryBudget - totalPayroll;

    const hasRunForMonth = useMemo(() => {
        const now = new Date();
        const currentMonth = now.getMonth();
        const currentYear = now.getFullYear();
        return payrollRuns.some(p => new Date(p.date).getMonth() === currentMonth && new Date(p.date).getFullYear() === currentYear);
    }, [payrollRuns]);

    const handleSalaryChange = (userId: number, value: string) => {
        setSalaries(prev => ({ ...prev, [userId]: value }));
    };

    const handleSaveSalary = (userId: number) => {
        if (!currentUser || !canChangeSalaries) return;
        const newSalary = Number(salaries[userId]);
        const userToUpdate = allUsers.find(u => u.id === userId);
        if (!userToUpdate || isNaN(newSalary) || newSalary < 0) {
            notifyError("Invalid salary amount.");
            if(userToUpdate) setSalaries(prev => ({ ...prev, [userId]: userToUpdate.salary }));
            return;
        }
        if (userToUpdate.salary === newSalary) return;
        updateUserSalary(userId, newSalary, currentUser.id);
        refreshData();
        notifySuccess(`Updated salary for ${userToUpdate.name}.`);
    };

    const handleRunPayroll = () => {
        if (!currentUser || !canRunPayroll) return;
        if(hasRunForMonth) {
            notifyError("Payroll has already been processed for this month.");
            return;
        }
        const result = runPayroll(allUsers, currentUser.id);
        if (result) {
            refreshData();
            notifySuccess(`Payroll processed for ${formatCurrency(result.totalAmount, currency)}. Expense logged.`);
        } else {
            notifyError("Payroll could not be processed.");
        }
    };

    const inputClasses = `w-full p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'} read-only:bg-slate-500/20 read-only:cursor-not-allowed`;
    
    if (!data) return <div>Loading...</div>;

    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <PageHeader title="Payroll" subtitle="Manage salaries and process payments" />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <Card className="!p-0 overflow-hidden">
                        <div className="p-6"><h2 className="text-xl font-bold flex items-center gap-2"><Briefcase className={`w-6 h-6 ${themeClasses.textGradient}`} /><span>Employee Salaries</span></h2></div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left">
                                <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
                                    <tr><th className="p-4">User</th><th className="p-4 w-48">Monthly Salary ({currency.symbol})</th>{canChangeSalaries && <th className="p-4 w-20">Action</th>}</tr>
                                </thead>
                                <tbody>
                                    {allUsers.map(user => (
                                        <tr key={user.id} className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                            <td className="p-4"><div className="flex items-center gap-3"><div className="w-10 h-10 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold shadow-lg text-sm">{user.avatar}</div><div><p className="font-semibold">{user.name}</p><p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{user.role}</p></div></div></td>
                                            <td className="p-4"><input type="number" value={salaries[user.id] || ''} onChange={(e) => handleSalaryChange(user.id, e.target.value)} className={inputClasses} readOnly={!canChangeSalaries} /></td>
                                            {canChangeSalaries && (<td className="p-4"><button onClick={() => handleSaveSalary(user.id)} disabled={Number(salaries[user.id]) === user.salary} className="p-2 rounded-full text-emerald-400 hover:bg-emerald-500/20 disabled:text-slate-500 disabled:hover:bg-transparent transition-colors" aria-label="Save Salary"><Check /></button></td>)}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Card>
                     <Card>
                        <h2 className="text-xl font-bold mb-4">Payroll History</h2>
                        <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
                           {payrollRuns.sort((a,b) => b.date.getTime() - a.date.getTime()).map(run => (
                               <div key={run.id} className={`p-4 rounded-xl flex flex-wrap justify-between items-center gap-4 ${isDarkMode ? 'bg-slate-800/50' : 'bg-slate-100'}`}>
                                   <div>
                                       <p className="font-bold text-lg">{formatCurrency(run.totalAmount, currency)}</p>
                                       <div className="flex items-center gap-4 text-xs text-slate-400 mt-1">
                                           <span className="flex items-center gap-1.5"><Calendar size={14} />{format(run.date, 'dd MMM, yyyy')}</span>
                                           <span className="flex items-center gap-1.5"><Users size={14} />{run.employeeCount} Employees</span>
                                           <span className="flex items-center gap-1.5"><Hash size={14} />Run ID: {run.id}</span>
                                       </div>
                                   </div>
                                   <div className={`px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1.5 ${isDarkMode ? 'bg-emerald-500/10 text-emerald-400' : 'bg-emerald-100 text-emerald-600'}`}>
                                       <Check size={16} /> Processed
                                   </div>
                               </div>
                           ))}
                        </div>
                    </Card>
                </div>

                <div className="space-y-6">
                    <Card className="flex flex-col justify-center items-center text-center">
                        <p className={isDarkMode ? 'text-slate-400' : 'text-slate-500'}>Total Monthly Payroll</p>
                        <p className={`text-5xl font-bold my-4 ${themeClasses.textGradient}`}>{formatCurrency(totalPayroll, currency)}</p>
                        <button onClick={handleRunPayroll} disabled={!canRunPayroll || hasRunForMonth} className={`w-full flex items-center justify-center gap-2 py-3 mt-4 rounded-full font-bold text-lg transition-transform duration-200 hover:scale-105 ${themeClasses.button} disabled:opacity-50 disabled:cursor-not-allowed`}>
                            {hasRunForMonth ? <><Check/> Processed</> : <><Play /> Run Payroll</>}
                        </button>
                         {hasRunForMonth && <p className="text-xs text-emerald-400 mt-2">Payroll for {format(new Date(), 'MMMM')} has been run.</p>}
                         {!canRunPayroll && <p className="text-xs text-slate-500 mt-2">You don't have permission to run payroll.</p>}
                    </Card>
                    <Card>
                        <h3 className="text-xl font-bold mb-4">Budget Analysis</h3>
                        <div className="space-y-3">
                            <div className="flex justify-between items-baseline"><span className={isDarkMode ? 'text-slate-400' : 'text-slate-500'}>Budgeted Amount</span><span className="font-semibold text-lg">{formatCurrency(salaryBudget, currency)}</span></div>
                            <div className="flex justify-between items-baseline"><span className={isDarkMode ? 'text-slate-400' : 'text-slate-500'}>Actual Payroll</span><span className="font-semibold text-lg">{formatCurrency(totalPayroll, currency)}</span></div>
                            <div className={`flex justify-between items-center pt-2 border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}><span className="text-slate-400 font-bold">Variance</span><span className={`font-bold text-lg flex items-center gap-1 ${variance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{variance >= 0 ? <TrendingUp size={18}/> : <TrendingDown size={18}/>}{formatCurrency(variance, currency)}</span></div>
                            <p className="text-xs text-slate-500">{variance >= 0 ? 'Under budget' : 'Over budget'}</p>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default PayrollPage;