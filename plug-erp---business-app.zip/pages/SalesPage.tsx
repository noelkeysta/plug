

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { useNotifier } from '../contexts/NotificationContext';
import { useData } from '../contexts/DataContext';
import { addSaleTransaction } from '../services/mockDataService';
import { Product, Customer, UserRole, Transaction, SerializedCartItem } from '../types';
import ProductGrid from '../components/sales/ProductGrid';
import OrderSummary from '../components/sales/OrderSummary';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import CustomerSelectModal from '../components/sales/CustomerSelectModal';
import AddNewCustomerModal from '../components/sales/AddNewCustomerModal';
import LogRepairModal from '../components/repairs/LogRepairModal';
import ManagerSaleConfirmationModal from '../components/sales/ManagerSaleConfirmationModal';
import ConfirmationModal from '../components/ui/ConfirmationModal';
import EditPriceModal from '../components/sales/EditPriceModal';
import Receipt from '../components/sales/Receipt';
import SerialNumberSelectModal from '../components/sales/SerialNumberSelectModal';
import { Wrench } from 'lucide-react';

const usePersistentState = <T,>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
    const [state, setState] = useState<T>(() => {
        try {
            const storedValue = localStorage.getItem(key);
            return storedValue ? JSON.parse(storedValue) : initialValue;
        } catch (error) {
            console.error(`Error reading from localStorage key “${key}”:`, error);
            return initialValue;
        }
    });

    useEffect(() => {
        try {
            localStorage.setItem(key, JSON.stringify(state));
        } catch (error) {
            console.error(`Error writing to localStorage key “${key}”:`, error);
        }
    }, [key, state]);

    return [state, setState];
};


const SalesPage: React.FC = () => {
    const { currentUser } = useAuth();
    const { settings } = useSettings();
    const { notifySuccess, notifyError, notifyInfo } = useNotifier();
    const { data, refreshData } = useData();
    const location = useLocation();
    
    const { products = [], customers = [], inventoryItems = [], repairJobs = [] } = data || {};

    const [cartItems, setCartItems] = usePersistentState<SerializedCartItem[]>('pos_cart_items', []);
    const [selectedCustomerId, setSelectedCustomerId] = usePersistentState<number | null>('pos_customer_id', null);
    const [discount, setDiscount] = usePersistentState<number>('pos_discount', 0);
    
    const productMap = useMemo(() => {
      return products.reduce((acc, p) => ({ ...acc, [p.id]: p }), {} as Record<string, Product>);
    }, [products]);

    const selectedCustomer = useMemo(() => {
        return customers.find(c => c.id === selectedCustomerId) || customers.find(c => c.tier === 'Walk-in') || null
    }, [selectedCustomerId, customers]);

    const [isCustomerModalOpen, setCustomerModalOpen] = useState(false);
    const [isAddNewCustomerModalOpen, setAddNewCustomerModalOpen] = useState(false);
    const [isRepairModalOpen, setRepairModalOpen] = useState(false);
    const [isManagerConfirmModalOpen, setManagerConfirmModalOpen] = useState(false);
    const [isSerialModalOpen, setSerialModalOpen] = useState(false);
    const [isClearCartConfirmOpen, setClearCartConfirmOpen] = useState(false);
    const [isEditPriceModalOpen, setEditPriceModalOpen] = useState(false);
    const [itemToEdit, setItemToEdit] = useState<SerializedCartItem | null>(null);
    
    const [productForSerialSelect, setProductForSerialSelect] = useState<Product | null>(null);
    const [pendingPaymentMethod, setPendingPaymentMethod] = useState<'Cash' | 'Credit' | 'Card' | 'Mobile Money' | null>(null);
    const [lastTransaction, setLastTransaction] = useState<Transaction | null>(null);

    useEffect(() => {
        if (!selectedCustomerId && customers.length > 0) {
            setSelectedCustomerId(customers.find(c => c.tier === 'Walk-in')?.id || null);
        }
    }, [customers, selectedCustomerId, setSelectedCustomerId]);

    const handleClearCart = useCallback(() => {
        setCartItems([]);
        setDiscount(0);
        setSelectedCustomerId(customers.find(c => c.tier === 'Walk-in')?.id || null);
        setClearCartConfirmOpen(false);
    }, [setCartItems, setDiscount, setSelectedCustomerId, customers]);

    useEffect(() => {
        const repairJobId = location.state?.repairJobId;
        if (repairJobId && data) {
            if (cartItems.length > 0) {
                console.warn('Clearing existing cart to bill for repair job.');
                handleClearCart();
            }
            const job = repairJobs.find(j => j.id === repairJobId);
            const repairProduct = products.find(p => p.category === 'Repairs');
            
            if (job && repairProduct) {
                const customer = customers.find(c => c.name.toLowerCase() === job.customerName.toLowerCase()) || customers.find(c => c.tier === 'Walk-in');
                setCartItems([{ productId: repairProduct.id, serialNumber: `REPAIR-${job.id}`, finalPrice: job.quote }]);
                setSelectedCustomerId(customer?.id || null);
                notifyInfo(`Added repair bill for ${job.customerName} to the order.`);
                window.history.replaceState({}, document.title);
            } else {
                notifyError('Could not find repair job or repair service product.');
            }
        }
    }, [location.state, data, cartItems.length, handleClearCart, repairJobs, products, customers, setCartItems, setSelectedCustomerId, notifyInfo, notifyError]);
    

    const handleProductSelect = (product: Product) => {
        setProductForSerialSelect(product);
        setSerialModalOpen(true);
    };
    
    const handleSerialSelect = (product: Product, serialNumber: string) => {
        const isAlreadyInCart = cartItems.some(item => item.serialNumber === serialNumber);
        if (isAlreadyInCart) {
            notifyError("This specific item is already in the cart.");
            return;
        }
        setCartItems(prev => [...prev, { productId: product.id, serialNumber, finalPrice: product.price }]);
        setSerialModalOpen(false);
        setProductForSerialSelect(null);
    }
    
    const handleRemoveItem = (serialNumber: string) => {
        setCartItems(cartItems.filter(item => item.serialNumber !== serialNumber));
    };

    const handleDiscountChange = (newDiscount: number) => {
        if (isNaN(newDiscount) || newDiscount < 0) setDiscount(0);
        else if (newDiscount > 100) setDiscount(100);
        else setDiscount(newDiscount);
    };
    
    const proceedWithSale = (paymentMethod: 'Cash' | 'Credit' | 'Card' | 'Mobile Money', managerId?: number) => {
        if (!currentUser || cartItems.length === 0) return;

        if (paymentMethod === 'Credit' && (!selectedCustomer || selectedCustomer.tier === 'Walk-in')) {
            notifyError('Please select a specific customer to charge to their account.');
            return;
        }
        
        const saleItems = cartItems.map(item => ({
            productId: item.productId,
            serialNumber: item.serialNumber,
            price: item.finalPrice,
            originalPrice: productMap[item.productId].price
        }));

        const newTransaction = addSaleTransaction({
            saleItems,
            cashierId: currentUser.id,
            taxRate: settings.taxRate,
            customerId: selectedCustomer?.id,
            paymentMethod,
            discount,
            managerApprovalId: managerId
        });

        if (newTransaction) {
            setLastTransaction(newTransaction);
            handleClearCart();
            refreshData();
            notifySuccess(`Sale #${newTransaction.id} Completed!`);
        } else {
            notifyError("Sale failed. Check stock or customer credit limit. Inventory has been refreshed.");
            refreshData();
        }
    }
    
    const handleCompleteSale = (paymentMethod: 'Cash' | 'Credit' | 'Card' | 'Mobile Money') => {
        if (!currentUser) return;
        
        const isManagerOrAdmin = [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER].includes(currentUser.role);
        const hasPriceOverride = cartItems.some(item => item.finalPrice < productMap[item.productId].price);
        const requiresAuth = (discount > 15 || hasPriceOverride) && !isManagerOrAdmin;

        if (requiresAuth) {
            setPendingPaymentMethod(paymentMethod);
            setManagerConfirmModalOpen(true);
        } else {
            proceedWithSale(paymentMethod);
        }
    };
    
    const handleManagerConfirmSale = (managerId: number) => {
        if (pendingPaymentMethod) {
            proceedWithSale(pendingPaymentMethod, managerId);
        }
        setManagerConfirmModalOpen(false);
        setPendingPaymentMethod(null);
    }
    
    const handleNewSale = () => {
        setLastTransaction(null);
    }

    const handleAddNewCustomer = (customerData: { name: string; email: string; phone: string; }) => {
        if (!currentUser) return;
        // The mock service has a dedicated `addCustomer` now, but this local one is fine for POS flow
        const newCustomer: Customer = {
            ...customerData,
            id: Math.max(...customers.map(c => c.id)) + 1,
            tier: 'Regular',
            creditLimit: 0,
            creditUsed: 0,
            joinDate: new Date(),
        };
        customers.unshift(newCustomer); // Simulate adding
        refreshData();
        setSelectedCustomerId(newCustomer.id);
        notifySuccess(`Customer "${newCustomer.name}" added and selected.`);
        setAddNewCustomerModalOpen(false);
    };

    const handleEditPrice = (item: SerializedCartItem) => {
        setItemToEdit(item);
        setEditPriceModalOpen(true);
    };

    const handleUpdatePrice = (serialNumber: string, newPrice: number) => {
        setCartItems(currentItems => currentItems.map(item => 
            item.serialNumber === serialNumber ? { ...item, finalPrice: newPrice } : item
        ));
        setEditPriceModalOpen(false);
        setItemToEdit(null);
    };

    return (
        <>
            <main className="flex-1 overflow-hidden p-6 flex flex-col md:flex-row gap-6 h-full">
                <div className="flex-[3] flex flex-col overflow-y-auto h-full">
                     <div className="mb-4">
                        <button 
                            onClick={() => setRepairModalOpen(true)} 
                            className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-semibold text-lg bg-gradient-to-r from-blue-500 to-teal-500 text-white transition-transform duration-300 hover:scale-105"
                        >
                            <Wrench /> Log a Repair Job
                        </button>
                    </div>
                    <ProductGrid products={products} inventoryItems={inventoryItems} onProductSelect={handleProductSelect} />
                </div>
                <div className="flex-[2] flex flex-col h-full">
                    <Card className="flex-grow flex flex-col">
                        <OrderSummary 
                            items={cartItems}
                            taxRate={settings.taxRate}
                            discount={discount}
                            selectedCustomer={selectedCustomer}
                            productMap={productMap}
                            onRemoveItem={handleRemoveItem}
                            onClearCart={() => cartItems.length > 0 && setClearCartConfirmOpen(true)}
                            onCompleteSale={handleCompleteSale}
                            onSelectCustomerClick={() => setCustomerModalOpen(true)}
                            onDiscountChange={handleDiscountChange}
                            onEditPrice={handleEditPrice}
                        />
                    </Card>
                </div>
            </main>

            <Modal isOpen={isCustomerModalOpen} onClose={() => setCustomerModalOpen(false)} title="Select Customer">
                <CustomerSelectModal
                    customers={customers}
                    onClose={() => setCustomerModalOpen(false)}
                    onSelectCustomer={(customer) => {
                        setSelectedCustomerId(customer?.id || null);
                        setCustomerModalOpen(false);
                        notifySuccess(customer ? `${customer.name} selected.` : 'Switched to Walk-in Customer.');
                    }}
                    onAddNewCustomerClick={() => {
                        setCustomerModalOpen(false);
                        setAddNewCustomerModalOpen(true);
                    }}
                />
            </Modal>

            <Modal isOpen={isAddNewCustomerModalOpen} onClose={() => setAddNewCustomerModalOpen(false)} title="Add New Customer">
                <AddNewCustomerModal 
                    onClose={() => setAddNewCustomerModalOpen(false)}
                    onCustomerAdded={handleAddNewCustomer}
                />
            </Modal>

             <Modal isOpen={isRepairModalOpen} onClose={() => setRepairModalOpen(false)} title="Log New Repair Job" size="lg">
                <LogRepairModal
                    user={currentUser}
                    onClose={() => setRepairModalOpen(false)}
                />
            </Modal>
             <Modal isOpen={isSerialModalOpen} onClose={() => setSerialModalOpen(false)} title={`Select Serial for ${productForSerialSelect?.name}`}>
                <SerialNumberSelectModal
                    isOpen={isSerialModalOpen}
                    product={productForSerialSelect}
                    inventoryItems={inventoryItems}
                    cartItems={cartItems}
                    onClose={() => setSerialModalOpen(false)}
                    onSerialSelect={handleSerialSelect}
                />
             </Modal>
            <Modal isOpen={isManagerConfirmModalOpen} onClose={() => setManagerConfirmModalOpen(false)} title="Manager Approval Required" size="md">
                <ManagerSaleConfirmationModal
                    onConfirm={handleManagerConfirmSale}
                    onCancel={() => {
                        setManagerConfirmModalOpen(false);
                        setPendingPaymentMethod(null);
                    }}
                />
            </Modal>
            <Modal isOpen={isClearCartConfirmOpen} onClose={() => setClearCartConfirmOpen(false)} title="Confirm Action">
                <ConfirmationModal
                    onConfirm={handleClearCart}
                    onCancel={() => setClearCartConfirmOpen(false)}
                    title="Clear Current Order?"
                    message="Are you sure you want to remove all items from the current order? This action cannot be undone."
                    confirmText="Yes, Clear Order"
                />
            </Modal>
            {itemToEdit && (
                <Modal isOpen={isEditPriceModalOpen} onClose={() => setEditPriceModalOpen(false)} title="Edit Item Price">
                    <EditPriceModal
                        item={itemToEdit}
                        productMap={productMap}
                        onClose={() => setEditPriceModalOpen(false)}
                        onUpdatePrice={handleUpdatePrice}
                        currentUser={currentUser}
                    />
                </Modal>
            )}
             <Modal isOpen={lastTransaction !== null} onClose={handleNewSale} title="Transaction Receipt" size="sm">
                {lastTransaction && currentUser && (
                    <Receipt
                        transaction={lastTransaction}
                        products={products}
                        customer={customers.find(c => c.id === lastTransaction.customerId) || null}
                        cashier={currentUser}
                        settings={settings}
                        onNewSale={handleNewSale}
                    />
                )}
            </Modal>
        </>
    );
};

export default SalesPage;
