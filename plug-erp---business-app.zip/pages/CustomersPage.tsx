

import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { useAuth } from '../contexts/AuthContext';
import { UserRole, TransactionType, Customer } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { format } from 'date-fns';
import { useSearch } from '../contexts/SearchContext';
import Pagination from '../components/ui/Pagination';
import { useCurrency } from '../contexts/CurrencyContext';
import { formatCurrency } from '../utils/formatters';
import { Download, PlusCircle, ArrowUpDown, Eye } from 'lucide-react';
import AddCustomerModal from '../components/customers/AddCustomerModal';
import CustomerDetailsModal from '../components/customers/CustomerDetailsModal';
import Modal from '../components/ui/Modal';

type CustomerWithSpend = Customer & { totalSpent: number };
type SortableKeys = keyof CustomerWithSpend;

const CustomersPage: React.FC = () => {
  const { data, refreshData } = useData();
  const { customers = [], transactions = [] } = data || {};
  const { currentUser } = useAuth();
  const { isDarkMode, themeClasses } = useTheme();
  const { searchQuery } = useSearch();
  const { currency } = useCurrency();

  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isDetailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerWithSpend | null>(null);

  const canManageCustomers = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.SALES_ASSOCIATE].includes(currentUser.role);
  const canSeeCredit = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT, UserRole.SALES_MANAGER].includes(currentUser.role);
  
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const [tierFilter, setTierFilter] = useState('All');
  const [sortConfig, setSortConfig] = useState<{ key: SortableKeys; direction: 'asc' | 'desc' } | null>({ key: 'joinDate', direction: 'desc' });

  const customerSpendMap = useMemo(() => {
    return transactions
      .filter(t => t.type === TransactionType.SALE && t.customerId)
      .reduce((acc, t) => {
        if (t.customerId) acc[t.customerId] = (acc[t.customerId] || 0) + t.totalAmount;
        return acc;
      }, {} as Record<number, number>);
  }, [transactions]);

  const sortedItems = useMemo(() => {
    let items: CustomerWithSpend[] = customers
      .filter(c => c.tier !== 'Walk-in')
      .map(c => ({ ...c, totalSpent: customerSpendMap[c.id] || 0 }));

    if (searchQuery) {
        items = items.filter(customer =>
            customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
            customer.phone.toLowerCase().includes(searchQuery.toLowerCase()) ||
            `C${customer.id}`.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }
    
    if (tierFilter !== 'All') {
        items = items.filter(customer => customer.tier === tierFilter);
    }

    if (sortConfig !== null) {
      items.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'asc' ? -1 : 1;
        if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return items;
  }, [customers, searchQuery, tierFilter, customerSpendMap, sortConfig]);

  const requestSort = (key: SortableKeys) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };
  
  const SortableHeader: React.FC<{ sortKey: SortableKeys, label: string, className?: string }> = ({ sortKey, label, className }) => (
    <th className={`p-4 ${className || ''}`}>
      <button onClick={() => requestSort(sortKey)} className="flex items-center gap-2 group">
        {label}
        <ArrowUpDown size={14} className="opacity-30 group-hover:opacity-100" />
      </button>
    </th>
  );

  const totalPages = Math.ceil(sortedItems.length / itemsPerPage);
  const currentItems = sortedItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  useEffect(() => {
      setCurrentPage(1);
  }, [searchQuery, tierFilter, sortConfig]);

  const handleExportCsv = () => {
    const headers = ['ID', 'Name', 'Email', 'Phone', 'Tier', 'Join Date', 'Total Spent'];
    const rows = sortedItems.map(c => [ `C${c.id}`, `"${c.name.replace(/"/g, '""')}"`, c.email, c.phone, c.tier, format(new Date(c.joinDate), 'yyyy-MM-dd'), c.totalSpent ].join(','));
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `plug_customers_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  const handleViewDetails = (customer: CustomerWithSpend) => {
    setSelectedCustomer(customer);
    setDetailsModalOpen(true);
  }

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-8">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <PageHeader title="Customers" />
        <div className="flex items-center gap-2">
            {canManageCustomers && (
                <button onClick={() => setAddModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 border-2 ${isDarkMode ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'}`}>
                    <PlusCircle size={20} /> Add Customer
                </button>
            )}
            <button onClick={handleExportCsv} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                <Download size={20} /> Export CSV
            </button>
        </div>
      </div>

      <Card className="!p-4 flex flex-col md:flex-row flex-wrap gap-4">
          <div className="flex-grow min-w-[200px]">
              <label htmlFor="tier-filter" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Customer Tier</label>
              <select 
                id="tier-filter"
                value={tierFilter}
                onChange={e => setTierFilter(e.target.value)}
                className={`w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`}
              >
                  <option value="All" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>All Tiers</option>
                  <option value="VIP" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>VIP</option>
                  <option value="Regular" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>Regular</option>
              </select>
          </div>
      </Card>
      
      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
              <tr>
                <SortableHeader sortKey="name" label="Customer" />
                <th className="p-4">Contact</th>
                <SortableHeader sortKey="tier" label="Tier" />
                <SortableHeader sortKey="joinDate" label="Join Date" />
                <SortableHeader sortKey="totalSpent" label="Total Spent" className="text-right" />
                {canSeeCredit && <th className="p-4 text-center">Credit Usage</th>}
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((customer) => {
                const creditUsage = customer.creditLimit > 0 ? (customer.creditUsed / customer.creditLimit) * 100 : 0;
                let usageColor = 'bg-emerald-500';
                if (creditUsage > 75) usageColor = 'bg-red-500';
                else if (creditUsage > 50) usageColor = 'bg-yellow-500';

                return (
                <tr key={customer.id} className={`border-b ${isDarkMode ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-200 hover:bg-slate-200/50'}`}>
                  <td className="p-4">
                    <p className="font-semibold">{customer.name}</p>
                    <p className="font-mono text-xs text-slate-500">ID: C{customer.id}</p>
                  </td>
                  <td className="p-4 text-sm">
                    <p>{customer.email}</p>
                    <p className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>{customer.phone}</p>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${ customer.tier === 'VIP' ? (isDarkMode ? 'bg-amber-500/30 text-amber-300' : 'bg-amber-100 text-amber-700') : (isDarkMode ? 'bg-blue-500/30 text-blue-300' : 'bg-blue-100 text-blue-700') }`}>
                      {customer.tier}
                    </span>
                  </td>
                  <td className="p-4">{format(new Date(customer.joinDate), 'dd MMM yyyy')}</td>
                  <td className="p-4 text-right font-medium">{formatCurrency(customer.totalSpent, currency)}</td>
                  {canSeeCredit && (
                    <td className="p-4">
                      {customer.creditLimit > 0 ? (
                        <div className="flex items-center gap-2">
                           <div className={`w-full ${themeClasses.progressBg} rounded-full h-2.5 overflow-hidden`}>
                              <div className={`${usageColor} h-2.5 rounded-full`} style={{ width: `${creditUsage}%` }} />
                            </div>
                          <span className="text-xs font-mono w-16 text-right">{creditUsage.toFixed(0)}%</span>
                        </div>
                      ) : ( <span className="text-slate-500 text-sm flex justify-center">N/A</span> )}
                    </td>
                  )}
                  <td className="p-4 text-center">
                    <button onClick={() => handleViewDetails(customer)} className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`} aria-label="View Details"><Eye size={16} /></button>
                  </td>
                </tr>
                );
            })}
            </tbody>
          </table>
        </div>
        <Pagination currentPage={currentPage} totalPages={totalPages > 0 ? totalPages : 1} onPageChange={setCurrentPage} itemsCount={sortedItems.length} itemsPerPage={itemsPerPage} />
      </Card>
      
      <Modal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} title="Add New Customer">
        <AddCustomerModal user={currentUser} onClose={() => { setAddModalOpen(false); refreshData(); }} />
      </Modal>

      {selectedCustomer && (
        <Modal isOpen={isDetailsModalOpen} onClose={() => setDetailsModalOpen(false)} title={`Details for ${selectedCustomer.name}`} size="xl">
          <CustomerDetailsModal customer={selectedCustomer} transactions={transactions} products={data?.products || []} />
        </Modal>
      )}
    </div>
  );
};

export default CustomersPage;
