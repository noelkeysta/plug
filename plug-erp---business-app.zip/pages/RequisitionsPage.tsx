
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { useNotifier } from '../contexts/NotificationContext';
import { Requisition, RequisitionStatus, User, UserRole } from '../types';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import Pagination from '../components/ui/Pagination';
import CreateRequisitionModal from '../components/requisitions/CreateRequisitionModal';
import ApproveRequisitionModal from '../components/requisitions/ApproveRequisitionModal';
import { updateRequisitionStatus } from '../services/mockDataService';
import { formatCurrency } from '../utils/formatters';
import { format } from 'date-fns';
import { PlusCircle, Check, X } from 'lucide-react';

const RequisitionsPage: React.FC = () => {
    const { data, refreshData } = useData();
    const { requisitions = [], users = [] } = data || {};
    const { currentUser } = useAuth();
    const { isDarkMode } = useTheme();
    const { currency } = useCurrency();
    const { notifySuccess, notifyError } = useNotifier();

    const [isCreateModalOpen, setCreateModalOpen] = useState(false);
    const [isApproveModalOpen, setApproveModalOpen] = useState(false);
    const [selectedRequisition, setSelectedRequisition] = useState<Requisition | null>(null);

    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    const [statusFilter, setStatusFilter] = useState('All');
    
    const userMap = useMemo(() => users.reduce((acc, user) => ({ ...acc, [user.id]: user }), {} as Record<number, User>), [users]);
    const isManager = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER].includes(currentUser.role);
    
    const filteredItems = useMemo(() => {
        let items = requisitions;
        if (statusFilter !== 'All') {
            items = items.filter(r => r.status === statusFilter);
        }
        if (!isManager) {
            items = items.filter(r => r.requesterId === currentUser?.id);
        }
        return items.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }, [requisitions, statusFilter, isManager, currentUser]);

    const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
    const currentItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    useEffect(() => {
        setCurrentPage(1);
    }, [statusFilter]);
    
    const openApproveModal = (req: Requisition) => {
        setSelectedRequisition(req);
        setApproveModalOpen(true);
    };

    const handleApprove = (rejectionReason?: string) => {
        if (!currentUser || !selectedRequisition) return;
        const newStatus = rejectionReason ? RequisitionStatus.REJECTED : RequisitionStatus.APPROVED;
        const result = updateRequisitionStatus(selectedRequisition.id, newStatus, currentUser.id, rejectionReason);
        if (result) {
            notifySuccess(`Requisition #${selectedRequisition.id} has been ${newStatus.toLowerCase()}.`);
            refreshData();
        } else {
            notifyError('Failed to update requisition status.');
        }
        setApproveModalOpen(false);
        setSelectedRequisition(null);
    };

    const getStatusBadge = (status: RequisitionStatus) => {
        const statusClasses: Record<RequisitionStatus, string> = {
            [RequisitionStatus.PENDING]: isDarkMode ? 'bg-yellow-500/30 text-yellow-300' : 'bg-yellow-100 text-yellow-700',
            [RequisitionStatus.APPROVED]: isDarkMode ? 'bg-sky-500/30 text-sky-300' : 'bg-sky-100 text-sky-700',
            [RequisitionStatus.ORDERED]: isDarkMode ? 'bg-blue-500/30 text-blue-300' : 'bg-blue-100 text-blue-700',
            [RequisitionStatus.COMPLETED]: isDarkMode ? 'bg-emerald-500/30 text-emerald-300' : 'bg-emerald-100 text-emerald-700',
            [RequisitionStatus.REJECTED]: isDarkMode ? 'bg-red-500/30 text-red-300' : 'bg-red-100 text-red-700',
        };
        return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusClasses[status]}`}>{status}</span>;
    }
    
    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <div className="flex justify-between items-center flex-wrap gap-4">
                <PageHeader title="Requisitions" subtitle="Manage all purchase requests" />
                <button onClick={() => setCreateModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 bg-gradient-to-r from-amber-500 to-blue-500 text-white`}>
                    <PlusCircle size={20} /> Create Request
                </button>
            </div>

            <Card className="!p-4 flex items-center gap-4">
                <label htmlFor="status-filter" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Status</label>
                <select id="status-filter" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
                    className={`p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`}>
                    <option value="All">All</option>
                    {Object.values(RequisitionStatus).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
            </Card>

            <Card className="!p-0 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
                            <tr>
                                <th className="p-4">Req. ID</th>
                                <th className="p-4">Date</th>
                                <th className="p-4">Requester</th>
                                <th className="p-4">Description</th>
                                <th className="p-4">Type</th>
                                <th className="p-4">Status</th>
                                <th className="p-4 text-right">Amount</th>
                                {isManager && <th className="p-4 text-center">Actions</th>}
                            </tr>
                        </thead>
                        <tbody>
                            {currentItems.map(req => (
                                <tr key={req.id} className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                    <td className="p-4 font-mono text-sm">#{req.id}</td>
                                    <td className="p-4 whitespace-nowrap">{format(new Date(req.createdAt), 'dd MMM yyyy')}</td>
                                    <td className="p-4 font-semibold">{userMap[req.requesterId]?.name || 'Unknown'}</td>
                                    <td className="p-4 max-w-xs truncate">{req.description}</td>
                                    <td className="p-4">{req.type}</td>
                                    <td className="p-4">{getStatusBadge(req.status)}</td>
                                    <td className="p-4 text-right font-medium">{formatCurrency(req.totalEstimatedCost, currency)}</td>
                                    {isManager && (
                                        <td className="p-4 text-center">
                                            {req.status === RequisitionStatus.PENDING && (
                                                <div className="flex gap-2 justify-center">
                                                    <button onClick={() => openApproveModal(req)} className="p-2 rounded-full bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"><Check size={16}/></button>
                                                    <button onClick={() => openApproveModal(req)} className="p-2 rounded-full bg-red-500/20 text-red-400 hover:bg-red-500/30"><X size={16}/></button>
                                                </div>
                                            )}
                                        </td>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <Pagination currentPage={currentPage} totalPages={totalPages > 0 ? totalPages : 1} onPageChange={setCurrentPage} itemsCount={filteredItems.length} itemsPerPage={itemsPerPage} />
            </Card>

            <Modal isOpen={isCreateModalOpen} onClose={() => setCreateModalOpen(false)} title="Create Requisition" size="lg">
                <CreateRequisitionModal onClose={() => setCreateModalOpen(false)} />
            </Modal>
            
            <Modal isOpen={isApproveModalOpen} onClose={() => setApproveModalOpen(false)} title="Approve/Reject Requisition" size="md">
                {selectedRequisition && <ApproveRequisitionModal requisition={selectedRequisition} onConfirm={handleApprove} onCancel={() => setApproveModalOpen(false)} />}
            </Modal>
        </div>
    );
};

export default RequisitionsPage;
