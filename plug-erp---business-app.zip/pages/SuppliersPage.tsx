
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { useAuth } from '../contexts/AuthContext';
import { UserRole, Supplier } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { PlusCircle } from 'lucide-react';
import { useSearch } from '../contexts/SearchContext';
import Modal from '../components/ui/Modal';
import Pagination from '../components/ui/Pagination';
import AddSupplierModal from '../components/suppliers/AddSupplierModal';

const SuppliersPage: React.FC = () => {
  const { data } = useData();
  const suppliers = data?.suppliers || [];
  const { currentUser } = useAuth();
  const { isDarkMode, themeClasses } = useTheme();
  const { searchQuery } = useSearch();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const canManageSuppliers = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER].includes(currentUser.role);

  const filteredItems = useMemo(() => {
    if (!searchQuery) return suppliers;

    return suppliers.filter(supplier =>
        supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        supplier.contact.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [suppliers, searchQuery]);

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const currentItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-8">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <PageHeader title="Suppliers" />
        {canManageSuppliers && (
          <button onClick={() => setIsModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
            <PlusCircle size={20} />
            Add Supplier
          </button>
        )}
      </div>

      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
              <tr>
                <th className="p-4">Supplier ID</th>
                <th className="p-4">Name</th>
                <th className="p-4">Contact</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((supplier) => (
                <tr key={supplier.id} className={`border-b ${isDarkMode ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-200 hover:bg-slate-200/50'}`}>
                  <td className="p-4 font-mono text-sm">S{supplier.id}</td>
                  <td className="p-4 font-semibold">{supplier.name}</td>
                  <td className={`${isDarkMode ? 'text-slate-400' : 'text-slate-600'} p-4`}>{supplier.contact}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination 
            currentPage={currentPage}
            totalPages={totalPages > 0 ? totalPages : 1}
            onPageChange={setCurrentPage}
            itemsCount={filteredItems.length}
            itemsPerPage={itemsPerPage}
        />
      </Card>
      
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Add New Supplier">
        <AddSupplierModal 
          onClose={() => setIsModalOpen(false)} 
          user={currentUser}
        />
      </Modal>
    </div>
  );
};

export default SuppliersPage;
