
import React, { useState } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { SlidersHorizontal, Shield } from 'lucide-react';
import PreferencesTab from '../components/settings/PreferencesTab';
import SecurityTab from '../components/settings/SecurityTab';

type SettingsTab = 'preferences' | 'security';

const SettingsPage: React.FC = () => {
    const { isDarkMode, themeClasses } = useTheme();
    const [activeTab, setActiveTab] = useState<SettingsTab>('preferences');

    const TabButton: React.FC<{ tabId: SettingsTab; label: string; icon: React.FC<any> }> = ({ tabId, label, icon: Icon }) => (
        <button
            onClick={() => setActiveTab(tabId)}
            className={`flex-1 flex items-center justify-center gap-3 p-4 font-bold rounded-t-2xl transition-all duration-300 border-b-4
                ${activeTab === tabId
                    ? `${isDarkMode ? 'bg-slate-800/50 border-amber-400' : 'bg-slate-100 border-blue-500'}`
                    : `border-transparent ${isDarkMode ? 'hover:bg-slate-800/20' : 'hover:bg-slate-200/50'}`
                }`
            }
        >
            <Icon className={`w-6 h-6 ${activeTab === tabId ? (isDarkMode ? 'text-amber-400' : 'text-blue-600') : 'text-slate-400'}`} />
            <span>{label}</span>
        </button>
    );

    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <PageHeader title="My Settings" subtitle="Manage your preferences and account security" />

            <div className="max-w-4xl mx-auto">
                <div className="flex">
                    <TabButton tabId="preferences" label="Preferences" icon={SlidersHorizontal} />
                    <TabButton tabId="security" label="Security" icon={Shield} />
                </div>
                <Card className="!rounded-t-none">
                    {activeTab === 'preferences' && <PreferencesTab />}
                    {activeTab === 'security' && <SecurityTab />}
                </Card>
            </div>
        </div>
    );
};

export default SettingsPage;
