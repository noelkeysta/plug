

import React, { useState, useMemo } from 'react';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { NOW } from '../services/mockDataService';
import { UserRole, Supplier } from '../types';

import PageHeader from '../components/ui/PageHeader';
import ReportCard from '../components/reports/ReportCard';
import SalesSummaryReport from '../components/reports/SalesSummaryReport';
import InventoryValuationReport from '../components/reports/InventoryValuationReport';
import ExpenseBreakdownReport from '../components/reports/ExpenseBreakdownReport';
import IncomeStatement from '../components/reports/IncomeStatement';
import BalanceSheet from '../components/reports/BalanceSheet';
import CashFlowStatement from '../components/reports/CashFlowStatement';

import { FileText, Archive, TrendingDown, ArrowLeft, Printer, Activity, Scaling, Wallet } from 'lucide-react';
import { format, endOfMonth } from 'date-fns';
import set from 'date-fns/set';

type ReportType = 'sales' | 'inventory' | 'expenses' | 'income' | 'balance-sheet' | 'cash-flow';
type DatePreset = 'month' | 'all';

const reportOptions = [
    { id: 'sales', title: 'Sales Summary', description: 'Detailed report on sales performance within a specific period.', icon: FileText, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.ACCOUNTANT] },
    { id: 'income', title: 'Income Statement', description: 'Profit & Loss statement showing revenues, costs, and profitability.', icon: Activity, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT] },
    { id: 'balance-sheet', title: 'Balance Sheet', description: 'A snapshot of the company\'s assets, liabilities, and equity.', icon: Scaling, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT] },
    { id: 'cash-flow', title: 'Cash Flow Statement', description: 'Analysis of cash movements from operating, investing, and financing activities.', icon: Wallet, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT] },
    { id: 'inventory', title: 'Inventory Valuation', description: 'Complete snapshot of your inventory\'s financial value based on cost.', icon: Archive, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER, UserRole.ACCOUNTANT] },
    { id: 'expenses', title: 'Expense Breakdown', description: 'Aggregated expenses grouped by category to see where money is going.', icon: TrendingDown, roles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT] },
];

const startOfMonth = (date: Date) => {
    return set(date, { date: 1, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
}
const businessStartDate = '2024-06-01';

const ReportsPage: React.FC = () => {
    const { isDarkMode, themeClasses } = useTheme();
    const { data } = useData();
    const { transactions, products, expenses, users, inventoryItems, accounts, ledger, suppliers } = data || { transactions: [], products: [], expenses: [], users: [], inventoryItems: [], accounts: [], ledger: [], suppliers: [] };
    const { currentUser } = useAuth();
    
    const [activeReport, setActiveReport] = useState<ReportType | null>(null);
    const [dateRange, setDateRange] = useState({
        start: format(startOfMonth(NOW), 'yyyy-MM-dd'),
        end: format(endOfMonth(NOW), 'yyyy-MM-dd'),
    });
    const [datePreset, setDatePreset] = useState<DatePreset>('month');
    const [balanceSheetDate, setBalanceSheetDate] = useState(format(NOW, 'yyyy-MM-dd'));
    const [salesFilters, setSalesFilters] = useState({ cashierId: 'all', categoryId: 'all' });
    const [inventoryFilters, setInventoryFilters] = useState({ supplierId: 'all' });
    
    const cashierOptions = useMemo(() => users.filter(u => [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.SALES_ASSOCIATE].includes(u.role)), [users]);
    const categoryOptions = useMemo(() => ['All', ...new Set(products.map(p => p.category))], [products]);

    const visibleReportOptions = useMemo(() => {
        if (!currentUser) return [];
        return reportOptions.filter(report => report.roles.includes(currentUser.role));
    }, [currentUser]);

    const financialReports = useMemo(() => visibleReportOptions.filter(r => ['income', 'balance-sheet', 'cash-flow'].includes(r.id)), [visibleReportOptions]);
    const operationalReports = useMemo(() => visibleReportOptions.filter(r => ['sales', 'inventory', 'expenses'].includes(r.id)), [visibleReportOptions]);

    const handlePrint = () => window.print();
    
    const handleSetDatePreset = (preset: DatePreset) => {
        setDatePreset(preset);
        if (preset === 'month') {
             setDateRange({
                start: format(startOfMonth(NOW), 'yyyy-MM-dd'),
                end: format(endOfMonth(NOW), 'yyyy-MM-dd'),
            });
        } else {
             setDateRange({
                start: businessStartDate,
                end: format(NOW, 'yyyy-MM-dd'),
            });
        }
    }

    const inputClasses = `p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`;
    const activeReportDetails = reportOptions.find(r => r.id === activeReport);

    const DatePresetButton: React.FC<{preset: DatePreset, label: string}> = ({ preset, label }) => (
        <button
            onClick={() => handleSetDatePreset(preset)}
            className={`px-3 py-1.5 text-sm font-semibold rounded-full transition-all duration-300
                ${datePreset === preset
                    ? themeClasses.button 
                    : isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'
                }`
            }
        >
            {label}
        </button>
    );

    const renderReportContent = () => {
        const start = new Date(dateRange.start);
        const end = new Date(dateRange.end);
        end.setHours(23, 59, 59, 999);

        switch (activeReport) {
            case 'sales': return <SalesSummaryReport transactions={transactions} products={products} dateRange={{ start, end }} filters={salesFilters} />;
            case 'inventory': return <InventoryValuationReport products={products} inventoryItems={inventoryItems} filters={inventoryFilters} />;
            case 'expenses': return <ExpenseBreakdownReport expenses={expenses} dateRange={{ start, end }} />;
            case 'income': return <IncomeStatement ledger={ledger} accounts={accounts} dateRange={{ start, end }} />;
            case 'balance-sheet': return <BalanceSheet accounts={accounts} ledger={ledger} asOfDate={new Date(balanceSheetDate)} />;
            case 'cash-flow': return <CashFlowStatement ledger={ledger} accounts={accounts} dateRange={{ start, end }} />;
            default: return null;
        }
    };
    
    if (!data) return <div>Loading...</div>;

    if (activeReport) {
        return (
            <div className="flex-1 overflow-y-auto p-6 space-y-8">
                 <div id="report-print-area">
                    <div className="flex justify-between items-center flex-wrap gap-4 mb-4 print-hide">
                        <div className="flex items-center gap-4">
                            <button onClick={() => setActiveReport(null)} className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`}><ArrowLeft /></button>
                            <PageHeader title={activeReportDetails?.title || 'Report'} />
                        </div>
                        <div className="flex items-center gap-4 flex-wrap">
                             {['income', 'cash-flow'].includes(activeReport) && (
                                <div className="flex items-center gap-2 p-1 rounded-full bg-slate-500/10">
                                    <DatePresetButton preset="month" label="Current Month" />
                                    <DatePresetButton preset="all" label="Entire Period" />
                                </div>
                            )}
                            {['sales', 'income', 'expenses', 'cash-flow'].includes(activeReport) && (
                                <div className="flex items-center gap-2 flex-wrap">
                                     <input type="date" value={dateRange.start} onChange={e => {setDateRange(p => ({...p, start: e.target.value})); setDatePreset('month');}} className={inputClasses} />
                                     <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>to</span>
                                     <input type="date" value={dateRange.end} onChange={e => {setDateRange(p => ({...p, end: e.target.value})); setDatePreset('month');}} className={inputClasses} />
                                </div>
                            )}
                            {activeReport === 'balance-sheet' && (
                                <div className="flex items-center gap-2 flex-wrap">
                                    <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>As of:</span>
                                    <input type="date" value={balanceSheetDate} onChange={e => setBalanceSheetDate(e.target.value)} className={inputClasses} />
                                </div>
                            )}
                             {activeReport === 'inventory' && (
                                <div className="flex items-center gap-2 flex-wrap">
                                    <label htmlFor="inventory-supplier-filter" className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Supplier:</label>
                                    <select
                                        id="inventory-supplier-filter"
                                        value={inventoryFilters.supplierId}
                                        onChange={e => setInventoryFilters({ supplierId: e.target.value })}
                                        className={inputClasses}
                                    >
                                        <option value="all">All Suppliers</option>
                                        {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                    </select>
                                </div>
                            )}
                            {activeReport === 'sales' && (
                                <div className="flex items-center gap-2 flex-wrap">
                                     <select value={salesFilters.cashierId} onChange={e => setSalesFilters(p => ({ ...p, cashierId: e.target.value }))} className={inputClasses}>
                                        <option value="all">All Cashiers</option>
                                        {cashierOptions.map(user => <option key={user.id} value={user.id}>{user.name}</option>)}
                                     </select>
                                     <select value={salesFilters.categoryId} onChange={e => setSalesFilters(p => ({ ...p, categoryId: e.target.value }))} className={inputClasses}>
                                        {categoryOptions.map(cat => <option key={cat} value={cat === 'All' ? 'all' : cat}>{cat}</option>)}
                                     </select>
                                </div>
                            )}
                            <button onClick={handlePrint} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                                <Printer size={20} /> Print Report
                            </button>
                        </div>
                    </div>
                    {renderReportContent()}
                </div>
                 <style>{`@media print { body > #root > div, body > #root aside { display: none; } main { padding: 0 !important; margin: 0 !important; overflow: visible !important; height: auto !important; } #report-print-area { color: #000; } .print-hide { display: none; } .card-print { border: 1px solid #ddd !important; box-shadow: none !important; border-radius: 0 !important; background: #fff !important; } .text-gradient-print { background: none !important; -webkit-background-clip: unset !important; background-clip: unset !important; color: #000 !important; } #report-print-area, #report-print-area h1, #report-print-area h3, #report-print-area p, #report-print-area span, #report-print-area th, #report-print-area td { color: #000 !important; } #report-print-area .bg-slate-700 { background-color: #eee !important; } #report-print-area .bg-gradient-to-r { background-image: none !important; background-color: #ccc !important; } }`}</style>
            </div>
        )
    }

    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <PageHeader title="Reports" subtitle="Generate insights from your data" />
            
            {financialReports.length > 0 && (
                <div className="space-y-4">
                    <h2 className={`text-2xl font-bold ${themeClasses.textGradient}`}>Financial Statements</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {financialReports.map(report => (
                            <ReportCard key={report.id} {...report} onClick={() => setActiveReport(report.id as ReportType)} />
                        ))}
                    </div>
                </div>
            )}

            {operationalReports.length > 0 && (
                <div className="space-y-4 mt-8">
                    <h2 className={`text-2xl font-bold ${themeClasses.textGradient}`}>Operational Reports</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {operationalReports.map(report => (
                            <ReportCard key={report.id} {...report} onClick={() => setActiveReport(report.id as ReportType)} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default ReportsPage;
