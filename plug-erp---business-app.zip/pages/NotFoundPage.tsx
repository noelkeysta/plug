
import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import Card from '../components/ui/Card';

interface NotFoundPageProps {
  title?: string;
}

const NotFoundPage: React.FC<NotFoundPageProps> = ({ title }) => {
  const { themeClasses, isDarkMode } = useTheme();

  return (
    <main className="flex-1 overflow-y-auto p-6 flex items-center justify-center">
      <Card className="text-center max-w-lg">
        <div className="mx-auto w-fit p-4 rounded-full bg-amber-500/20 mb-6">
          <AlertTriangle className="w-12 h-12 text-amber-400" />
        </div>
        <h1 className={`text-3xl font-bold ${themeClasses.textGradient}`}>
          {title ? 'Page Not Implemented' : 'Page Not Found'}
        </h1>
        <p className={`${isDarkMode ? 'text-slate-400' : 'text-slate-600'} mt-2 mb-6`}>
          {title 
            ? `The "${title}" page is currently under construction.`
            : "Oops! The page you're looking for doesn't exist."
          }
        </p>
        <Link 
          to="/"
          className={`inline-block px-6 py-3 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Go to Dashboard
        </Link>
      </Card>
    </main>
  );
};

export default NotFoundPage;
