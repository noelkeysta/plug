

import React, { useState, useMemo, useEffect } from 'react';
import { updateUserRole } from '../services/mockDataService';
import { User, UserRole, AuditLog, AppSettings, Currency } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import { useSettings } from '../contexts/SettingsContext';
import { useNotifier } from '../contexts/NotificationContext';
import { CURRENCIES } from '../constants';

import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { UserCog, History, Building, Percent } from 'lucide-react';
import Pagination from '../components/ui/Pagination';
import { format } from 'date-fns';

const SystemsPage: React.FC = () => {
    const { currentUser, refreshUsers } = useAuth();
    const { isDarkMode, themeClasses } = useTheme();
    const { data, refreshData } = useData();
    const { settings, updateSettings } = useSettings();
    const { notifySuccess, notifyError } = useNotifier();
    
    const [activeTab, setActiveTab] = useState('users');
    const [auditLogPage, setAuditLogPage] = useState(1);
    const auditItemsPerPage = 15;
    
    const users = data?.users || [];
    const auditLogs = data?.auditLogs || [];

    const [localSettings, setLocalSettings] = useState<AppSettings>(settings);

    useEffect(() => {
        setLocalSettings(settings);
    }, [settings]);

    const sortedAuditLogs = useMemo(() => {
        return [...auditLogs].sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    }, [auditLogs]);

    const totalAuditPages = Math.ceil(sortedAuditLogs.length / auditItemsPerPage);
    const currentAuditItems = sortedAuditLogs.slice((auditLogPage - 1) * auditItemsPerPage, auditLogPage * auditItemsPerPage);


    const handleRoleChange = (userId: number, newRole: UserRole) => {
        if(!currentUser) return;
        if(currentUser?.id === userId) {
            notifyError("For security reasons, you cannot change your own role.");
            return;
        }
        const userToUpdate = users.find(u => u.id === userId);
        if (userToUpdate && userToUpdate.role === UserRole.ADMINISTRATOR) {
            notifyError("The Administrator role cannot be changed.");
            return;
        }
        if (userToUpdate) {
            updateUserRole(userId, newRole, currentUser.id);
            refreshUsers(); // This now calls refreshData() via AuthContext
            notifySuccess(`Updated ${userToUpdate.name}'s role to ${newRole}.`);
        }
    };

    const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setLocalSettings(prev => ({
            ...prev,
            [name]: (name === 'taxRate' || name === 'incomeTaxRate' || name === 'markupPercentage') ? parseFloat(value) : value
        }));
    };
    
    const handleSettingsSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (currentUser) {
            updateSettings(localSettings, currentUser.id);
            notifySuccess('Settings saved successfully!');
        }
    };
    
    const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
    const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`;

    const TabButton: React.FC<{tabId: string; label: string}> = ({tabId, label}) => (
         <button
            onClick={() => setActiveTab(tabId)}
            className={`px-4 py-2 font-semibold rounded-full transition-all duration-300
                ${activeTab === tabId 
                    ? themeClasses.button 
                    : isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'
                }`
            }
        >
            {label}
        </button>
    )

    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <PageHeader title="Systems Management" />
            
            <Card className="!p-4 flex gap-2 flex-wrap">
                <TabButton tabId="users" label="User Management" />
                <TabButton tabId="settings" label="General Settings" />
                <TabButton tabId="audit" label="Audit Log" />
            </Card>

            {activeTab === 'users' && (
                <Card className="!p-0 overflow-hidden">
                    <div className="p-6">
                        <h2 className="text-xl font-bold flex items-center gap-2">
                            <UserCog className={`w-6 h-6 ${themeClasses.textGradient}`} />
                            <span>Manage User Roles</span>
                        </h2>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
                                <tr>
                                    <th className="p-4">User</th>
                                    <th className="p-4">Role</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users.map(user => (
                                    <tr key={user.id} className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                        <td className="p-4">
                                            <div className="flex items-center gap-3">
                                                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold shadow-lg text-sm">
                                                    {user.avatar}
                                                </div>
                                                <span className="font-semibold">{user.name}</span>
                                            </div>
                                        </td>
                                        <td className="p-4">
                                             <select 
                                                value={user.role}
                                                onChange={(e) => handleRoleChange(user.id, e.target.value as UserRole)}
                                                disabled={currentUser?.id === user.id || user.role === UserRole.ADMINISTRATOR}
                                                className={`p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'} disabled:opacity-50 disabled:cursor-not-allowed`}
                                             >
                                                {Object.values(UserRole).map(role => (
                                                    <option key={role} value={role} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{role}</option>
                                                ))}
                                            </select>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Card>
            )}

            {activeTab === 'settings' && (
                 <Card>
                    <div className="p-6">
                        <h2 className="text-xl font-bold flex items-center gap-2">
                            <Building className={`w-6 h-6 ${themeClasses.textGradient}`} />
                            <span>General Company Settings</span>
                        </h2>
                    </div>
                    <form onSubmit={handleSettingsSubmit} className="space-y-6 p-6">
                        <div>
                            <label htmlFor="companyName" className={labelClasses}>Company Name</label>
                            <input type="text" id="companyName" name="companyName" value={localSettings.companyName} onChange={handleSettingsChange} className={`${inputClasses} ${isDarkMode ? 'text-white' : 'text-black'}`} />
                        </div>
                         <div>
                            <label htmlFor="address" className={labelClasses}>Company Address</label>
                            <input type="text" id="address" name="address" value={localSettings.address} onChange={handleSettingsChange} className={`${inputClasses} ${isDarkMode ? 'text-white' : 'text-black'}`} />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label htmlFor="markupPercentage" className={labelClasses}>Global Sales Markup (%)</label>
                                <div className="relative">
                                    <input type="number" step="0.1" id="markupPercentage" name="markupPercentage" value={localSettings.markupPercentage} onChange={handleSettingsChange} className={`${inputClasses} pl-8 ${isDarkMode ? 'text-white' : 'text-black'}`} />
                                    <Percent size={16} className={`absolute left-2.5 top-1/2 -translate-y-1/2 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`} />
                                </div>
                                <p className="text-xs text-slate-500 mt-1">Updates all product sale prices based on their cost.</p>
                            </div>
                            <div>
                                <label htmlFor="defaultCurrency" className={labelClasses}>Default Currency</label>
                                <select id="defaultCurrency" name="defaultCurrency" value={localSettings.defaultCurrency} onChange={handleSettingsChange} className={`${inputClasses} ${isDarkMode ? 'text-white' : 'text-black'}`}>
                                    {CURRENCIES.map((c: Currency) => (
                                        <option key={c.code} value={c.code} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{c.name} ({c.symbol})</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                             <div>
                                <label htmlFor="taxRate" className={labelClasses}>Sales Tax Rate (%)</label>
                                <input type="number" step="0.01" id="taxRate" name="taxRate" value={localSettings.taxRate} onChange={handleSettingsChange} className={`${inputClasses} ${isDarkMode ? 'text-white' : 'text-black'}`} />
                            </div>
                            <div>
                                <label htmlFor="incomeTaxRate" className={labelClasses}>Income Tax Rate (%)</label>
                                <input type="number" step="0.01" id="incomeTaxRate" name="incomeTaxRate" value={localSettings.incomeTaxRate} onChange={handleSettingsChange} className={`${inputClasses} ${isDarkMode ? 'text-white' : 'text-black'}`} />
                            </div>
                        </div>
                        <div className="flex justify-end items-center gap-4 pt-4 border-t border-slate-700/20">
                            <button type="submit" className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                                Save Settings
                            </button>
                        </div>
                    </form>
                 </Card>
            )}
            
            {activeTab === 'audit' && (
                <Card className="!p-0 overflow-hidden">
                    <div className="p-6">
                        <h2 className="text-xl font-bold flex items-center gap-2">
                            <History className={`w-6 h-6 ${themeClasses.textGradient}`} />
                            <span>System Audit Log</span>
                        </h2>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
                                <tr>
                                    <th className="p-4">Timestamp</th>
                                    <th className="p-4">User</th>
                                    <th className="p-4">Action</th>
                                    <th className="p-4">Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                {currentAuditItems.map(log => (
                                    <tr key={log.id} className={`border-b text-sm ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                        <td className="p-4 whitespace-nowrap">{format(new Date(log.timestamp), 'dd MMM yyyy, HH:mm:ss')}</td>
                                        <td className="p-4 font-semibold">{log.userName}</td>
                                        <td className="p-4">
                                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${themeClasses.statusBadge}`}>
                                                {log.action}
                                            </span>
                                        </td>
                                        <td className={`${isDarkMode ? 'text-slate-400' : 'text-slate-600'} p-4`}>{log.details}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                     <Pagination 
                        currentPage={auditLogPage}
                        totalPages={totalAuditPages > 0 ? totalAuditPages : 1}
                        onPageChange={setAuditLogPage}
                        itemsCount={sortedAuditLogs.length}
                        itemsPerPage={auditItemsPerPage}
                    />
                </Card>
            )}
        </div>
    );
};

export default SystemsPage;
