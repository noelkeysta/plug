
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { InventoryItem, Product, Customer } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { useSearch } from '../contexts/SearchContext';
import Pagination from '../components/ui/Pagination';
import { format } from 'date-fns';

const WarrantyPage: React.FC = () => {
  const { data } = useData();
  const { inventoryItems = [], products = [], customers = [] } = data || {};
  const { isDarkMode } = useTheme();
  const { searchQuery } = useSearch();

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;

  const productMap = useMemo(() => products.reduce((acc, p) => ({ ...acc, [p.id]: p }), {} as Record<string, Product>), [products]);
  const customerMap = useMemo(() => customers.reduce((acc, c) => ({ ...acc, [c.id]: c }), {} as Record<number, Customer>), [customers]);

  const filteredItems = useMemo(() => {
    let items = inventoryItems.filter(item => item.status === 'sold');
    
    if (searchQuery) {
        const lowercasedQuery = searchQuery.toLowerCase();
        items = items.filter(item => {
            const product = productMap[item.productId];
            const customer = item.soldToCustomerId ? customerMap[item.soldToCustomerId] : null;
            return (
                item.id.toLowerCase().includes(lowercasedQuery) ||
                (product && product.name.toLowerCase().includes(lowercasedQuery)) ||
                (customer && customer.name.toLowerCase().includes(lowercasedQuery))
            );
        });
    }

    return items.sort((a,b) => (b.soldAt?.getTime() || 0) - (a.soldAt?.getTime() || 0));
  }, [inventoryItems, searchQuery, productMap, customerMap]);

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const currentItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  useEffect(() => {
      setCurrentPage(1);
  }, [searchQuery]);

  const getWarrantyStatus = (endDate?: Date) => {
    if (!endDate) return { text: 'N/A', color: 'bg-slate-500/30 text-slate-300' };
    const now = new Date();
    if (now > endDate) {
        return { text: 'Expired', color: isDarkMode ? 'bg-red-500/30 text-red-300' : 'bg-red-100 text-red-700' };
    }
    return { text: 'Active', color: isDarkMode ? 'bg-emerald-500/30 text-emerald-300' : 'bg-emerald-100 text-emerald-700' };
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-8">
      <PageHeader title="Warranty Tracking" subtitle="Look up warranty status by serial number" />

      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
              <tr>
                <th className="p-4">Serial Number</th>
                <th className="p-4">Product</th>
                <th className="p-4">Sold To</th>
                <th className="p-4">Sold Date</th>
                <th className="p-4">Warranty End Date</th>
                <th className="p-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((item) => {
                const product = productMap[item.productId];
                const customer = item.soldToCustomerId ? customerMap[item.soldToCustomerId] : null;
                const warrantyStatus = getWarrantyStatus(item.warrantyEndDate);
                return (
                    <tr key={item.id} className={`border-b ${isDarkMode ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-200 hover:bg-slate-200/50'}`}>
                      <td className="p-4 font-mono text-sm">{item.id}</td>
                      <td className="p-4 font-semibold">{product?.name || 'Unknown Product'}</td>
                      <td className="p-4">{customer?.name || 'N/A'}</td>
                      <td className="p-4">{item.soldAt ? format(new Date(item.soldAt), 'dd MMM yyyy') : 'N/A'}</td>
                      <td className="p-4">{item.warrantyEndDate ? format(new Date(item.warrantyEndDate), 'dd MMM yyyy') : 'N/A'}</td>
                      <td className="p-4">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${warrantyStatus.color}`}>
                            {warrantyStatus.text}
                        </span>
                      </td>
                    </tr>
                );
            })}
            </tbody>
          </table>
        </div>
        <Pagination 
            currentPage={currentPage}
            totalPages={totalPages > 0 ? totalPages : 1}
            onPageChange={setCurrentPage}
            itemsCount={filteredItems.length}
            itemsPerPage={itemsPerPage}
        />
      </Card>
    </div>
  );
};

export default WarrantyPage;
