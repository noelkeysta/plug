

import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { useAuth } from '../contexts/AuthContext';
import { UserRole, Product, Supplier } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { PlusCircle, Edit } from 'lucide-react';
import { useSearch } from '../contexts/SearchContext';
import Modal from '../components/ui/Modal';
import AddProductModal from '../components/inventory/AddProductModal';
import EditProductModal from '../components/inventory/EditProductModal';
import Pagination from '../components/ui/Pagination';
import { useCurrency } from '../contexts/CurrencyContext';
import { formatCurrency } from '../utils/formatters';

const InventoryPage: React.FC = () => {
  const { data } = useData();
  const { products = [], inventoryItems = [], suppliers = [] } = data || {};
  const { currentUser } = useAuth();
  const { isDarkMode, themeClasses } = useTheme();
  const { searchQuery } = useSearch();
  const { currency } = useCurrency();

  const [isAddModalOpen, setAddModalOpen] = useState(false);
  const [isEditModalOpen, setEditModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [stockFilter, setStockFilter] = useState('All');

  const canManageInventory = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER].includes(currentUser.role);
  
  const uniqueCategories = useMemo(() => ['All', ...new Set(products.map(p => p.category))], [products]);

  const supplierMap = useMemo(() => suppliers.reduce((acc, s) => ({ ...acc, [s.id]: s.name }), {} as Record<number, string>), [suppliers]);

  const productStockMap = useMemo(() => {
    return inventoryItems.reduce((acc, item) => {
        if (item.status === 'available') {
            acc[item.productId] = (acc[item.productId] || 0) + 1;
        }
        return acc;
    }, {} as Record<string, number>);
  }, [inventoryItems]);
  
  const filteredItems = useMemo(() => {
    let items = products.map(p => ({ ...p, stock: productStockMap[p.id] || 0 }));

    if (searchQuery) {
        items = items.filter(product =>
            product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            product.id.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }

    if (categoryFilter !== 'All') {
        items = items.filter(product => product.category === categoryFilter);
    }
    
    if (stockFilter !== 'All') {
        items = items.filter(product => {
            if (stockFilter === 'In Stock') return product.stock > 10;
            if (stockFilter === 'Low Stock') return product.stock > 0 && product.stock <= 10;
            if (stockFilter === 'Out of Stock') return product.stock === 0;
            return true;
        });
    }

    return items;
  }, [products, searchQuery, categoryFilter, stockFilter, productStockMap]);

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const currentItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  useEffect(() => {
      setCurrentPage(1);
  }, [searchQuery, categoryFilter, stockFilter]);

  const handleEditClick = (product: Product) => {
    setSelectedProduct(product);
    setEditModalOpen(true);
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-8">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <PageHeader title="Inventory" />
        {canManageInventory && (
          <button onClick={() => setAddModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
            <PlusCircle size={20} />
            Add Product
          </button>
        )}
      </div>
      
      <Card className="!p-4 flex flex-col md:flex-row flex-wrap gap-4">
          <div className="flex-grow min-w-[200px]">
              <label htmlFor="category-filter" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Category</label>
              <select 
                id="category-filter"
                value={categoryFilter}
                onChange={e => setCategoryFilter(e.target.value)}
                className={`w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`}
              >
                  {uniqueCategories.map(cat => <option key={cat} value={cat} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{cat}</option>)}
              </select>
          </div>
          <div className="flex-grow min-w-[200px]">
              <label htmlFor="stock-filter" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Stock Status</label>
              <select 
                id="stock-filter"
                value={stockFilter}
                onChange={e => setStockFilter(e.target.value)}
                className={`w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`}
              >
                  <option value="All" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>All</option>
                  <option value="In Stock" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>In Stock (&gt;10)</option>
                  <option value="Low Stock" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>Low Stock (&le;10)</option>
                  <option value="Out of Stock" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>Out of Stock</option>
              </select>
          </div>
      </Card>

      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
              <tr>
                <th className="p-4">Product</th>
                <th className="p-4">Category</th>
                <th className="p-4">Supplier</th>
                <th className="p-4 w-48">Stock Level</th>
                <th className="p-4 text-right">Price</th>
                <th className="p-4 text-right">Cost</th>
                {canManageInventory && <th className="p-4 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {currentItems.map((product) => {
                 const stockLevel = product.stock;
                 let stockColor = 'bg-emerald-500';
                 if (stockLevel <= 10 && stockLevel > 0) stockColor = 'bg-yellow-500';
                 else if (stockLevel === 0) stockColor = 'bg-red-500';
                 const stockPercentage = Math.min((stockLevel / 50) * 100, 100);

                return(
                <tr key={product.id} className={`border-b ${isDarkMode ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-200 hover:bg-slate-200/50'}`}>
                  <td className="p-4 font-semibold">{product.name}<br/><span className="font-mono text-xs text-slate-500">{product.id}</span></td>
                  <td className="p-4">{product.category}</td>
                  <td className={`p-4 text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{supplierMap[product.supplierId] || 'N/A'}</td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <div className={`w-full ${themeClasses.progressBg} rounded-full h-2.5 overflow-hidden`}>
                        <div className={`${stockColor} h-2.5 rounded-full`} style={{ width: `${stockPercentage}%` }}/>
                      </div>
                      <span className={`font-mono w-8 text-right ${stockLevel <= 10 && stockLevel > 0 ? 'text-yellow-400' : stockLevel === 0 ? 'text-red-400' : ''}`}>{stockLevel}</span>
                    </div>
                  </td>
                  <td className="p-4 text-right font-medium">{formatCurrency(product.price, currency)}</td>
                  <td className={`p-4 text-right ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{formatCurrency(product.cost, currency)}</td>
                  {canManageInventory && (
                    <td className="p-4 text-center">
                       <button onClick={() => handleEditClick(product)} className={`p-2 rounded-full transition-colors ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`} aria-label="Edit Product">
                          <Edit size={16} />
                       </button>
                    </td>
                  )}
                </tr>
              )})}
            </tbody>
          </table>
        </div>
        <Pagination 
            currentPage={currentPage}
            totalPages={totalPages > 0 ? totalPages : 1}
            onPageChange={setCurrentPage}
            itemsCount={filteredItems.length}
            itemsPerPage={itemsPerPage}
        />
      </Card>
      
      <Modal isOpen={isAddModalOpen} onClose={() => setAddModalOpen(false)} title="Add New Product">
        <AddProductModal 
          onClose={() => setAddModalOpen(false)} 
          user={currentUser}
        />
      </Modal>

      {selectedProduct && (
        <Modal isOpen={isEditModalOpen} onClose={() => setEditModalOpen(false)} title={`Edit ${selectedProduct.name}`}>
          <EditProductModal
            product={selectedProduct}
            onClose={() => setEditModalOpen(false)} 
            user={currentUser}
          />
        </Modal>
      )}
    </div>
  );
};

export default InventoryPage;
