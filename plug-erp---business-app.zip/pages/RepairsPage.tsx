
import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import { useAuth } from '../contexts/AuthContext';
import { UserRole, RepairJob, RepairStatus, User } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { useSearch } from '../contexts/SearchContext';
import Pagination from '../components/ui/Pagination';
import { useCurrency } from '../contexts/CurrencyContext';
import { formatCurrency } from '../utils/formatters';
import { format, formatDistanceToNow } from 'date-fns';
import { updateRepairJobStatus } from '../services/mockDataService';
import { useNotifier } from '../contexts/NotificationContext';
import RepairStatusBadge from '../components/repairs/RepairStatusBadge';
import { DollarSign } from 'lucide-react';

const RepairsPage: React.FC = () => {
  const { data, refreshData } = useData();
  const { currentUser } = useAuth();
  const { isDarkMode, themeClasses } = useTheme();
  const { searchQuery } = useSearch();
  const { currency } = useCurrency();
  const { notifySuccess } = useNotifier();
  const navigate = useNavigate();

  const repairJobs = data?.repairJobs || [];
  const users = data?.users || [];
  
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  const [statusFilter, setStatusFilter] = useState('All');
  
  const userMap = useMemo(() => {
    return users.reduce((acc, user) => {
        acc[user.id] = user;
        return acc;
    }, {} as Record<number, User>);
  }, [users]);

  const canEditStatus = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER].includes(currentUser.role);
  
  const filteredItems = useMemo(() => {
    let items = repairJobs;

    if (searchQuery) {
        items = items.filter(job =>
            job.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
            job.deviceDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
            `R-${job.id}`.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }

    if (statusFilter !== 'All') {
        items = items.filter(job => job.status === statusFilter);
    }

    return items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [repairJobs, searchQuery, statusFilter]);

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const currentItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  useEffect(() => {
      setCurrentPage(1);
  }, [searchQuery, statusFilter]);

  const handleStatusChange = (jobId: number, newStatus: RepairStatus) => {
    if (!currentUser) return;
    updateRepairJobStatus(jobId, newStatus, currentUser.id);
    notifySuccess(`Repair Job #${jobId} status updated to ${newStatus}.`);
    refreshData();
  };
  
  const handleBillCustomer = (job: RepairJob) => {
    navigate('/sales', { state: { repairJobId: job.id } });
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-8">
      <PageHeader title="Repair Jobs" subtitle="Track and manage customer repairs" />
      
      <Card className="!p-4">
          <label htmlFor="status-filter" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Filter by Status</label>
          <select 
            id="status-filter"
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className={`w-full md:w-1/4 mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-300 text-black'}`}
          >
              <option value="All" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>All Statuses</option>
              {Object.values(RepairStatus).map(status => (
                  <option key={status} value={status} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{status}</option>
              ))}
          </select>
      </Card>

      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
              <tr>
                <th className="p-4">Job ID</th>
                <th className="p-4">Customer</th>
                <th className="p-4">Device</th>
                <th className="p-4">Logged</th>
                <th className="p-4">Assigned To</th>
                <th className="p-4 text-right">Quote</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentItems.map((job) => (
                <tr key={job.id} className={`border-b ${isDarkMode ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-200 hover:bg-slate-200/50'}`}>
                  <td className="p-4 font-mono text-sm">R-{job.id}</td>
                  <td className="p-4 font-semibold">{job.customerName}</td>
                  <td className="p-4">{job.deviceDescription}</td>
                  <td className={`p-4 text-sm whitespace-nowrap ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}</td>
                  <td className="p-4">{userMap[job.assignedToId]?.name || 'Unassigned'}</td>
                  <td className="p-4 text-right font-medium">{formatCurrency(job.quote, currency)}</td>
                  <td className="p-4">
                    {canEditStatus && job.status !== RepairStatus.COMPLETED && job.status !== RepairStatus.CANCELLED && job.status !== RepairStatus.CLOSED ? (
                       <select 
                          value={job.status}
                          onChange={(e) => handleStatusChange(job.id, e.target.value as RepairStatus)}
                          className={`w-full text-xs p-1 rounded-md border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-400'}`}
                        >
                          <option value={RepairStatus.PENDING}>Pending</option>
                          <option value={RepairStatus.IN_PROGRESS}>In Progress</option>
                          <option value={RepairStatus.COMPLETED}>Completed</option>
                          <option value={RepairStatus.CANCELLED}>Cancelled</option>
                        </select>
                    ) : (
                      <RepairStatusBadge status={job.status} />
                    )}
                  </td>
                  <td className="p-4 text-center">
                    {job.status === RepairStatus.COMPLETED && (
                      <button 
                        onClick={() => handleBillCustomer(job)}
                        className={`flex items-center gap-1.5 text-xs px-2 py-1 rounded-full font-semibold transition-colors ${themeClasses.button}`}
                      >
                          <DollarSign size={14} /> Bill Customer
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination 
            currentPage={currentPage}
            totalPages={totalPages > 0 ? totalPages : 1}
            onPageChange={setCurrentPage}
            itemsCount={filteredItems.length}
            itemsPerPage={itemsPerPage}
        />
      </Card>
    </div>
  );
};

export default RepairsPage;
