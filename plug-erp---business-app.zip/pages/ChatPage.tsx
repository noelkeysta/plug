
import React, { useState, useMemo, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import ConversationList from '../components/chat/ConversationList';
import ChatWindow from '../components/chat/ChatWindow';
import ChatWelcome from '../components/chat/ChatWelcome';
import { Conversation, User } from '../types';

const ChatPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { data } = useData();
  const { themeClasses } = useTheme();
  const { conversationId } = useParams();
  const navigate = useNavigate();

  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(conversationId || null);

  useEffect(() => {
    setSelectedConversationId(conversationId || null);
  }, [conversationId]);

  const { conversations = [], messages = [], users = [] } = data || {};
  const userMap = useMemo(() => users.reduce((acc, u) => ({...acc, [u.id]: u}), {} as Record<number, User>), [users]);

  const userConversations = useMemo(() => {
    if (!currentUser) return [];
    return conversations
      .filter(c => c.participants.includes(currentUser.id))
      .sort((a, b) => {
        const dateA = a.lastMessage ? new Date(a.lastMessage.timestamp).getTime() : new Date(a.createdAt).getTime();
        const dateB = b.lastMessage ? new Date(b.lastMessage.timestamp).getTime() : new Date(b.createdAt).getTime();
        return dateB - dateA;
      });
  }, [conversations, currentUser]);

  const selectedConversation = useMemo(() => {
    return conversations.find(c => c.id === selectedConversationId);
  }, [conversations, selectedConversationId]);
  
  const conversationMessages = useMemo(() => {
    if (!selectedConversationId) return [];
    return messages
      .filter(m => m.conversationId === selectedConversationId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }, [messages, selectedConversationId]);

  const handleSelectConversation = (id: string) => {
    navigate(`/chat/${id}`);
  };

  if (!currentUser) return null;

  return (
    <main className="flex-1 flex overflow-hidden h-full">
      <div className={`w-1/3 max-w-sm border-r ${themeClasses.sidebar} rounded-none p-4 flex flex-col`}>
        <ConversationList
          conversations={userConversations}
          currentUser={currentUser}
          userMap={userMap}
          selectedConversationId={selectedConversationId}
          onSelectConversation={handleSelectConversation}
        />
      </div>
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <ChatWindow
            key={selectedConversation.id}
            conversation={selectedConversation}
            messages={conversationMessages}
            currentUser={currentUser}
            userMap={userMap}
          />
        ) : (
          <ChatWelcome />
        )}
      </div>
    </main>
  );
};

export default ChatPage;
