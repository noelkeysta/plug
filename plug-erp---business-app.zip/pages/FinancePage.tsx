

import React, { useState, useMemo } from 'react';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import { useCurrency } from '../contexts/CurrencyContext';
import { Account, Expense, ExpenseCategory, UserRole } from '../../types';
import { formatCurrency } from '../../utils/formatters';

import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import AccountLedgerModal from '../components/finance/AccountLedgerModal';
import BudgetVsActual from '../components/finance/BudgetVsActual';
import ExpensePieChart from '../components/finance/ExpensePieChart';
import ExpenseDetailsModal from '../components/finance/ExpenseDetailsModal';
import AddExpenseModal from '../components/finance/AddExpenseModal';
import AddJournalEntryModal from '../components/finance/AddJournalEntryModal';

import { Eye, PlusCircle } from 'lucide-react';
import { format, endOfMonth } from 'date-fns';
import set from 'date-fns/set';
import { NOW } from '../services/mockDataService';
import { useAuth } from '../contexts/AuthContext';

const startOfMonth = (date: Date): Date => {
    return set(date, { date: 1, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 });
};

const FinancePage: React.FC = () => {
    const { currentUser } = useAuth();
    const { isDarkMode, themeClasses } = useTheme();
    const { currency } = useCurrency();
    const { data } = useData();
    const { accounts = [], ledger = [], budgets = [], expenses = [] } = data || {};
    
    const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
    const [isLedgerModalOpen, setLedgerModalOpen] = useState(false);
    const [isExpenseModalOpen, setExpenseModalOpen] = useState(false);
    const [isAddExpenseModalOpen, setAddExpenseModalOpen] = useState(false);
    const [isAddJournalEntryModalOpen, setAddJournalEntryModalOpen] = useState(false);
    const [selectedExpenseCategory, setSelectedExpenseCategory] = useState<ExpenseCategory | 'Salaries' | null>(null);

    const [viewDate, setViewDate] = useState(format(NOW, 'yyyy-MM'));
    
    const canManageFinance = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT].includes(currentUser.role);
    
    const { monthStart, monthEnd } = useMemo(() => {
        const date = new Date(viewDate + '-02'); // Use day 2 to avoid timezone issues
        return {
            monthStart: startOfMonth(date),
            monthEnd: endOfMonth(date),
        };
    }, [viewDate]);
    
    const accountsForPeriod = useMemo(() => {
        // For each account, calculate its balance up to the monthEnd date
        return accounts.map(account => {
            const balance = ledger
                .filter(entry => {
                    const entryDate = new Date(entry.timestamp);
                    return entry.accountId === account.id && entryDate <= monthEnd;
                })
                .reduce((sum, entry) => sum + entry.amount, 0);

            return { ...account, balance };
        });
    }, [accounts, ledger, monthEnd]);

    const accountGroups = useMemo(() => {
        return accountsForPeriod.reduce((acc, account) => {
            if (!acc[account.type]) acc[account.type] = [];
            acc[account.type].push(account);
            return acc;
        }, {} as Record<string, Account[]>);
    }, [accountsForPeriod]);

    const monthlyExpenses = useMemo(() => {
        return expenses.filter(e => {
            const expenseDate = new Date(e.date);
            return expenseDate >= monthStart && expenseDate <= monthEnd;
        });
    }, [expenses, monthStart, monthEnd]);

    const handleViewLedger = (account: Account) => {
        setSelectedAccount(account);
        setLedgerModalOpen(true);
    };

    const handleViewExpenseDetails = (category: ExpenseCategory | 'Salaries') => {
        setSelectedExpenseCategory(category);
        setExpenseModalOpen(true);
    };

    if (!data) return <div>Loading...</div>

    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <div className="flex items-center justify-between flex-wrap gap-4">
                <PageHeader title="Finance Hub" subtitle="General Ledger & Budgets" />
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <label htmlFor="month-picker" className="font-semibold">View Month:</label>
                        <input
                            type="month"
                            id="month-picker"
                            value={viewDate}
                            onChange={(e) => setViewDate(e.target.value)}
                            className={`p-2 rounded-lg border bg-transparent ${themeClasses.card} ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
                        />
                    </div>
                     {canManageFinance && (
                        <div className="flex items-center gap-2">
                            <button onClick={() => setAddJournalEntryModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-colors duration-300 border-2 ${isDarkMode ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-300 hover:bg-slate-100'}`}>
                                New Journal Entry
                            </button>
                            <button onClick={() => setAddExpenseModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                                <PlusCircle size={20} />
                                Log Expense
                            </button>
                        </div>
                    )}
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                     <Card className="!p-0 overflow-hidden">
                        <div className="p-6"><h2 className="text-xl font-bold">Chart of Accounts</h2></div>
                        <div className="overflow-x-auto">
                           {Object.entries(accountGroups).map(([type, accs]) => (
                               <div key={type} className="mb-4">
                                   <h3 className={`font-semibold text-lg px-6 pb-2 ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`}>{type}</h3>
                                    <table className="w-full text-left">
                                        <thead className={`border-y ${isDarkMode ? 'border-amber-500/10' : 'border-blue-200/30'} ${isDarkMode ? 'bg-slate-800/20' : 'bg-slate-100/50'}`}>
                                            <tr>
                                                <th className="p-4 w-24">ID</th><th className="p-4">Account Name</th><th className="p-4 text-right">Balance</th><th className="p-4 text-center w-24">Ledger</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {accs.map((account) => (
                                                <tr key={account.id} className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                                    <td className={`p-4 font-mono text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{account.id}</td>
                                                    <td className="p-4 font-semibold">{account.name}</td>
                                                    <td className={`p-4 text-right font-semibold font-mono ${account.balance < 0 ? 'text-red-400' : ''}`}>{formatCurrency(account.balance, currency)}</td>
                                                    <td className="p-4 text-center">
                                                        <button onClick={() => handleViewLedger(account)} className="p-2 rounded-full hover:bg-white/10"><Eye size={18} /></button>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                               </div>
                           ))}
                        </div>
                    </Card>
                </div>
                <div className="lg:col-span-1 space-y-8">
                    <ExpensePieChart expenses={monthlyExpenses} />
                    <BudgetVsActual budgets={budgets} expenses={monthlyExpenses} onCategoryClick={handleViewExpenseDetails} />
                </div>
            </div>

            <Modal isOpen={isLedgerModalOpen} onClose={() => setLedgerModalOpen(false)} title={`Ledger: ${selectedAccount?.name}`} size="xl">
                {selectedAccount && <AccountLedgerModal account={selectedAccount} ledger={ledger} />}
            </Modal>
            
            <Modal isOpen={isExpenseModalOpen} onClose={() => setExpenseModalOpen(false)} title={`Expenses: ${selectedExpenseCategory}`} size="lg">
                {selectedExpenseCategory && (
                    <ExpenseDetailsModal
                        category={selectedExpenseCategory}
                        allExpenses={monthlyExpenses}
                    />
                )}
            </Modal>

            <Modal isOpen={isAddExpenseModalOpen} onClose={() => setAddExpenseModalOpen(false)} title="Log New Expense">
                <AddExpenseModal onClose={() => setAddExpenseModalOpen(false)} />
            </Modal>
            
            <Modal isOpen={isAddJournalEntryModalOpen} onClose={() => setAddJournalEntryModalOpen(false)} title="Create General Journal Entry" size="xl">
                <AddJournalEntryModal onClose={() => setAddJournalEntryModalOpen(false)} />
            </Modal>
        </div>
    );
};

export default FinancePage;
