

import React, { useState, useMemo } from 'react';
import { useData } from '../contexts/DataContext';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';
import PageHeader from '../components/ui/PageHeader';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import AddShiftModal from '../components/scheduling/AddShiftModal';
import { ChevronLeft, ChevronRight, PlusCircle } from 'lucide-react';
import { format, endOfWeek, eachDayOfInterval, isSameDay, addWeeks } from 'date-fns';
import startOfWeek from 'date-fns/startOfWeek';
import subWeeks from 'date-fns/subWeeks';

const SchedulingPage: React.FC = () => {
    const { data } = useData();
    const { users = [], shifts = [] } = data || {};
    const { currentUser } = useAuth();
    const { isDarkMode, themeClasses } = useTheme();

    const [currentDate, setCurrentDate] = useState(new Date());
    const [isAddShiftModalOpen, setAddShiftModalOpen] = useState(false);

    const canManageShifts = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER].includes(currentUser.role);
    const userMap = useMemo(() => users.reduce((acc, user) => ({ ...acc, [user.id]: user }), {} as Record<number, typeof users[0]>), [users]);

    const week = useMemo(() => {
        const start = startOfWeek(currentDate, { weekStartsOn: 1 });
        const end = endOfWeek(currentDate, { weekStartsOn: 1 });
        return eachDayOfInterval({ start, end });
    }, [currentDate]);

    const scheduledShifts = useMemo(() => {
        return shifts.reduce((acc, shift) => {
            const dayKey = format(shift.start, 'yyyy-MM-dd');
            if (!acc[dayKey]) acc[dayKey] = [];
            acc[dayKey].push(shift);
            return acc;
        }, {} as Record<string, typeof shifts>);
    }, [shifts]);

    const goToPreviousWeek = () => setCurrentDate(subWeeks(currentDate, 1));
    const goToNextWeek = () => setCurrentDate(addWeeks(currentDate, 1));
    const goToToday = () => setCurrentDate(new Date());

    return (
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <div className="flex justify-between items-center flex-wrap gap-4">
                <PageHeader title="Employee Scheduling" subtitle={`Week of ${format(startOfWeek(currentDate, { weekStartsOn: 1 }), 'MMMM do')}`} />
                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 p-1 rounded-full bg-slate-500/10">
                        <button onClick={goToPreviousWeek} className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`}><ChevronLeft /></button>
                        <button onClick={goToToday} className={`px-4 py-2 text-sm font-semibold rounded-full ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`}>Today</button>
                        <button onClick={goToNextWeek} className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`}><ChevronRight /></button>
                    </div>
                    {canManageShifts && (
                        <button onClick={() => setAddShiftModalOpen(true)} className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                            <PlusCircle size={20} /> New Shift
                        </button>
                    )}
                </div>
            </div>

            <Card className="!p-0 overflow-hidden">
                <div className="grid grid-cols-7">
                    {week.map(day => (
                        <div key={day.toString()} className={`p-2 border-r ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                            <div className={`text-center p-2 rounded-lg ${isSameDay(day, new Date()) ? (isDarkMode ? 'bg-amber-500/20' : 'bg-blue-100') : ''}`}>
                                <p className="font-bold text-lg">{format(day, 'd')}</p>
                                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>{format(day, 'EEE')}</p>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="grid grid-cols-7 min-h-[50vh]">
                    {week.map(day => {
                        const dayKey = format(day, 'yyyy-MM-dd');
                        const dayShifts = scheduledShifts[dayKey] || [];
                        return (
                            <div key={day.toString()} className={`p-2 border-r ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                <div className="space-y-2">
                                    {dayShifts.map(shift => (
                                        <div key={shift.id} className={`p-2 rounded-lg ${isDarkMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
                                            <p className="font-semibold text-sm">{userMap[shift.employeeId]?.name || 'Unknown'}</p>
                                            <p className="text-xs text-slate-400">{format(shift.start, 'HH:mm')} - {format(shift.end, 'HH:mm')}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </Card>

            <Modal isOpen={isAddShiftModalOpen} onClose={() => setAddShiftModalOpen(false)} title="Add New Shift">
                <AddShiftModal onClose={() => setAddShiftModalOpen(false)} />
            </Modal>
        </div>
    );
};

export default SchedulingPage;