# Application Architecture

This document provides a detailed overview of the technical architecture for the PLUG ERP Dashboard application.

## 1. Core Technologies

- **React 19**: The foundation of our user interface, utilizing functional components and hooks for building a declarative and component-based UI.
- **TypeScript**: Used throughout the project to provide static typing, improving code quality, maintainability, and developer experience by catching errors early.
- **TailwindCSS**: A utility-first CSS framework used for all styling. It enables rapid UI development with a consistent design language without writing custom CSS.
- **Lucide-React**: A lightweight and beautiful icon library that provides clean and consistent icons across the application.

### Forms and Validation
- **`react-hook-form`**: Manages form state, submission, and validation logic efficiently, optimizing for performance by isolating component re-renders.
- **`zod`**: A TypeScript-first schema declaration and validation library, used with `react-hook-form` to ensure data integrity with clear, reusable schemas.

## 2. State Management

Global application state is managed using **React's Context API**. This approach avoids the need for external state management libraries like Redux for an application of this scale, keeping the dependency footprint small.

We have several specialized contexts:

- **`ThemeContext`**: Manages the current UI theme (light/dark mode). It provides a set of theme-specific CSS classes that components can consume to adapt their appearance.
- **`AuthContext`**: Manages user authentication and authorization. It holds the `currentUser` object and a list of all users. It exposes functions like `loginAs` to switch users and `refreshUsers` to sync with the data service. This context is the source of truth for user permissions.
- **`CurrencyContext`**: Manages the currently selected currency and provides a list of available currencies. This allows all financial data in the app to be displayed in the user's preferred currency.
- **`SearchContext`**: Manages the global search query entered in the header's search bar. Pages that support searching can consume this context to filter their displayed data.

## 3. Routing

Client-side routing is handled by **`react-router-dom`**.

- **`HashRouter`**: Used as the primary router. This is suitable for single-page applications that may be deployed in environments where server-side URL rewriting isn't available.
- **Routes Definition**: All application routes are defined in `App.tsx`. This file uses a nested route structure within a `MainLayout` component, which provides the consistent header and sidebar for all pages.

## 4. Component Structure

The component architecture is designed to be modular and reusable.

- **`pages/`**: Contains top-level components that correspond to a specific route (e.g., `DashboardPage`, `InventoryPage`). These components are responsible for fetching data from services and composing the page layout using smaller, reusable components.
- **`components/`**: This directory is subdivided by feature or purpose:
    - **`components/layout/`**: High-level layout components like `Header`, `Sidebar`, and `MainLayout`.
    - **`components/ui/`**: Generic, presentation-focused components that can be used anywhere (e.g., `Card`, `Modal`, `PageHeader`, `Pagination`). These components are styled but contain no business logic.
    - **`components/[feature]/`**: Feature-specific components that contain business logic related to a particular domain (e.g., `components/dashboard/KpiCard`, `components/sales/ProductGrid`).

## 5. Data Flow

The application simulates a full-stack environment through a mock data service.

1.  **Source of Truth**: The `services/mockDataService.ts` file acts as a singleton data store. It initializes a large set of mock data in-memory on the first call.
2.  **Data Fetching**: Page components (e.g., `DashboardPage`) call `getMockData()` to retrieve the data they need to render.
3.  **State Synchronization**: Since `getMockData()` returns a copy of the data, pages often store this data in their local state using `useState`. This prevents direct mutation and follows React's unidirectional data flow principles.
4.  **Data Mutation**: When a user performs an action (e.g., completing a sale, adding a product), the component calls a mutation function from the mock service (e.g., `addSaleTransaction`).
5.  **Updating the UI**: The mutation function modifies the central data store within the service. To reflect these changes in the UI, the component must then re-fetch the data (or a part of it) and update its local state, triggering a re-render. For global state like user roles, the `AuthContext` provides a `refreshUsers` function to trigger this update centrally.

## 6. Styling and Theming

- **TailwindCSS**: Provides the core styling utilities.
- **`ThemeContext`**: Builds on top of Tailwind by providing semantic class groups. For example, `themeClasses.card` resolves to a string of Tailwind classes for styling a card in either light or dark mode. This abstracts the specific theme styling away from the components, making it easy to change the entire look and feel of the application from one place.