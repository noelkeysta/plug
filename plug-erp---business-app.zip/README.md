# PLUG ERP - Business Dashboard

A comprehensive ERP system dashboard to manage Sales, Inventory, Customers, and Finances with role-based access control. Features a modern UI with light and dark modes.

## Features

- **Role-Based Access Control (RBAC)**: Fine-grained permissions for different user roles (Super Admin, Manager, Cashier, etc.).
- **Dashboard**: At-a-glance overview of key performance indicators (KPIs) like revenue, orders, and inventory value.
- **Point of Sale (POS)**: A feature-rich interface for cashiers to conduct sales, with real-time product search and cart management.
- **Inventory Management**: Track product stock, prices, and costs. Add new products and filter by category or stock status.
- **Customer Management**: View customer details, credit limits, and purchase history.
- **Supplier & Purchasing**: Manage suppliers and create/track purchase orders.
- **Systems Management**: A dedicated module for administrators to manage user roles and system settings.
- **Theming**: Switch between a sleek dark mode and a clean light mode.
- **Currency Support**: Switch between multiple currencies (MWK, USD, etc.) with real-time formatting.
- **Responsive Design**: Fully functional on devices of all sizes, from desktops to mobile phones.

## Architecture Overview

The application is built with a modern frontend stack designed for scalability and maintainability.

- **Core Framework**: **React 19** with functional components and hooks.
- **Language**: **TypeScript** for robust type-safety.
- **Styling**: **TailwindCSS** for utility-first styling, combined with a custom theming system for light/dark modes.
- **Routing**: **React Router** (`HashRouter`) for client-side navigation.
- **State Management**: **React Context API** for managing global state like authentication, theme, search, and currency.
- **Data Layer**: A mock data service (`services/mockDataService.ts`) simulates a backend API, providing realistic data and mutation functions.

For a more detailed breakdown, see [ARCHITECTURE.md](ARCHITECTURE.md).

## Folder Structure

The project follows a feature-oriented structure to keep the codebase organized and scalable.

```
/
├── components/         # Reusable React components
│   ├── dashboard/      # Components specific to the Dashboard page
│   ├── inventory/      # Components for Inventory features
│   ├── layout/         # Main layout components (Header, Sidebar)
│   ├── purchasing/     # Components for Purchasing features
│   ├── sales/          # Components for the Point of Sale page
│   ├── suppliers/      # Components for Suppliers features
│   └── ui/             # Generic, reusable UI elements (Card, Modal, Button)
├── constants.ts        # Global constants (menu items, user data)
├── contexts/           # React Context providers for global state
├── hooks/              # Custom React hooks (e.g., useDebounce)
├── pages/              # Top-level page components for each route
├── services/           # Data services (e.g., mockDataService)
├── types.ts            # Global TypeScript type definitions
├── utils/              # Utility functions (e.g., formatters)
├── App.tsx             # Main application component with routing setup
├── index.html          # The main HTML file
└── index.tsx           # The entry point of the React application
```

## Key Concepts

### Mock Data Service

Located in `services/mockDataService.ts`, this service simulates a backend. It generates realistic-looking data on first load and exposes functions to `get`, `add`, and `update` data (e.g., `addProduct`, `addSaleTransaction`, `updateUserRole`). This allows for full-stack style development without needing a live backend.

### Theming

The theme is controlled by `contexts/ThemeContext.tsx`. It provides CSS class sets for both light and dark modes, which are applied throughout the application. This makes it easy to maintain a consistent and visually appealing UI.

### Authentication & Authorization

Authentication is handled by `contexts/AuthContext.tsx`. It manages the `currentUser` and their role. Based on this role, the UI adapts:
- The **Sidebar** (`components/layout/Sidebar.tsx`) filters menu items based on `allowedRoles`.
- Individual pages and components conditionally render elements or disable functionality based on the user's role.
This ensures a secure and context-aware user experience.
