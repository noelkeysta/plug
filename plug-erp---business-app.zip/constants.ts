

import { UserRole, User, Currency, Account, AccountType, Budget, ExpenseCategory } from './types';
import { Layout, Zap, Archive, PieChart, Truck, Users, BarChart, ShoppingCart, SlidersHorizontal, History, DollarSign, FileText, Briefcase, Wrench, ShieldCheck, Settings, Settings2, ClipboardList, Megaphone, Calendar, MessageSquare } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export interface MenuItem {
  id: string;
  label: string;
  icon: LucideIcon;
  path: string;
  allowedRoles: UserRole[];
}

export const ALL_USER_ROLES = Object.values(UserRole);

export const MENU_ITEMS: MenuItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: Layout, path: '/', allowedRoles: ALL_USER_ROLES },
  { id: 'sales', label: 'Point of Sale', icon: Zap, path: '/sales', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.SALES_ASSOCIATE] },
  { id: 'chat', label: 'Chat', icon: MessageSquare, path: '/chat', allowedRoles: ALL_USER_ROLES },
  { id: 'customers', label: 'Customers', icon: Users, path: '/customers', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.SALES_ASSOCIATE] },
  { id: 'inventory', label: 'Inventory', icon: Archive, path: '/inventory', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.IT_MANAGER, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER, UserRole.SALES_MANAGER, UserRole.ACCOUNTANT] },
  { id: 'suppliers', label: 'Suppliers', icon: Truck, path: '/suppliers', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER, UserRole.ACCOUNTANT] },
  { id: 'purchasing', label: 'Purchasing', icon: ShoppingCart, path: '/purchasing', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.INVENTORY_MANAGER] },
  { id: 'requisitions', label: 'Requisitions', icon: ClipboardList, path: '/requisitions', allowedRoles: ALL_USER_ROLES },
  { id: 'scheduling', label: 'Scheduling', icon: Calendar, path: '/scheduling', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER] },
  { id: 'repairs', label: 'Repairs', icon: Wrench, path: '/repairs', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.IT_MANAGER, UserRole.GENERAL_MANAGER]},
  { id: 'warranty', label: 'Warranty', icon: ShieldCheck, path: '/warranty', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.IT_MANAGER, UserRole.GENERAL_MANAGER, UserRole.SALES_ASSOCIATE, UserRole.SALES_MANAGER] },
  { id: 'marketing', label: 'Marketing', icon: Megaphone, path: '/marketing', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.ACCOUNTANT] },
  { id: 'finance', label: 'Finance', icon: PieChart, path: '/finance', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT] },
  { id: 'payroll', label: 'Payroll', icon: Briefcase, path: '/payroll', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.ACCOUNTANT] },
  { id: 'reports', label: 'Reports', icon: BarChart, path: '/reports', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.ACCOUNTANT] },
  { id: 'systems', label: 'Systems', icon: SlidersHorizontal, path: '/systems', allowedRoles: [UserRole.ADMINISTRATOR, UserRole.IT_MANAGER] },
  { id: 'settings', label: 'My Settings', icon: Settings, path: '/settings', allowedRoles: ALL_USER_ROLES },
];

export const USERS_DATA: User[] = [
  { id: 1, name: 'Benjamin Ntekera', employeeId: 'EMP-001', role: UserRole.ADMINISTRATOR, avatar: 'BN', salary: 450000 },
  { id: 2, name: 'The Boy', employeeId: 'EMP-008', role: UserRole.IT_MANAGER, avatar: 'TB', salary: 250000 },
  { id: 3, name: 'Victor Zumazuma', employeeId: 'EMP-002', role: UserRole.GENERAL_MANAGER, avatar: 'VZ', salary: 350000 },
  { id: 4, name: 'Stephen Phiri', employeeId: 'EMP-003', role: UserRole.SALES_MANAGER, avatar: 'SP', salary: 280000 },
  { id: 5, name: 'Praise Kenamu', employeeId: 'EMP-004', role: UserRole.INVENTORY_MANAGER, avatar: 'PK', salary: 220000 },
  { id: 6, name: 'Mayamiko Kamlopa', employeeId: 'EMP-005', role: UserRole.ACCOUNTANT, avatar: 'MK', salary: 300000 },
  { id: 7, name: 'Collen Munyenyembe', employeeId: 'EMP-006', role: UserRole.SALES_ASSOCIATE, avatar: 'CM', salary: 150000 },
  { id: 8, name: 'Cliff Mkandawire', employeeId: 'EMP-007', role: UserRole.SALES_ASSOCIATE, avatar: 'MK', salary: 150000 },
];

export const CURRENCIES: Currency[] = [
    { code: 'MWK', name: 'Malawian Kwacha', symbol: 'MK' },
    { code: 'USD', name: 'US Dollar', symbol: '$' },
    { code: 'EUR', name: 'Euro', symbol: '€' },
    { code: 'GBP', name: 'British Pound', symbol: '£' },
];

export const EXCHANGE_RATES: Record<Currency['code'], number> = {
    'MWK': 1,
    'USD': 1865,
    'EUR': 2000, // Assumed rate
    'GBP': 2200, // Assumed rate
};

export const CHART_OF_ACCOUNTS: Account[] = [
    // Assets
    { id: '1010', name: 'Cash', type: AccountType.ASSET, balance: 0 },
    { id: '1100', name: 'Accounts Receivable', type: AccountType.ASSET, balance: 0 },
    { id: '1200', name: 'Inventory', type: AccountType.ASSET, balance: 0 },
    { id: '1400', name: 'Prepaid Expenses', type: AccountType.ASSET, balance: 0 },
    { id: '1510', name: 'Property, Plant & Equipment', type: AccountType.ASSET, balance: 0 },
    { id: '1590', name: 'Accumulated Depreciation', type: AccountType.ASSET, balance: 0 }, // Contra-asset
    // Liabilities
    { id: '2010', name: 'Bank Loan', type: AccountType.LIABILITY, balance: 0 },
    { id: '2100', name: 'Accounts Payable', type: AccountType.LIABILITY, balance: 0 },
    { id: '2200', name: 'Sales Tax Payable', type: AccountType.LIABILITY, balance: 0 },
    { id: '2300', name: 'Interest Payable', type: AccountType.LIABILITY, balance: 0 },
    { id: '2400', name: 'Warranty Provision', type: AccountType.LIABILITY, balance: 0 },
    { id: '2500', name: 'Income Tax Payable', type: AccountType.LIABILITY, balance: 0 },
    // Equity
    { id: '3000', name: 'Owner\'s Capital', type: AccountType.EQUITY, balance: 0 },
    { id: '3100', name: 'Retained Earnings', type: AccountType.EQUITY, balance: 0 },
    // Revenue
    { id: '4000', name: 'Sales Revenue', type: AccountType.REVENUE, balance: 0 },
    { id: '4100', name: 'Repair Revenue', type: AccountType.REVENUE, balance: 0 },
    // Cost of Goods Sold
    { id: '5000', name: 'Cost of Goods Sold', type: AccountType.COST_OF_GOODS_SOLD, balance: 0 },
    // Expenses
    { id: '6010', name: 'Salaries Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6020', name: 'Rent Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6030', name: 'Utilities Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6040', name: 'Marketing Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6050', name: 'Office Supplies Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6060', name: 'Repairs & Maintenance', type: AccountType.EXPENSE, balance: 0 },
    { id: '6065', name: 'Fuel & Transportation', type: AccountType.EXPENSE, balance: 0 },
    { id: '6070', name: 'Interest Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6080', name: 'Depreciation Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6090', name: 'Warranty Claims Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6100', name: 'Bank & Loan Fees', type: AccountType.EXPENSE, balance: 0 },
    { id: '6800', name: 'Income Tax Expense', type: AccountType.EXPENSE, balance: 0 },
    { id: '6900', name: 'Other Expense', type: AccountType.EXPENSE, balance: 0 },
];

export const BUDGET_DATA: Budget[] = [
    { category: 'Salaries', amount: 8000000 },
    { category: ExpenseCategory.RENT, amount: 1000000 },
    { category: ExpenseCategory.UTILITIES, amount: 400000 },
    { category: ExpenseCategory.MARKETING, amount: 500000 },
    { category: ExpenseCategory.SUPPLIES, amount: 200000 },
    { category: ExpenseCategory.REPAIRS, amount: 150000 },
    { category: ExpenseCategory.FUEL_TRANSPORTATION, amount: 1000000 },
    { category: ExpenseCategory.WARRANTY_CLAIMS, amount: 1200000 },
    { category: ExpenseCategory.OTHER, amount: 100000 },
];
