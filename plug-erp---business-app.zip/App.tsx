
import React, { useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { DataProvider, useData } from './contexts/DataContext';
import { SearchProvider } from './contexts/SearchContext';
import { CurrencyProvider } from './contexts/CurrencyContext';
import { SettingsProvider } from './contexts/SettingsContext';
import { NotificationProvider, useNotifier } from './contexts/NotificationContext';
import { DashboardSettingsProvider } from './contexts/DashboardSettingsContext';
import { Toaster } from 'react-hot-toast';
import MainLayout from './components/layout/MainLayout';
import ProtectedRoute from './components/auth/ProtectedRoute';
import DashboardPage from './pages/DashboardPage';
import InventoryPage from './pages/InventoryPage';
import CustomersPage from './pages/CustomersPage';
import SuppliersPage from './pages/SuppliersPage';
import PurchasingPage from './pages/PurchasingPage';
import SalesPage from './pages/SalesPage';
import SystemsPage from './pages/SystemsPage';
import FinancePage from './pages/FinancePage';
import PayrollPage from './pages/PayrollPage';
import ReportsPage from './pages/ReportsPage';
import RepairsPage from './pages/RepairsPage';
import WarrantyPage from './pages/WarrantyPage';
import NotFoundPage from './pages/NotFoundPage';
import LoginPage from './pages/LoginPage';
import SettingsPage from './pages/SettingsPage';
import NotificationsPage from './pages/NotificationsPage';
import RequisitionsPage from './pages/RequisitionsPage';
import MarketingPage from './pages/MarketingPage';
import SchedulingPage from './pages/SchedulingPage';
import ChatPage from './pages/ChatPage';
import { sendMessage } from './services/mockDataService';

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <DataProvider>
        <AuthProvider>
          <SettingsProvider>
            <CurrencyProvider>
              <SearchProvider>
                <DashboardSettingsProvider>
                  <NotificationProvider>
                    <AppContent />
                  </NotificationProvider>
                </DashboardSettingsProvider>
              </SearchProvider>
            </CurrencyProvider>
          </SettingsProvider>
        </AuthProvider>
      </DataProvider>
    </ThemeProvider>
  );
};

const AppContent: React.FC = () => {
  const { themeClasses, isDarkMode } = useTheme();
  const { currentUser } = useAuth();
  const { data, refreshData } = useData();
  const { notifyInfo } = useNotifier();
  const location = useLocation();

  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
        root.classList.add('dark');
        root.classList.remove('light');
    } else {
        root.classList.add('light');
        root.classList.remove('dark');
    }
  }, [isDarkMode]);

  useEffect(() => {
    if (!currentUser || !data || location.pathname.startsWith('/chat')) {
        return;
    }

    const intervalId = setInterval(() => {
        const { conversations, users } = data;
        const myConversations = conversations.filter(c => c.participants.includes(currentUser.id));
        if (myConversations.length === 0) return;
        
        const targetConversations = myConversations.filter(c => c.participants.length > 1);
        if(targetConversations.length === 0) return;

        if (Math.random() > 0.3) return; // 30% chance each 15 seconds

        const conversation = targetConversations[Math.floor(Math.random() * targetConversations.length)];
        const otherParticipants = conversation.participants.filter(pId => pId !== currentUser.id);
        const sender = users.find(u => u.id === otherParticipants[Math.floor(Math.random() * otherParticipants.length)]);
        
        if (sender) {
            const messages = ["Hey, are you free to look at this?", "Just checking in.", "Got a minute?", "Can I get your opinion on something?", "Did you see the latest report?"];
            const randomMessage = messages[Math.floor(Math.random() * messages.length)];
            
            sendMessage(sender.id, conversation.id, { text: randomMessage });
            refreshData();
            notifyInfo(`${sender.name} sent you a message.`);
        }

    }, 15000); // every 15 seconds

    return () => clearInterval(intervalId);

  }, [currentUser, data, refreshData, notifyInfo, location.pathname]);


  return (
    <div className={`min-h-screen ${themeClasses.main} transition-colors duration-500`}>
      <Toaster
        position="bottom-right"
        toastOptions={{
          duration: 5000,
          style: {
            background: isDarkMode ? 'rgba(30, 41, 59, 0.8)' : 'rgba(255, 255, 255, 0.8)',
            color: isDarkMode ? '#f8fafc' : '#0f172a',
            backdropFilter: 'blur(10px)',
            border: `1px solid ${isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'}`,
            borderRadius: '1.5rem',
            padding: '1rem 1.5rem',
            boxShadow: `0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)`
          },
          success: {
            iconTheme: {
              primary: '#2dd4bf', // teal-400
              secondary: isDarkMode ? '#0f172a' : '#ffffff',
            },
          },
          error: {
            iconTheme: {
              primary: '#f472b6', // pink-400
              secondary: isDarkMode ? '#0f172a' : '#ffffff',
            },
          },
        }}
      />
      
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
            <Route index element={<DashboardPage />} />
            <Route path="inventory" element={<InventoryPage />} />
            <Route path="customers" element={<CustomersPage />} />
            <Route path="suppliers" element={<SuppliersPage />} />
            <Route path="purchasing" element={<PurchasingPage />} />
            <Route path="requisitions" element={<RequisitionsPage />} />
            <Route path="scheduling" element={<SchedulingPage />} />
            <Route path="sales" element={<SalesPage />} />
            <Route path="chat/:conversationId?" element={<ChatPage />} />
            <Route path="repairs" element={<RepairsPage />} />
            <Route path="warranty" element={<WarrantyPage />} />
            <Route path="marketing" element={<MarketingPage />} />
            <Route path="systems" element={<SystemsPage />} />
            <Route path="finance" element={<FinancePage />} />
            <Route path="payroll" element={<PayrollPage />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route path="notifications" element={<NotificationsPage />} />
            <Route path="settings" element={<SettingsPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      
    </div>
  );
};

const Root: React.FC = () => (
    <HashRouter>
        <App />
    </HashRouter>
);

export default Root;
