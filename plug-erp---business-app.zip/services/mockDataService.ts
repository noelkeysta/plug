
import { Product, Customer, Supplier, Transaction, TransactionType, User, PurchaseOrder, PurchaseOrderStatus, UserRole, Expense, ExpenseCategory, AuditLog, LogAction, AppSettings, RepairJob, RepairStatus, DataSnapshot, InventoryItem, LedgerEntry, Account, Notification, NotificationType, Budget, Requisition, RequisitionType, RequisitionStatus, MarketingCampaign, MarketingCampaignStatus, Shift, PayrollRun, Conversation, Message, MessageStatus } from '../types';
import { USERS_DATA, CURRENCIES, CHART_OF_ACCOUNTS, BUDGET_DATA } from '../constants';
import { format, differenceInMonths, addMonths, getYear, getMonth, isAfter, addDays, getDaysInMonth, isBefore, isSameDay, getDate, getDay, isLastDayOfMonth, endOfDay, eachDayOfInterval, addHours } from 'date-fns';
import set from 'date-fns/set';
import startOfDay from 'date-fns/startOfDay';
import sub from 'date-fns/sub';
import { formatCurrency } from '../utils/formatters';

const STORAGE_KEY = 'PLUG_ERP_DATA_V15_NEW_MODULES';
export const NOW = new Date('2025-07-18T10:00:00Z');
export const STARTUP_DATE = new Date('2024-06-01T08:00:00Z');

// --- Data Generation & Simulation ---
const malawianFirstNames = ['Chisomo', 'Thoko', 'Madalitso', 'Tiwonge', 'Limbani', 'Kondwani', 'Tapiwa', 'Mayamiko', 'Blessings', 'Hope', 'Precious', 'Gift', 'Frank', 'John', 'Peter', 'James', 'David', 'Grace', 'Mary', 'Esther', 'Martha', 'Sarah', 'Joseph', 'Samuel', 'Daniel', 'Fatima', 'Aisha', 'Yusuf', 'Mike', 'Steve'];
const malawianLastNames = ['Banda', 'Phiri', 'Kachale', 'Mwale', 'Nkhoma', 'Gama', 'Moyo', 'Chirwa', 'Kamanga', 'Kumwenda', 'Chavula', 'Mvula', 'Ngwira', 'Jere', 'Tembo', 'Lungu', 'Zimba', 'Nyirenda', 'Mhango', 'Soko', 'Mbewe', 'Chulu', 'Mithi', 'Patel', 'Gondwe'];

const generatePhoneNumber = () => {
    const prefixes = ['088', '099', '089'];
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const number = Math.floor(1000000 + Math.random() * 9000000).toString().substring(1);
    return `${prefix}${number}`;
};

const generateCustomers = (): Customer[] => {
    const customers: Customer[] = [];
    let customerIdCounter = 1;
    for (let i = 0; i < 100; i++) {
        const firstName = malawianFirstNames[Math.floor(Math.random() * malawianFirstNames.length)];
        const lastName = malawianLastNames[Math.floor(Math.random() * malawianLastNames.length)];
        const name = `${firstName} ${lastName}`;
        customers.push({
            id: customerIdCounter++,
            name: name,
            email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}${Math.floor(Math.random()*100)}@example.com`,
            phone: generatePhoneNumber(),
            tier: Math.random() > 0.9 ? 'VIP' : 'Regular',
            creditLimit: Math.random() > 0.8 ? 500000 : 0,
            creditUsed: 0,
            joinDate: sub(NOW, { days: Math.floor(Math.random() * 365) }),
        });
    }
    customers.push({ id: 101, name: 'Blantyre University', email: 'procurement@blantyre.ac.mw', phone: '0111222333', tier: 'VIP', creditLimit: 5000000, creditUsed: 0, joinDate: new Date('2024-10-01') });
    customers.push({ id: 102, name: 'Chisomo Innovations', email: 'accounts@chisomo.com', phone: '0999888777', tier: 'Regular', creditLimit: 1000000, creditUsed: 0, joinDate: new Date('2024-08-15') });
    customers.push({ id: 103, name: 'Walk-in Customer', email: 'n/a', phone: 'n/a', tier: 'Walk-in', creditLimit: 0, creditUsed: 0, joinDate: new Date('2024-06-01') });
    return customers;
};


const suppliersData: Supplier[] = [
  { id: 1, name: 'Plug Tech International', contact: 'sales@plugtech.com' }, { id: 2, name: 'Bovin Electronics', contact: 'contact@bovin.co' }, { id: 3, name: 'eBay Business', contact: 'support@ebaybusiness.com' }, { id: 4, name: 'Amazon Business', contact: 'sales@amazonbusiness.com' }, { id: 5, name: 'Alibaba B2B', contact: 'orders@alibaba.com' }, { id: 6, name: 'China B2B Direct', contact: 'wholesale@chinadirect.com' }, { id: 7, name: 'Malawi Electronics Distributors', contact: 'info@mwelectronics.mw' }, { id: 8, name: 'South African Distributors', contact: 'query@sadistro.co.za' },
];

const productsTemplate: Omit<Product, 'id'>[] = [
  { name: 'Tecno Spark 10', category: 'Smartphones', price: 162000, cost: 108540, supplierId: 5, image: 'https://picsum.photos/seed/p1/200/200' }, { name: 'Itel A58 Pro', category: 'Smartphones', price: 175000, cost: 117250, supplierId: 5, image: 'https://picsum.photos/seed/p2/200/200' }, { name: 'Samsung A14', category: 'Smartphones', price: 280000, cost: 187600, supplierId: 1, image: 'https://picsum.photos/seed/p3/200/200' }, { name: 'Infinix Hot 12', category: 'Smartphones', price: 195000, cost: 130650, supplierId: 5, image: 'https://picsum.photos/seed/p4/200/200' }, { name: 'iPhone 12', category: 'Smartphones', price: 1650000, cost: 1105500, supplierId: 1, image: 'https://picsum.photos/seed/p5/200/200' }, { name: 'iPhone 13', category: 'Smartphones', price: 1910000, cost: 1279700, supplierId: 1, image: 'https://picsum.photos/seed/p6/200/200' }, { name: 'iPhone 14', category: 'Smartphones', price: 2200000, cost: 1474000, supplierId: 1, image: 'https://picsum.photos/seed/p7/200/200' }, { name: 'iPhone 11 (Refurb)', category: 'Smartphones', price: 825000, cost: 552750, supplierId: 3, image: 'https://picsum.photos/seed/p8/200/200' }, { name: 'iPhone 12 (Refurb)', category: 'Smartphones', price: 1028000, cost: 688760, supplierId: 3, image: 'https://picsum.photos/seed/p9/200/200' }, { name: 'Samsung S21 (Refurb)', category: 'Smartphones', price: 650000, cost: 435500, supplierId: 2, image: 'https://picsum.photos/seed/p10/200/200' }, { name: 'HP 14" Essential', category: 'Laptops', price: 580000, cost: 388600, supplierId: 1, image: 'https://picsum.photos/seed/p11/200/200' }, { name: 'Acer Aspire 3', category: 'Laptops', price: 692000, cost: 463640, supplierId: 1, image: 'https://picsum.photos/seed/p12/200/200' }, { name: 'Lenovo IdeaPad 1', category: 'Laptops', price: 636000, cost: 426120, supplierId: 1, image: 'https://picsum.photos/seed/p13/200/200' }, { name: 'HP EliteBook (Refurb)', category: 'Laptops', price: 875000, cost: 586250, supplierId: 3, image: 'https://picsum.photos/seed/p14/200/200' }, { name: 'Dell Latitude (Refurb)', category: 'Laptops', price: 995000, cost: 666650, supplierId: 3, image: 'https://picsum.photos/seed/p15/200/200' }, { name: 'Lenovo ThinkPad (Refurb)', category: 'Laptops', price: 1085000, cost: 726950, supplierId: 3, image: 'https://picsum.photos/seed/p16/200/200' }, { name: 'PS4 Slim (New)', category: 'Gaming Consoles', price: 875000, cost: 586250, supplierId: 1, image: 'https://picsum.photos/seed/p17/200/200' }, { name: 'PS4 Pro (New)', category: 'Gaming Consoles', price: 1085000, cost: 726950, supplierId: 1, image: 'https://picsum.photos/seed/p18/200/200' }, { name: 'PS5 Standard', category: 'Gaming Consoles', price: 1382000, cost: 925940, supplierId: 1, image: 'https://picsum.photos/seed/p19/200/200' }, { name: 'PS4 (Refurb)', category: 'Gaming Consoles', price: 580000, cost: 388600, supplierId: 3, image: 'https://picsum.photos/seed/p20/200/200' }, { name: 'Xbox One S', category: 'Gaming Consoles', price: 692000, cost: 463640, supplierId: 1, image: 'https://picsum.photos/seed/p21/200/200' }, { name: 'Xbox Series S', category: 'Gaming Consoles', price: 875000, cost: 586250, supplierId: 1, image: 'https://picsum.photos/seed/p22/200/200' }, { name: 'Xbox Series X', category: 'Gaming Consoles', price: 1382000, cost: 925940, supplierId: 1, image: 'https://picsum.photos/seed/p23/200/200' }, { name: 'Phone Case', category: 'Accessories', price: 13000, cost: 8710, supplierId: 6, image: 'https://picsum.photos/seed/p24/200/200' }, { name: 'Fast Charger', category: 'Accessories', price: 32500, cost: 21775, supplierId: 4, image: 'https://picsum.photos/seed/p25/200/200' }, { name: 'Power Bank 10000mAh', category: 'Accessories', price: 57500, cost: 38525, supplierId: 4, image: 'https://picsum.photos/seed/p26/200/200' }, { name: 'Bluetooth Headphones', category: 'Accessories', price: 91000, cost: 60970, supplierId: 2, image: 'https://picsum.photos/seed/p27/200/200' }, { name: 'Gaming Controller', category: 'Accessories', price: 161000, cost: 107870, supplierId: 4, image: 'https://picsum.photos/seed/p28/200/200' }, { name: 'Screen Protector', category: 'Accessories', price: 8000, cost: 5360, supplierId: 7, image: 'https://picsum.photos/seed/p29/200/200' }, { name: 'Laptop Bag', category: 'Accessories', price: 45000, cost: 30150, supplierId: 7, image: 'https://picsum.photos/seed/p30/200/200' }, { name: 'Repair Service', category: 'Repairs', price: 50000, cost: 15000, supplierId: 1, image: 'https://picsum.photos/seed/p31/200/200' },
];

const generateSerialNumber = (productId: string) => `SN-${productId}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

const jsonDateReviver = (key: string, value: any) => {
    const isoDateRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/;
    if (typeof value === 'string' && isoDateRegex.test(value)) return new Date(value);
    return value;
};

// --- Accounting Helpers ---
let ledgerIdCounter = 1;
let batchIdCounter = 1;
const generateBatchId = () => `B${1000 + batchIdCounter++}`;

const createLedgerEntry = (ledger: LedgerEntry[], debitAccountId: string, creditAccountId: string, amount: number, description: string, transactionId?: number | string, timestamp: Date = NOW, batchId?: string) => {
    const finalBatchId = batchId || generateBatchId();
    ledger.push({ id: ledgerIdCounter++, accountId: debitAccountId, amount: amount, timestamp, description, transactionId, relatedAccountId: creditAccountId, batchId: finalBatchId });
    ledger.push({ id: ledgerIdCounter++, accountId: creditAccountId, amount: -amount, timestamp, description, transactionId, relatedAccountId: debitAccountId, batchId: finalBatchId });
};

// --- Notification Helper ---
let notificationIdCounter = 1;
const addNotification = (notifications: Notification[], type: NotificationType, message: string, relatedId?: string | number, actorName?: string) => {
    notifications.unshift({ id: notificationIdCounter++, type, message, timestamp: NOW, isRead: false, relatedId, actorName });
};


const initializeBusinessData = (): DataSnapshot => {
    // --- Financial Model Constants ---
    const OWNER_EQUITY_CASH = 23_000_000;
    const OWNER_EQUITY_VEHICLE = 6_500_000;
    const LOAN_PRINCIPAL = 30_000_000;
    const INITIAL_INVENTORY_COST = 50_000_000; // Increased from 40M
    const STORE_EQUIPMENT_COST = 2_850_000;
    const LOAN_FEE = 1_350_000;
    const ANNUAL_DEPRECIATION = 1_870_000;
    const MONTHLY_DEPRECIATION = ANNUAL_DEPRECIATION / 12;
    const LOAN_INTEREST_RATE_ANNUAL = 0.048;
    const LOAN_INTEREST_RATE_MONTHLY = LOAN_INTEREST_RATE_ANNUAL / 12;
    const LOAN_TERM_MONTHS = 24;
    const LOAN_FEE_AMORTIZATION_MONTHLY = LOAN_FEE / LOAN_TERM_MONTHS;

    const financialYearOneTargets = [
        21626552, 23789207, 26168128, 28784941, 31663435, 34829778,
        37267663, 39876399, 42667747, 45654689, 48850517, 52270053,
    ];
    
    // --- Initial Setup ---
    const customersData = generateCustomers();
    const products: Product[] = productsTemplate.map((p, i) => ({ ...p, id: `P${1001 + i}` }));
    const inventoryItems: InventoryItem[] = [];
    const expenses: Expense[] = [];
    let expenseIdCounter = 10001;
    const transactions: Transaction[] = [];
    let transactionIdCounter = 8001;
    const purchaseOrders: PurchaseOrder[] = [];
    let poIdCounter = 2000;
    const accounts: Account[] = JSON.parse(JSON.stringify(CHART_OF_ACCOUNTS));
    const ledger: LedgerEntry[] = [];
    const notifications: Notification[] = [];
    const settings: AppSettings = { companyName: 'Plug Play Tech', defaultCurrency: 'MWK', taxRate: 16.5, incomeTaxRate: 30, address: 'Blantyre, Malawi', markupPercentage: 50 };
    const startupDate = STARTUP_DATE;
    const requisitions: Requisition[] = [];
    let requisitionIdCounter = 1;
    const marketingCampaigns: MarketingCampaign[] = [];
    let marketingCampaignIdCounter = 1;
    const payrollRuns: PayrollRun[] = [];
    let payrollRunIdCounter = 1;
    const shifts: Shift[] = [];
    let shiftIdCounter = 1;
    const conversations: Conversation[] = [];
    const messages: Message[] = [];
    let conversationIdCounter = 1;
    let messageIdCounter = 1;
    
    const accountantUser = USERS_DATA.find(u => u.role === UserRole.ACCOUNTANT)!;
    const inventoryManagerUser = USERS_DATA.find(u => u.role === UserRole.INVENTORY_MANAGER)!;
    const generalManagerUser = USERS_DATA.find(u => u.role === UserRole.GENERAL_MANAGER)!;
    const itManagerUser = USERS_DATA.find(u => u.role === UserRole.IT_MANAGER)!;
    const adminUser = USERS_DATA.find(u => u.role === UserRole.ADMINISTRATOR)!;
    
    // --- INITIAL CHAT DATA ---
    // DM between admin and GM
    const conv1Id = `C${conversationIdCounter++}`;
    const msg1Timestamp = sub(NOW, { days: 2, hours: 1 });
    const msg2Timestamp = sub(NOW, { days: 2, hours: 1, minutes: 1 });
    conversations.push({
        id: conv1Id, type: 'direct', participants: [adminUser.id, generalManagerUser.id],
        createdAt: sub(NOW, { days: 2 }), unreadCounts: { [adminUser.id]: 2, [generalManagerUser.id]: 0 },
        lastMessage: { text: 'I think there might be a discrepancy in the numbers.', timestamp: msg2Timestamp, senderId: generalManagerUser.id }
    });
    messages.push({ id: `M${messageIdCounter++}`, conversationId: conv1Id, senderId: generalManagerUser.id, text: 'Hey Ben, can you look at the Q2 sales report?', timestamp: msg1Timestamp, status: MessageStatus.READ });
    messages.push({ id: `M${messageIdCounter++}`, conversationId: conv1Id, senderId: generalManagerUser.id, text: 'I think there might be a discrepancy in the numbers.', timestamp: msg2Timestamp, status: MessageStatus.READ });

    // Group chat for managers
    const managerIds = USERS_DATA.filter(u => [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER, UserRole.INVENTORY_MANAGER, UserRole.ACCOUNTANT].includes(u.role)).map(u => u.id);
    const unreadCountsGroup = managerIds.reduce((acc, id) => ({...acc, [id]: id === adminUser.id ? 0 : 1}), {});
    const conv2Id = `C${conversationIdCounter++}`;
    const msg3Timestamp = sub(NOW, { hours: 5 });
    conversations.push({
        id: conv2Id, type: 'group', name: 'Management Team', participants: managerIds, creatorId: adminUser.id,
        createdAt: sub(NOW, { days: 5 }), unreadCounts: unreadCountsGroup,
        lastMessage: { text: 'Team, let\'s sync up tomorrow at 10 AM to discuss Q3 planning.', timestamp: msg3Timestamp, senderId: generalManagerUser.id }
    });
    messages.push({ id: `M${messageIdCounter++}`, conversationId: conv2Id, senderId: generalManagerUser.id, text: 'Team, let\'s sync up tomorrow at 10 AM to discuss Q3 planning.', timestamp: msg3Timestamp, status: MessageStatus.SENT });


    // 1a. Requisition for initial store equipment
    const storeEquipReqId = requisitionIdCounter++;
    const equipExpenseId = expenseIdCounter++;
    const storeEquipRequisition: Requisition = {
        id: storeEquipReqId,
        requesterId: generalManagerUser.id,
        type: RequisitionType.ASSET,
        status: RequisitionStatus.COMPLETED, // Pre-approved and completed
        items: [{ description: 'Store setup & equipment', quantity: 1, estimatedCost: STORE_EQUIPMENT_COST }],
        totalEstimatedCost: STORE_EQUIPMENT_COST,
        description: 'Initial purchase of store setup and necessary equipment.',
        createdAt: startupDate,
        approverId: generalManagerUser.id,
        approvedAt: startupDate,
    };
    requisitions.push(storeEquipRequisition);
    expenses.push({
        id: equipExpenseId,
        description: 'Purchase of store setup & equipment',
        category: ExpenseCategory.ASSET_PURCHASE,
        amount: STORE_EQUIPMENT_COST,
        date: startupDate,
        recordedById: generalManagerUser.id,
        requisitionId: storeEquipReqId
    });

    // 1. Initial Journal Entries for Capital and Asset Allocation
    const capitalBatch = generateBatchId();
    createLedgerEntry(ledger, '1010', '3000', OWNER_EQUITY_CASH, "Owner's cash capital injection", undefined, startupDate, capitalBatch);
    createLedgerEntry(ledger, '1510', '3000', OWNER_EQUITY_VEHICLE, "Owner's vehicle contribution (in-kind)", undefined, startupDate, capitalBatch);
    createLedgerEntry(ledger, '1010', '2010', LOAN_PRINCIPAL, 'Bank loan received', undefined, startupDate);
    createLedgerEntry(ledger, '1200', '1010', INITIAL_INVENTORY_COST, 'Initial inventory purchase', undefined, startupDate);
    createLedgerEntry(ledger, '1510', '1010', STORE_EQUIPMENT_COST, 'Purchase of store setup & equipment', equipExpenseId, startupDate);
    createLedgerEntry(ledger, '1400', '1010', LOAN_FEE, 'Loan processing fee paid', 'EXP-INIT-FEE', startupDate);

    // 2. Populate initial inventory based on cost
    const physicalProducts = products.filter(p => p.category !== 'Repairs');
    let currentInventoryValue = 0;
    while(currentInventoryValue < INITIAL_INVENTORY_COST) {
        const product = physicalProducts[Math.floor(Math.random() * physicalProducts.length)];
        if(currentInventoryValue + product.cost <= INITIAL_INVENTORY_COST) {
            inventoryItems.push({ id: generateSerialNumber(product.id), productId: product.id, cost: product.cost, status: 'available', addedAt: startupDate });
            currentInventoryValue += product.cost;
        } else {
            break; 
        }
    }

    // --- Daily Simulation Engine ---
    const simulationEndDate = NOW;
    
    let monthRevenue = 0;
    let monthCogs = 0;
    let lastMonthRevenue = 0;
    let monthRevenueTarget = 0;
    let remainingLoanBalance = LOAN_PRINCIPAL;

    const generateSalesForDay = (date: Date, revenueTarget: number, unitsTarget: number) => {
        let dailyRevenue = 0;
        let dailyCogs = 0;
        let unitsSold = 0;
        const cashiers = USERS_DATA.filter(u => [UserRole.SALES_ASSOCIATE, UserRole.SALES_MANAGER, UserRole.ADMINISTRATOR].includes(u.role));
        const regularCustomers = customersData.filter(c => c.tier !== 'Walk-in');
        const walkInCustomer = customersData.find(c => c.tier === 'Walk-in')!;
        
        while ((dailyRevenue < revenueTarget || unitsSold < unitsTarget) || unitsSold === 0 && revenueTarget > 0) {
            const availableItems = inventoryItems.filter(item => item.status === 'available');
            if (availableItems.length === 0) {
                if (unitsSold > 0) break; 
                console.warn(`Stockout on ${format(date, 'yyyy-MM-dd')}. Cannot meet sales target.`);
                break;
            }
            const itemToSell = availableItems[Math.floor(Math.random() * availableItems.length)];
            const product = products.find(p => p.id === itemToSell.productId)!;
            if (dailyRevenue + product.price > revenueTarget * 1.5 && unitsSold >= unitsTarget) break;
            
            const itemIndex = inventoryItems.findIndex(i => i.id === itemToSell.id);
            // Assign more sales to registered customers
            const customerForSale = Math.random() < 0.3 ? walkInCustomer : regularCustomers[Math.floor(Math.random() * regularCustomers.length)];

            if(itemIndex > -1){
                inventoryItems[itemIndex].status = 'sold';
                inventoryItems[itemIndex].soldAt = date;
                inventoryItems[itemIndex].soldToCustomerId = customerForSale.id;
            }

            const preTaxTotal = product.price;
            const taxAmount = preTaxTotal * (settings.taxRate / 100);
            
            const saleBatchId = generateBatchId();
            transactions.unshift({ id: transactionIdCounter, type: TransactionType.SALE, items: [{ productId: product.id, serialNumber: itemToSell.id, price: product.price, originalPrice: product.price }], totalAmount: preTaxTotal + taxAmount, timestamp: date, cashierId: cashiers[Math.floor(Math.random() * cashiers.length)].id, customerId: customerForSale.id, paymentMethod: 'Cash' });
            createLedgerEntry(ledger, '1010', '4000', preTaxTotal, `Revenue from Sale #${transactionIdCounter}`, transactionIdCounter, date, saleBatchId);
            createLedgerEntry(ledger, '1010', '2200', taxAmount, `Tax for Sale #${transactionIdCounter}`, transactionIdCounter, date, saleBatchId);
            createLedgerEntry(ledger, '5000', '1200', itemToSell.cost, `COGS for Sale #${transactionIdCounter}`, transactionIdCounter, date, saleBatchId);
            
            dailyRevenue += preTaxTotal;
            dailyCogs += itemToSell.cost;
            unitsSold++;
            transactionIdCounter++;
            if (unitsSold === 1 && revenueTarget === 0) break; // Ensure at least one sale on days with no target
        }
        return { dailyRevenue, dailyCogs };
    };
    
    const averageProductPrice = products.filter(p => p.category !== 'Repairs').reduce((sum, p) => sum + p.price, 0) / products.filter(p => p.category !== 'Repairs').length;

    let currentDate = startupDate;
    while (isBefore(currentDate, simulationEndDate) || isSameDay(currentDate, simulationEndDate)) {
        // --- Synchronous PO Status Update Simulation ---
        purchaseOrders.forEach(po => {
            if (po.status === PurchaseOrderStatus.PENDING && (isAfter(currentDate, addDays(po.orderDate, 2)) || isSameDay(currentDate, addDays(po.orderDate, 2)))) {
                po.status = PurchaseOrderStatus.SHIPPED;
            }

            if (po.status === PurchaseOrderStatus.SHIPPED && (isAfter(currentDate, po.expectedDeliveryDate) || isSameDay(currentDate, po.expectedDeliveryDate))) {
                const alreadyReceived = inventoryItems.some(item => item.purchaseOrderId === po.id);
                if (!alreadyReceived) {
                    po.status = PurchaseOrderStatus.RECEIVED;
                    
                    let purchasedValue = 0;
                    const inventoryToPurchase = po.totalCost;
                    
                    while (purchasedValue < inventoryToPurchase) {
                        const product = physicalProducts[Math.floor(Math.random() * physicalProducts.length)];
                        if (purchasedValue + product.cost <= inventoryToPurchase) {
                            inventoryItems.push({
                                id: generateSerialNumber(product.id),
                                productId: product.id,
                                cost: product.cost,
                                status: 'available',
                                addedAt: currentDate,
                                purchaseOrderId: po.id
                            });
                            purchasedValue += product.cost;
                        } else {
                            break;
                        }
                    }
                    createLedgerEntry(ledger, '1200', '2100', purchasedValue, `Received PO ${po.id}`, po.id, currentDate);
                }
            }
        });

        const dayOfMonth = getDate(currentDate);
        const monthOfSim = differenceInMonths(currentDate, startupDate);

        if (dayOfMonth === 1) {
            lastMonthRevenue = monthRevenue;
            monthRevenue = 0;
            monthCogs = 0;
            
            if (monthOfSim < 12) monthRevenueTarget = financialYearOneTargets[monthOfSim];
            else monthRevenueTarget = monthRevenueTarget * 1.05;
        }
        
        // --- Proactive Monthly Inventory Replenishment via Requisition ---
        if (dayOfMonth === 2 && monthOfSim > 0) { 
            const projectedCogs = monthRevenueTarget * 0.67;
            const currentStockValue = inventoryItems.filter(i => i.status === 'available').reduce((sum, i) => sum + i.cost, 0);
            const targetInventoryValue = projectedCogs * 2.5;
            const inventoryToPurchase = Math.max(0, targetInventoryValue - currentStockValue);

            if (inventoryToPurchase > 0) {
                 const reqId = requisitionIdCounter++;
                 const newPoId = `PO-${poIdCounter++}`;
                 const requisition: Requisition = {
                    id: reqId,
                    requesterId: inventoryManagerUser.id,
                    type: RequisitionType.INVENTORY,
                    status: RequisitionStatus.ORDERED,
                    items: [{ description: 'Monthly Stock Replenishment', quantity: 1, estimatedCost: inventoryToPurchase, }],
                    totalEstimatedCost: inventoryToPurchase,
                    description: `Monthly stock replenishment for ${format(currentDate, 'MMMM yyyy')}`,
                    createdAt: currentDate,
                    approverId: generalManagerUser.id,
                    approvedAt: addDays(currentDate, 1),
                    relatedPOId: newPoId
                 };
                 requisitions.push(requisition);
                 
                 const newOrder: PurchaseOrder = {
                     id: newPoId,
                     supplierId: 1,
                     totalCost: inventoryToPurchase,
                     orderDate: addDays(currentDate, 1),
                     expectedDeliveryDate: addDays(currentDate, 15),
                     status: PurchaseOrderStatus.PENDING,
                     requisitionId: reqId,
                     items: [{ productId: 'BULK', quantity: 1, cost: inventoryToPurchase }]
                 };
                 purchaseOrders.push(newOrder);
            }
        }

        let dailyRevenueTarget = 0, dailyUnitsTarget = 0;
        const daysInMonth = getDaysInMonth(currentDate);
        let dailyBaseRevenue = monthRevenueTarget / daysInMonth;
        const dayOfWeek = getDay(currentDate);
        if (dayOfWeek >= 4 && dayOfWeek <= 6) dailyBaseRevenue *= 1.2;
        if (dayOfWeek === 0) dailyBaseRevenue *= 0.8;
        dailyRevenueTarget = dailyBaseRevenue;

        dailyUnitsTarget = Math.max(1, Math.round(dailyRevenueTarget / (averageProductPrice > 0 ? averageProductPrice : 150000)));

        const { dailyRevenue, dailyCogs } = generateSalesForDay(currentDate, dailyRevenueTarget, dailyUnitsTarget);
        monthRevenue += dailyRevenue;
        monthCogs += dailyCogs;

        // --- SPECIFIC & RECURRING TASKS ---
        if(isSameDay(currentDate, new Date('2024-06-01Z'))) {
            const campaign: MarketingCampaign = {id: marketingCampaignIdCounter++, name: 'Grand Opening Promotion', type: 'Local Ad', status: MarketingCampaignStatus.COMPLETED, budget: 500000, actualSpend: 500000, startDate: sub(currentDate, {days: 2}), endDate: currentDate, description: 'Initial marketing push for store opening.', createdById: accountantUser.id };
            marketingCampaigns.push(campaign);
            expenses.push({ id: expenseIdCounter++, description: 'Grand Opening Promotion', category: ExpenseCategory.MARKETING, amount: 500000, date: currentDate, recordedById: accountantUser.id });
            createLedgerEntry(ledger, '6040', '1010', 500000, 'Grand Opening Promotion', expenseIdCounter - 1, currentDate);
        }
        if(isSameDay(currentDate, new Date('2024-06-22Z'))) {
            const marketingReqId = requisitionIdCounter++;
            const marketingRequisition: Requisition = {
                id: marketingReqId,
                requesterId: accountantUser.id,
                type: RequisitionType.EXPENSE,
                status: RequisitionStatus.COMPLETED, // Pre-approved and completed
                items: [{ description: 'Week 4 Social Media Campaign', quantity: 1, estimatedCost: 200000 }],
                totalEstimatedCost: 200000,
                description: 'Funding for targeted ads on social platforms.',
                createdAt: currentDate,
                approverId: generalManagerUser.id,
                approvedAt: currentDate,
            };
            requisitions.push(marketingRequisition);
            
             const campaign: MarketingCampaign = {id: marketingCampaignIdCounter++, name: 'Week 4 Social Media Campaign', type: 'Social Media', status: MarketingCampaignStatus.COMPLETED, budget: 200000, actualSpend: 200000, startDate: currentDate, endDate: addDays(currentDate, 7), description: 'Targeted ads on social platforms.', createdById: accountantUser.id };
             marketingCampaigns.push(campaign);

            const marketingExpenseId = expenseIdCounter++;
            expenses.push({ id: marketingExpenseId, description: 'Week 4 Social Media Campaign', category: ExpenseCategory.MARKETING, amount: 200000, date: currentDate, recordedById: accountantUser.id, requisitionId: marketingReqId });
            createLedgerEntry(ledger, '6040', '1010', 200000, 'Week 4 Social Media Campaign', marketingExpenseId, currentDate);
        }
        
        const isFinalDayOfSim = isSameDay(currentDate, simulationEndDate);
        const proRataFactor = isFinalDayOfSim && !isLastDayOfMonth(currentDate) ? getDate(simulationEndDate) / getDaysInMonth(simulationEndDate) : 1;
        
        if (dayOfMonth === 1) {
            const rentAmount = 1000000 * (isFinalDayOfSim ? proRataFactor : 1);
            expenses.push({ id: expenseIdCounter++, description: `Rent for ${format(currentDate, 'MMMM yyyy')}`, category: ExpenseCategory.RENT, amount: rentAmount, date: currentDate, recordedById: accountantUser.id });
            createLedgerEntry(ledger, '6020', '1010', rentAmount, `Rent for ${format(currentDate, 'MMMM yyyy')}`, expenseIdCounter - 1, currentDate);
        }

        if (isLastDayOfMonth(currentDate) || isFinalDayOfSim) {
            const monthStr = format(currentDate, 'MMMM yyyy');
            
            // Refactored Payroll
            const totalSalary = USERS_DATA.reduce((sum, u) => sum + u.salary, 0) * proRataFactor;
            payrollRuns.push({ id: payrollRunIdCounter++, date: currentDate, totalAmount: totalSalary, employeeCount: USERS_DATA.length, processedById: accountantUser.id });
            const salaryBatch = generateBatchId();
            USERS_DATA.forEach(user => {
                const userSalary = user.salary * proRataFactor;
                const expense: Expense = { id: expenseIdCounter++, description: `Salary for ${user.name} - ${monthStr}`, category: ExpenseCategory.SALARIES, amount: userSalary, date: currentDate, recordedById: accountantUser.id };
                expenses.push(expense);
                createLedgerEntry(ledger, '6010', '1010', userSalary, expense.description, expense.id, currentDate, salaryBatch);
            });
            
            const utilitiesAmount = 400000 * proRataFactor;
            expenses.push({ id: expenseIdCounter++, description: `Utilities for ${monthStr}`, category: ExpenseCategory.UTILITIES, amount: utilitiesAmount, date: currentDate, recordedById: accountantUser.id });
            createLedgerEntry(ledger, '6030', '1010', utilitiesAmount, `Utilities for ${monthStr}`, expenseIdCounter-1, currentDate);

            const fuelAmount = 1000000 * proRataFactor;
            expenses.push({ id: expenseIdCounter++, description: `Fuel & Transport for ${monthStr}`, category: ExpenseCategory.FUEL_TRANSPORTATION, amount: fuelAmount, date: currentDate, recordedById: accountantUser.id });
            createLedgerEntry(ledger, '6065', '1010', fuelAmount, `Fuel & Transport for ${monthStr}`, expenseIdCounter-1, currentDate);

            const warrantyExpense = (isFinalDayOfSim ? monthRevenue : lastMonthRevenue) * 0.04;
            expenses.push({ id: expenseIdCounter++, description: `Warranty provision for ${monthStr}`, category: ExpenseCategory.WARRANTY_CLAIMS, amount: warrantyExpense, date: currentDate, recordedById: accountantUser.id });
            createLedgerEntry(ledger, '6090', '2400', warrantyExpense, `Warranty provision for ${monthStr}`, expenseIdCounter-1, currentDate);
            
            const depBatch = generateBatchId();
            createLedgerEntry(ledger, '6080', '1590', MONTHLY_DEPRECIATION * proRataFactor, `Depreciation for ${monthStr}`, `DEP-${getMonth(currentDate)}-${getYear(currentDate)}`, currentDate, depBatch);
            createLedgerEntry(ledger, '6100', '1400', LOAN_FEE_AMORTIZATION_MONTHLY * proRataFactor, `Loan fee amortization for ${monthStr}`, `AMORT-${getMonth(currentDate)}-${getYear(currentDate)}`, currentDate, depBatch);
            
            if (remainingLoanBalance > 0) {
                const interestPayment = remainingLoanBalance * LOAN_INTEREST_RATE_MONTHLY * proRataFactor;
                const principalPayment = (LOAN_PRINCIPAL / LOAN_TERM_MONTHS) * proRataFactor;
                const loanBatch = generateBatchId();
                if (interestPayment > 0) createLedgerEntry(ledger, '6070', '1010', interestPayment, `Loan interest for ${monthStr}`, `LOAN-INT-${getMonth(currentDate)}-${getYear(currentDate)}`, currentDate, loanBatch);
                if(principalPayment > 0) createLedgerEntry(ledger, '2010', '1010', principalPayment, `Loan principal for ${monthStr}`, `LOAN-PRIN-${getMonth(currentDate)}-${getYear(currentDate)}`, currentDate, loanBatch);
                remainingLoanBalance -= principalPayment;
            }
        }
        currentDate = addDays(currentDate, 1);
    }
    
    // Generate Shifts
    const shiftDays = eachDayOfInterval({ start: STARTUP_DATE, end: NOW });
    shiftDays.forEach(day => {
        const workingUsers = USERS_DATA.filter(u => u.role !== UserRole.IT_MANAGER); // Everyone works except IT
        workingUsers.forEach(user => {
            if (Math.random() > 0.15) { // 85% chance of having a shift
                const start = set(day, { hours: 8, minutes: 0, seconds: 0 });
                const end = set(day, { hours: 17, minutes: 0, seconds: 0 });
                shifts.push({ id: shiftIdCounter++, employeeId: user.id, start, end });
            }
        });
    });


    const repairJobs: RepairJob[] = [
        { id: 1, customerName: 'Alice Johnson', contactInfo: '555-0101', deviceDescription: 'iPhone 12, Blue', issueDescription: 'Cracked screen', assignedToId: itManagerUser.id, status: RepairStatus.COMPLETED, quote: 150000, createdById: 7, createdAt: sub(NOW, { days: 15 }), completedAt: sub(NOW, { days: 12 }) },
        { id: 2, customerName: 'Bob Williams', contactInfo: '555-0102', deviceDescription: 'HP EliteBook Laptop', issueDescription: 'Won\'t turn on, possible motherboard issue.', assignedToId: itManagerUser.id, status: RepairStatus.IN_PROGRESS, quote: 350000, createdById: 8, createdAt: sub(NOW, { days: 8 }) },
    ];
    
    // Final balance calculation
    accounts.forEach(account => {
        account.balance = ledger.filter(e => e.accountId === account.id).reduce((sum, e) => sum + e.amount, 0);
    });

    return {
        products, inventoryItems, customers: customersData, suppliers: suppliersData, transactions, purchaseOrders, users: [...USERS_DATA], expenses,
        auditLogs: [], settings, repairJobs, accounts, ledger, budgets: BUDGET_DATA, notifications,
        requisitions, marketingCampaigns, shifts, payrollRuns, conversations, messages
    };
};

let mockData: DataSnapshot | null = null;
const saveData = () => { if (mockData) localStorage.setItem(STORAGE_KEY, JSON.stringify(mockData)); };

export const getMockData = (): DataSnapshot => {
  if (!mockData) {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if(savedData) {
        try {
            mockData = JSON.parse(savedData, jsonDateReviver) as DataSnapshot;
            if (!mockData.accounts || !mockData.ledger || !mockData.budgets || !mockData.notifications || !mockData.users.find(u=>u.employeeId) || !mockData.requisitions || !mockData.payrollRuns || !mockData.shifts || !mockData.marketingCampaigns || !mockData.conversations || !mockData.messages) {
                throw new Error("Invalid or outdated data structure.");
            }
        } catch (error) {
            console.error("Failed to parse data, re-initializing.", error);
            localStorage.removeItem(STORAGE_KEY);
            mockData = initializeBusinessData();
            saveData();
        }
    } else {
        mockData = initializeBusinessData();
        saveData();
    }
  }
  return JSON.parse(JSON.stringify(mockData), jsonDateReviver);
};

// --- DATA MUTATION FUNCTIONS ---
export const addAuditLog = (performingUserId: number, action: LogAction, details: string) => {
    if(!mockData) getMockData();
    if(mockData) {
        const user = mockData.users.find(u => u.id === performingUserId);
        if(!user) return;
        const newLog: AuditLog = { id: (mockData.auditLogs[0]?.id || 0) + 1, timestamp: NOW, userId: performingUserId, userName: user.name, action, details };
        mockData.auditLogs.unshift(newLog);
    }
};

interface SaleDetails {
    saleItems: { productId: string; serialNumber: string; price: number; originalPrice: number; }[]; cashierId: number; taxRate: number; discount?: number; customerId?: number; paymentMethod: 'Cash' | 'Credit' | 'Card' | 'Mobile Money'; managerApprovalId?: number;
}

export const addSaleTransaction = (details: SaleDetails): Transaction | null => {
    if (!mockData) getMockData();
    if (mockData) {
        const { saleItems, cashierId, taxRate, customerId, paymentMethod, discount = 0, managerApprovalId } = details;
        
        for (const item of saleItems) {
            if (item.productId.startsWith('P') && !item.serialNumber.startsWith('REPAIR-')) {
                const inventoryItem = mockData.inventoryItems.find(i => i.id === item.serialNumber);
                if (!inventoryItem || inventoryItem.status !== 'available') { console.error(`Item ${item.serialNumber} not available.`); return null; }
            }
        }
        
        const subtotal = saleItems.reduce((sum, item) => sum + item.price, 0);
        const discountAmount = subtotal * (discount / 100);
        const preTaxTotal = subtotal - discountAmount;
        const taxAmount = preTaxTotal * (taxRate / 100);
        const finalTotal = preTaxTotal + taxAmount;

        const newTransactionId = (mockData.transactions[0]?.id || 8000) + 1;
        const salesTimestamp = NOW;
        const paymentAccountId = paymentMethod === 'Credit' ? '1100' : '1010'; 
        
        const repairItem = saleItems.find(item => item.serialNumber.startsWith('REPAIR-'));
        const isRepair = !!repairItem;
        const revenueAccount = isRepair ? '4100' : '4000';
        
        const saleBatchId = generateBatchId();

        mockData.ledger.push({ id: ledgerIdCounter++, accountId: paymentAccountId, amount: finalTotal, timestamp: salesTimestamp, description: `Sale #${newTransactionId}`, transactionId: newTransactionId, relatedAccountId: 'SPLIT', batchId: saleBatchId });
        mockData.ledger.push({ id: ledgerIdCounter++, accountId: revenueAccount, amount: -preTaxTotal, timestamp: salesTimestamp, description: `Revenue from Sale #${newTransactionId}`, transactionId: newTransactionId, relatedAccountId: paymentAccountId, batchId: saleBatchId });
        mockData.ledger.push({ id: ledgerIdCounter++, accountId: '2200', amount: -taxAmount, timestamp: salesTimestamp, description: `Tax for Sale #${newTransactionId}`, transactionId: newTransactionId, relatedAccountId: paymentAccountId, batchId: saleBatchId });
        
        if (paymentMethod === 'Credit' && customerId) {
            const customerIndex = mockData.customers.findIndex(c => c.id === customerId);
            if(customerIndex > -1) mockData.customers[customerIndex].creditUsed += finalTotal;
        }

        const physicalSaleItems = saleItems.filter(item => !item.serialNumber.startsWith('REPAIR-'));
        if(physicalSaleItems.length > 0) {
            const cogs = physicalSaleItems.reduce((sum, item) => {
                const invItem = mockData.inventoryItems.find(i => i.id === item.serialNumber);
                return sum + (invItem?.cost || 0);
            }, 0);
            
            if (cogs > 0) createLedgerEntry(mockData.ledger, '5000', '1200', cogs, `COGS for Sale #${newTransactionId}`, newTransactionId, salesTimestamp, saleBatchId);
            
            for (const item of physicalSaleItems) {
                const itemIndex = mockData.inventoryItems.findIndex(i => i.id === item.serialNumber);
                if (itemIndex > -1) { 
                    const inventoryItem = mockData.inventoryItems[itemIndex];
                    inventoryItem.status = 'sold'; inventoryItem.soldAt = NOW; inventoryItem.soldToCustomerId = customerId;
                    inventoryItem.warrantyEndDate = new Date(new Date(NOW).setFullYear(new Date(NOW).getFullYear() + 1));
                    
                    const product = mockData.products.find(p => p.id === inventoryItem.productId);
                    if (product) {
                        const stockCount = mockData.inventoryItems.filter(i => i.productId === inventoryItem.productId && i.status === 'available').length;
                        if(stockCount === 0) addNotification(mockData.notifications, NotificationType.OUT_OF_STOCK, `${product.name} is now out of stock.`, product.id);
                        else if (stockCount <= 5) addNotification(mockData.notifications, NotificationType.LOW_STOCK, `Low stock for ${product.name} (${stockCount} left).`, product.id);
                    }
                }
            }
        }
        
        if (isRepair && repairItem) {
            const repairId = parseInt(repairItem.serialNumber.split('-')[1]);
            const repairJobIndex = mockData.repairJobs.findIndex(j => j.id === repairId);
            if (repairJobIndex > -1) mockData.repairJobs[repairJobIndex].status = RepairStatus.CLOSED;
        }
        
        const newTransaction: Transaction = { id: newTransactionId, type: TransactionType.SALE, items: saleItems, totalAmount: finalTotal, discount, timestamp: salesTimestamp, cashierId, customerId, paymentMethod, managerApprovalId };
        mockData.transactions.unshift(newTransaction);
        addAuditLog(cashierId, LogAction.SALE_COMPLETED, `Sale #${newTransaction.id} for ${formatCurrency(newTransaction.totalAmount, CURRENCIES[0])}.`);

        saleItems.forEach(item => {
            if (item.price !== item.originalPrice) {
                const product = mockData.products.find(p => p.id === item.productId);
                const manager = managerApprovalId ? mockData.users.find(u => u.id === managerApprovalId) : null;
                addAuditLog(cashierId, LogAction.PRICE_OVERRIDE_IN_SALE, `Price for "${product?.name || 'unknown'}" (SN: ${item.serialNumber}) changed from ${formatCurrency(item.originalPrice, CURRENCIES[0])} to ${formatCurrency(item.price, CURRENCIES[0])} in Sale #${newTransaction.id}. ${manager ? `Approved by ${manager.name}.` : ''}`);
            }
        });

        saveData();
        return newTransaction;
    }
    return null;
};

export const addExpense = (expense: Omit<Expense, 'id' | 'date'>): Expense | null => {
    if (!mockData) getMockData();
    if (mockData) {
        const newId = (mockData.expenses[0]?.id || 10000) + 1;
        const newExpense: Expense = { ...expense, id: newId, date: NOW };
        mockData.expenses.unshift(newExpense);
        
        const expenseAccountMap: Record<ExpenseCategory, string> = {
            [ExpenseCategory.SALARIES]: '6010', [ExpenseCategory.RENT]: '6020', [ExpenseCategory.UTILITIES]: '6030', [ExpenseCategory.MARKETING]: '6040',
            [ExpenseCategory.SUPPLIES]: '6050', [ExpenseCategory.REPAIRS]: '6060', [ExpenseCategory.OTHER]: '6900',
            [ExpenseCategory.FUEL_TRANSPORTATION]: '6065', [ExpenseCategory.WARRANTY_CLAIMS]: '6090', [ExpenseCategory.DEPRECIATION]: '6080',
            [ExpenseCategory.INTEREST]: '6070', [ExpenseCategory.BANK_FEES]: '6100', [ExpenseCategory.INCOME_TAX]: '6800', [ExpenseCategory.ASSET_PURCHASE]: '1510',
        };
        createLedgerEntry(mockData.ledger, expenseAccountMap[newExpense.category], '1010', newExpense.amount, newExpense.description, newId, NOW);
        
        addAuditLog(expense.recordedById, LogAction.EXPENSE_LOGGED, `Logged expense "${newExpense.description}" for ${formatCurrency(newExpense.amount, CURRENCIES[0])}.`);
        saveData();
        return newExpense;
    }
    return null;
};

export const addJournalEntry = (entries: { accountId: string, amount: number }[], description: string, pId: number): LedgerEntry[] | null => {
    if (!mockData) getMockData();
    if (mockData) {
        const total = entries.reduce((sum, e) => sum + e.amount, 0);
        if (Math.abs(total) > 0.01) { console.error("Journal entry is not balanced."); return null; }

        const batchId = generateBatchId();
        const transactionId = `JE-${batchId}`;
        const newLedgerEntries: LedgerEntry[] = [];
        
        for(const entry of entries) {
             const newEntry: LedgerEntry = { id: ledgerIdCounter++, accountId: entry.accountId, amount: entry.amount, timestamp: NOW, description, transactionId, relatedAccountId: 'JE-SPLIT', batchId };
            mockData.ledger.push(newEntry);
            newLedgerEntries.push(newEntry);
        }
        
        addAuditLog(pId, LogAction.GENERAL_JOURNAL_ENTRY_CREATED, `Created journal entry: ${description}`);
        saveData();
        return newLedgerEntries;
    }
    return null;
}

export const runPayroll = (usersToPay: User[], performingUserId: number): PayrollRun | null => {
    if (!mockData) return null;
    
    const totalSalary = usersToPay.reduce((sum, user) => sum + user.salary, 0);
    if (totalSalary <= 0) return null;
    
    const monthStr = format(NOW, 'MMMM yyyy');
    const newPayrollRun: PayrollRun = { id: (mockData.payrollRuns[0]?.id || 0) + 1, date: NOW, totalAmount: totalSalary, employeeCount: usersToPay.length, processedById: performingUserId };
    mockData.payrollRuns.unshift(newPayrollRun);

    const salaryBatch = generateBatchId();
    usersToPay.forEach(user => {
        const newExpense: Expense = { id: (mockData?.expenses[0]?.id || 10000) + 1, description: `Salary for ${user.name} - ${monthStr}`, category: ExpenseCategory.SALARIES, amount: user.salary, date: NOW, recordedById: performingUserId };
        mockData?.expenses.unshift(newExpense);
        createLedgerEntry(mockData!.ledger, '6010', '1010', user.salary, newExpense.description, newExpense.id, NOW, salaryBatch);
    });

    const performer = mockData.users.find(u => u.id === performingUserId);
    addNotification(mockData.notifications, NotificationType.PAYROLL_PROCESSED, `Payroll run for ${formatCurrency(totalSalary, CURRENCIES[0])}.`, undefined, performer?.name);
    addAuditLog(performingUserId, LogAction.PAYROLL_PROCESSED, `Processed payroll for ${formatCurrency(totalSalary, CURRENCIES[0])}.`);
    saveData();
    return newPayrollRun;
};

// --- CHAT MODULE MUTATIONS ---
// Using a simple object to simulate a persistent store for counters.
const counters = {
    conversationId: 100,
    messageId: 100,
};

export const createConversation = (creatorId: number, participantIds: number[], groupName?: string): Conversation | null => {
    if (!mockData) getMockData();
    if (mockData) {
        if (participantIds.length < 2) return null;

        // For direct messages, check if a conversation already exists
        if (participantIds.length === 2) {
            const existing = mockData.conversations.find(c => 
                c.type === 'direct' &&
                c.participants.length === 2 &&
                c.participants.includes(participantIds[0]) &&
                c.participants.includes(participantIds[1])
            );
            if (existing) return existing;
        }

        const newConversation: Conversation = {
            id: `C${++counters.conversationId}`,
            type: participantIds.length > 2 ? 'group' : 'direct',
            participants: participantIds,
            creatorId: participantIds.length > 2 ? creatorId : undefined,
            name: groupName,
            createdAt: NOW,
            unreadCounts: participantIds.reduce((acc, id) => ({ ...acc, [id]: 0 }), {}),
        };
        mockData.conversations.unshift(newConversation);
        saveData();
        return newConversation;
    }
    return null;
};

export const sendMessage = (senderId: number, conversationId: string, content: { text?: string; imageUrl?: string }): Message | null => {
    if (!mockData) getMockData();
    if (mockData) {
        const conversationIndex = mockData.conversations.findIndex(c => c.id === conversationId);
        if (conversationIndex === -1) return null;

        const { text, imageUrl } = content;
        if (!text && !imageUrl) return null;

        const newMessage: Message = {
            id: `M${++counters.messageId}`,
            conversationId,
            senderId,
            text: text || '',
            imageUrl,
            timestamp: NOW,
            status: MessageStatus.SENT,
        };
        mockData.messages.push(newMessage);
        
        const conversation = mockData.conversations[conversationIndex];
        const lastMessageText = text || 'Sent an image';
        conversation.lastMessage = { text: lastMessageText, timestamp: NOW, senderId };
        
        const sender = mockData.users.find(u => u.id === senderId);

        conversation.participants.forEach(id => {
            if (id !== senderId) {
                conversation.unreadCounts[id] = (conversation.unreadCounts[id] || 0) + 1;
                addNotification(mockData!.notifications, NotificationType.CHAT_MESSAGE, `${lastMessageText}`, conversationId, sender?.name);
            }
        });

        saveData();
        return newMessage;
    }
    return null;
}

export const editMessage = (messageId: string, newText: string): Message | null => {
    if (!mockData) getMockData();
    if (mockData) {
        const messageIndex = mockData.messages.findIndex(m => m.id === messageId);
        if (messageIndex > -1) {
            mockData.messages[messageIndex].text = newText;
            mockData.messages[messageIndex].isEdited = true;
            saveData();
            return mockData.messages[messageIndex];
        }
    }
    return null;
}

export const deleteMessage = (messageId: string): Message | null => {
    if (!mockData) getMockData();
    if (mockData) {
        const messageIndex = mockData.messages.findIndex(m => m.id === messageId);
        if (messageIndex > -1) {
            // Soft delete
            mockData.messages[messageIndex].text = '[Message deleted]';
            mockData.messages[messageIndex].imageUrl = undefined;
            saveData();
            return mockData.messages[messageIndex];
        }
    }
    return null;
}

export const markConversationAsRead = (userId: number, conversationId: string) => {
    if (!mockData) getMockData();
    if (mockData) {
        const convIndex = mockData.conversations.findIndex(c => c.id === conversationId);
        if (convIndex > -1) {
            mockData.conversations[convIndex].unreadCounts[userId] = 0;
            saveData();
        }
    }
}


export const addPurchaseOrder = (order: Omit<PurchaseOrder, 'id' | 'status' | 'orderDate'>, performingUserId: number) => {
    if (!mockData) getMockData();
    if (mockData) {
        const newId = `PO-${(parseInt(mockData.purchaseOrders[0]?.id.substring(3) || '1999')) + 1}`;
        const newOrder: PurchaseOrder = { ...order, id: newId, status: PurchaseOrderStatus.PENDING, orderDate: NOW };
        
        const performer = mockData.users.find(u => u.id === performingUserId);
        addNotification(mockData.notifications, NotificationType.PENDING_PO, `New Purchase Order ${newId} created.`, newId, performer?.name);
        
        setTimeout(() => {
            if(mockData){
                const orderIndex = mockData.purchaseOrders.findIndex(o => o.id === newId);
                if (orderIndex > -1 && mockData.purchaseOrders[orderIndex].status === PurchaseOrderStatus.PENDING) {
                    mockData.purchaseOrders[orderIndex].status = PurchaseOrderStatus.SHIPPED;
                    addNotification(mockData.notifications, NotificationType.PO_SHIPPED, `Purchase Order ${newId} has been shipped.`, newId, 'System');
                    saveData();
                }
            }
        }, 1000 * 60 * 60 * 24 * 2);

        mockData.purchaseOrders.unshift(newOrder);
        addAuditLog(performingUserId, LogAction.PO_CREATED, `Created Purchase Order ${newId}.`);
        saveData();
        return newOrder;
    }
    return null;
}

export const receivePurchaseOrder = (orderId: string, performingUserId: number): PurchaseOrder | null => {
    if (!mockData) getMockData();
    if(mockData) {
        const poIndex = mockData.purchaseOrders.findIndex(po => po.id === orderId);
        if (poIndex > -1) {
            const po = mockData.purchaseOrders[poIndex];
            if (po.status !== PurchaseOrderStatus.SHIPPED) return null;
            po.status = PurchaseOrderStatus.RECEIVED;
            
            let totalCost = 0;
            for (const item of po.items) {
                totalCost += item.cost * item.quantity;
                for (let i = 0; i < item.quantity; i++) {
                    mockData.inventoryItems.push({ id: generateSerialNumber(item.productId), productId: item.productId, cost: item.cost, status: 'available', addedAt: NOW, purchaseOrderId: po.id });
                }
            }
            createLedgerEntry(mockData.ledger, '1200', '2100', totalCost, `Received PO ${po.id}`, po.id);
            const performer = mockData.users.find(u => u.id === performingUserId);
            addNotification(mockData.notifications, NotificationType.PO_RECEIVED, `Purchase Order ${po.id} has been received.`, po.id, performer?.name);
            addAuditLog(performingUserId, LogAction.PO_RECEIVED, `Received PO ${po.id}.`);
            saveData();
            return po;
        }
    }
    return null;
}

export const addRequisition = (req: Omit<Requisition, 'id' | 'status' | 'createdAt'>, pId: number): Requisition | null => {
    if(!mockData) getMockData();
    if(mockData) {
        const newReq: Requisition = { ...req, id: (mockData.requisitions[0]?.id || 0) + 1, status: RequisitionStatus.PENDING, createdAt: NOW };
        mockData.requisitions.unshift(newReq);
        addAuditLog(pId, LogAction.REQUISITION_CREATED, `Created requisition #${newReq.id} for ${formatCurrency(newReq.totalEstimatedCost, CURRENCIES[0])}.`);
        const requester = mockData.users.find(u => u.id === pId);
        addNotification(mockData.notifications, NotificationType.REQUISITION_PENDING, `Requisition #${newReq.id} is pending approval.`, newReq.id, requester?.name);
        saveData();
        return newReq;
    }
    return null;
};

export const updateRequisitionStatus = (reqId: number, status: RequisitionStatus, approverId: number, rejectionReason?: string): Requisition | null => {
    if(!mockData) getMockData();
    if(mockData){
        const reqIndex = mockData.requisitions.findIndex(r => r.id === reqId);
        if(reqIndex > -1){
            const req = mockData.requisitions[reqIndex];
            req.status = status;
            req.approverId = approverId;
            req.approvedAt = NOW;
            if(rejectionReason) req.rejectionReason = rejectionReason;
            
            const approver = mockData.users.find(u => u.id === approverId);
            const actionDetail = `Status of requisition #${reqId} changed to ${status} by ${approver?.name}.`;
            addAuditLog(approverId, LogAction.REQUISITION_STATUS_CHANGED, actionDetail);
            
            const requester = mockData.users.find(u => u.id === req.requesterId);
            if(requester) {
                const notifType = status === RequisitionStatus.APPROVED ? NotificationType.REQUISITION_APPROVED : NotificationType.REQUISITION_REJECTED;
                addNotification(mockData.notifications, notifType, `Your requisition #${reqId} has been ${status.toLowerCase()}.`, req.id, approver?.name);
            }

            if (status === RequisitionStatus.APPROVED && req.type === RequisitionType.INVENTORY) {
                const po = addPurchaseOrder({
                    supplierId: 1, // Default supplier for now
                    items: req.items.map(item => ({ productId: item.productId || 'GENERIC', quantity: item.quantity, cost: item.estimatedCost })),
                    totalCost: req.totalEstimatedCost,
                    expectedDeliveryDate: addDays(NOW, 14),
                    requisitionId: req.id,
                }, approverId);
                if (po) {
                    req.status = RequisitionStatus.ORDERED;
                    req.relatedPOId = po.id;
                }
            } else if (status === RequisitionStatus.APPROVED && (req.type === RequisitionType.EXPENSE || req.type === RequisitionType.ASSET)) {
                const category = req.type === RequisitionType.ASSET ? ExpenseCategory.ASSET_PURCHASE : (req.items[0]?.description.toLowerCase().includes('marketing') ? ExpenseCategory.MARKETING : ExpenseCategory.OTHER);
                addExpense({ description: req.description, category, amount: req.totalEstimatedCost, recordedById: approverId, requisitionId: req.id });
                req.status = RequisitionStatus.COMPLETED;
            }

            saveData();
            return req;
        }
    }
    return null;
};

export const addMarketingCampaign = (campaign: Omit<MarketingCampaign, 'id' | 'status' | 'createdById' | 'actualSpend'>, pId: number): MarketingCampaign | null => {
    if(!mockData) getMockData();
    if(mockData){
        const newCampaign: MarketingCampaign = { ...campaign, id: (mockData.marketingCampaigns[0]?.id || 0) + 1, status: MarketingCampaignStatus.PLANNING, createdById: pId, actualSpend: 0 };
        mockData.marketingCampaigns.unshift(newCampaign);
        addAuditLog(pId, LogAction.MARKETING_CAMPAIGN_CREATED, `Created new marketing campaign: "${newCampaign.name}".`);
        saveData();
        return newCampaign;
    }
    return null;
};

export const addShift = (shift: Omit<Shift, 'id'>, pId: number): Shift | null => {
    if(!mockData) getMockData();
    if(mockData) {
        const newShift: Shift = { ...shift, id: (mockData.shifts[0]?.id || 0) + 1 };
        mockData.shifts.push(newShift);
        const employee = mockData.users.find(u => u.id === shift.employeeId);
        addAuditLog(pId, LogAction.SHIFT_SCHEDULED, `Scheduled shift for ${employee?.name} on ${format(shift.start, 'yyyy-MM-dd')}.`);
        saveData();
        return newShift;
    }
    return null;
}

export const updateNotifications = (notifications: Notification[]) => { if(!mockData) getMockData(); if(mockData) { mockData.notifications = notifications; saveData(); } };
export const updateUserRole = (userId: number, role: UserRole, pId: number): User | null => { if(!mockData)getMockData();if(mockData){ const uI=mockData.users.findIndex(u=>u.id===userId); if(uI>-1){const u=mockData.users[uI],oR=u.role;u.role=role;addAuditLog(pId,LogAction.USER_ROLE_CHANGED,`Changed role of "${u.name}" from "${oR}" to "${role}".`);saveData();return u;}} return null;}
export const updateUserSalary = (userId:number,newSalary:number,pId:number):User|null=>{if(!mockData)getMockData();if(mockData){const uI=mockData.users.findIndex(u=>u.id===userId);if(uI>-1){const u=mockData.users[uI],oS=u.salary;u.salary=newSalary;addAuditLog(pId,LogAction.USER_SALARY_CHANGED,`Changed salary of "${u.name}" from ${formatCurrency(oS,CURRENCIES[0])} to ${formatCurrency(newSalary,CURRENCIES[0])}.`);saveData();return u;}} return null;}
export const updateUserPassword = (userId: number, pId: number): User | null => { if(!mockData)getMockData();if(mockData){const uI=mockData.users.findIndex(u=>u.id===userId);if(uI>-1){const u=mockData.users[uI];addAuditLog(pId,LogAction.USER_PASSWORD_CHANGED,`User ${u.name} (ID: ${u.id}) changed their password.`);saveData();return u;}}return null;};
export const addSupplier=(s:Omit<Supplier,'id'>,pId:number)=>{if(!mockData)getMockData();if(mockData){const nS:Supplier={...s,id:(mockData.suppliers[0]?.id||0)+1};mockData.suppliers.unshift(nS);addAuditLog(pId,LogAction.SUPPLIER_ADDED,`Added new supplier: "${nS.name}".`);saveData();return nS;}return null}
export const updateSettings=(newSettings:AppSettings,pId:number):void=>{if(!mockData)getMockData();if(mockData){const oldMarkup=mockData.settings.markupPercentage;const newMarkup=newSettings.markupPercentage;if(oldMarkup!==newMarkup&&newMarkup!==undefined){mockData.products.forEach(p=>{if(p.category!=='Repairs'){p.price=Math.round(p.cost*(1+newMarkup/100));}});addAuditLog(pId,LogAction.PRODUCT_PRICES_UPDATED_FROM_MARKUP,`Global product markup changed from ${oldMarkup||'N/A'}% to ${newMarkup}%. Prices updated.`);}mockData.settings=newSettings;addAuditLog(pId,LogAction.SETTINGS_CHANGED,'Updated general company settings.');saveData();}};
export const addRepairJob = (job: Omit<RepairJob, 'id' | 'createdAt' | 'assignedToId'>, pId: number): RepairJob | null => { 
    if(!mockData)getMockData();
    if(mockData){
        const itManager = mockData.users.find(u => u.role === UserRole.IT_MANAGER);
        if (!itManager) {
            console.error("IT Manager role not found. Cannot assign repair job.");
            return null;
        }
        const newJob:RepairJob={...job, id:(mockData.repairJobs[0]?.id||0)+1, assignedToId: itManager.id, createdAt: NOW};
        mockData.repairJobs.unshift(newJob);
        addAuditLog(pId,LogAction.REPAIR_LOGGED,`Logged new repair job #${newJob.id} for ${newJob.customerName}.`);
        saveData();
        return newJob;
    }
    return null;
};
export const updateRepairJobStatus=(jId:number,s:RepairStatus,pId:number):RepairJob|null=>{if(!mockData)getMockData();if(mockData){const jI=mockData.repairJobs.findIndex(j=>j.id===jId);if(jI>-1){const j=mockData.repairJobs[jI],oS=j.status;j.status=s;if(s===RepairStatus.COMPLETED)j.completedAt=NOW;addAuditLog(pId,LogAction.REPAIR_STATUS_CHANGED,`Changed status of repair job #${jId} from ${oS} to ${s}.`);saveData();return j;}}return null;};
export const addProduct=(d:Omit<Product,'id'|'image'>,iS:number,pId:number)=>{
    if(!mockData) getMockData();
    if(mockData){
        const newProductData = { ...d };
        const june2025 = new Date('2025-06-01T00:00:00Z');

        // If the current date is on or after June 1, 2025, apply a 60% markup, overriding any submitted price.
        if (NOW >= june2025) {
            newProductData.price = Math.round(newProductData.cost * 1.60);
        }

        const nP:Product={...newProductData,id:`P${(parseInt(mockData.products[0]?.id.substring(1)||'999'))+1}`, image: `https://picsum.photos/seed/P${(parseInt(mockData.products[0]?.id.substring(1)||'999'))+1}/200/200`};
        mockData.products.unshift(nP);
        for(let i=0;i<iS;i++){
            mockData.inventoryItems.push({id:generateSerialNumber(nP.id),productId:nP.id,cost:nP.cost,status:'available',addedAt:NOW});
        }
        addAuditLog(pId,LogAction.PRODUCT_ADDED,`Added "${nP.name}" with ${iS} units.`);
        saveData();
        return nP;
    }
    return null
};
export const updateProductPrice=(pId:string,newPrice:number,performingUserId:number):Product|null=>{if(!mockData)getMockData();if(mockData){const pI=mockData.products.findIndex(p=>p.id===pId);if(pI>-1){const p=mockData.products[pI],oP=p.price;p.price=newPrice;addAuditLog(performingUserId,LogAction.PRODUCT_PRICE_UPDATED,`Updated price for "${p.name}" from ${formatCurrency(oP,CURRENCIES[0])} to ${formatCurrency(newPrice,CURRENCIES[0])}.`);saveData();return p;}}return null};
export const addCustomer=(cD:Omit<Customer,'id'|'tier'|'creditUsed'|'joinDate'>,pId:number):Customer|null=>{if(!mockData)getMockData();if(mockData){const nC:Customer={...cD,id:(mockData.customers.reduce((max,c)=>Math.max(c.id,max),0))+1,tier:'Regular',creditUsed:0,joinDate:NOW};mockData.customers.unshift(nC);addAuditLog(pId,LogAction.CUSTOMER_ADDED,`Added new customer: ${nC.name}`);saveData();return nC;}return null};
export const updateBudget = (newBudgets: Budget[], pId: number) => { if (!mockData) getMockData(); if (mockData) { mockData.budgets = newBudgets; addAuditLog(pId, LogAction.SETTINGS_CHANGED, 'Updated monthly budgets.'); saveData(); } }
