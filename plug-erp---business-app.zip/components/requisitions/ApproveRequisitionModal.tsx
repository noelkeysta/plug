
import React, { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { Requisition } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import { useCurrency } from '../../contexts/CurrencyContext';
import { format } from 'date-fns';
import { Check, X, AlertTriangle } from 'lucide-react';

interface ApproveRequisitionModalProps {
  requisition: Requisition;
  onConfirm: (rejectionReason?: string) => void;
  onCancel: () => void;
}

const ApproveRequisitionModal: React.FC<ApproveRequisitionModalProps> = ({ requisition, onConfirm, onCancel }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currency } = useCurrency();
  const [rejectionReason, setRejectionReason] = useState('');
  
  const handleReject = () => {
    if (rejectionReason.trim() === '') {
        // Simple validation, can be improved with react-hook-form if needed
        alert('Rejection reason is required.');
        return;
    }
    onConfirm(rejectionReason);
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold">Review Requisition #{requisition.id}</h3>
      <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-slate-800/50' : 'bg-slate-100'}`}>
        <p className="font-semibold">{requisition.description}</p>
        <div className="flex justify-between items-baseline mt-2">
            <span className="text-sm text-slate-400">Total Amount:</span>
            <span className="font-bold text-lg">{formatCurrency(requisition.totalEstimatedCost, currency)}</span>
        </div>
      </div>
      
      <div className="space-y-2">
        <label htmlFor="rejectionReason" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Rejection Reason (if applicable)</label>
        <textarea
            id="rejectionReason"
            value={rejectionReason}
            onChange={(e) => setRejectionReason(e.target.value)}
            rows={3}
            className={`w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
            placeholder="Provide a reason for rejection..."
        />
      </div>

      <div className="flex justify-end gap-4 pt-4">
        <button onClick={onCancel} className={`px-6 py-2 rounded-full font-semibold`}>Cancel</button>
        <button
            onClick={handleReject}
            disabled={!rejectionReason}
            className={`flex items-center gap-2 px-6 py-2 rounded-full font-semibold bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          <X size={16} /> Reject
        </button>
        <button
            onClick={() => onConfirm()}
            className={`flex items-center gap-2 px-6 py-2 rounded-full font-semibold bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors`}
        >
          <Check size={16} /> Approve
        </button>
      </div>
    </div>
  );
};

export default ApproveRequisitionModal;
