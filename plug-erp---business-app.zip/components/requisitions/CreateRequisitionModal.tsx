
import React, { useMemo } from 'react';
import { useForm, useFieldArray, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useData } from '../../contexts/DataContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { addRequisition } from '../../services/mockDataService';
import { RequisitionType } from '../../types';
import { Plus, Trash2 } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface CreateRequisitionModalProps {
    onClose: () => void;
}

const itemSchema = z.object({
    productId: z.string().optional(),
    description: z.string().min(3, 'Item description is required'),
    quantity: z.number().positive('Quantity must be positive'),
    estimatedCost: z.number().positive('Estimated cost must be positive'),
});

const requisitionSchema = z.object({
    type: z.nativeEnum(RequisitionType),
    description: z.string().min(5, 'Overall description is required'),
    items: z.array(itemSchema).min(1, 'At least one item is required'),
});

type RequisitionFormData = z.infer<typeof requisitionSchema>;

const CreateRequisitionModal: React.FC<CreateRequisitionModalProps> = ({ onClose }) => {
    const { isDarkMode, themeClasses } = useTheme();
    const { currentUser } = useAuth();
    const { data, refreshData } = useData();
    const { products = [] } = data || {};
    const { notifySuccess } = useNotifier();
    const { currency } = useCurrency();

    const { register, control, handleSubmit, formState: { errors }, watch } = useForm<RequisitionFormData>({
        resolver: zodResolver(requisitionSchema),
        defaultValues: {
            type: RequisitionType.EXPENSE,
            items: [{ description: '', quantity: 1, estimatedCost: 0 }],
        }
    });

    const { fields, append, remove } = useFieldArray({ control, name: "items" });
    const watchedItems = watch('items');
    const requisitionType = watch('type');

    const totalEstimatedCost = useMemo(() => {
        return watchedItems.reduce((acc, item) => acc + (item.quantity * item.estimatedCost || 0), 0);
    }, [watchedItems]);

    const onSubmit = (formData: RequisitionFormData) => {
        if (!currentUser) return;
        const result = addRequisition({ ...formData, requesterId: currentUser.id, totalEstimatedCost }, currentUser.id);
        if (result) {
            notifySuccess(`Requisition #${result.id} submitted for approval.`);
            refreshData();
            onClose();
        }
    };
    
    const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
    const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
    const errorClasses = "text-red-400 text-xs mt-1";

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="type" className={labelClasses}>Requisition Type</label>
                    <select id="type" {...register('type')} className={inputClasses}>
                        {Object.values(RequisitionType).map(t => <option key={t}>{t}</option>)}
                    </select>
                </div>
                 <div>
                    <label htmlFor="description" className={labelClasses}>Overall Description</label>
                    <input id="description" {...register('description')} className={inputClasses} placeholder="e.g., Q3 Office Supplies"/>
                    {errors.description && <p className={errorClasses}>{errors.description.message}</p>}
                </div>
            </div>

            <div className="space-y-3">
                <h4 className={labelClasses}>Items</h4>
                {fields.map((field, index) => (
                    <div key={field.id} className={`p-3 rounded-lg grid gap-2 ${isDarkMode ? 'bg-slate-800/50' : 'bg-slate-100'}`}>
                        {requisitionType === RequisitionType.INVENTORY ? (
                            <select {...register(`items.${index}.productId`)} className={inputClasses}>
                                <option value="">Select Product</option>
                                {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                            </select>
                        ) : (
                            <input {...register(`items.${index}.description`)} placeholder="Item description" className={inputClasses} />
                        )}
                        <div className="grid grid-cols-3 gap-2">
                            <input {...register(`items.${index}.quantity`, { valueAsNumber: true })} type="number" placeholder="Qty" className={inputClasses} />
                            <input {...register(`items.${index}.estimatedCost`, { valueAsNumber: true })} type="number" placeholder="Unit Cost" className={inputClasses} />
                            <button type="button" onClick={() => remove(index)} className="text-red-400 hover:text-red-300 flex items-center justify-center p-2"><Trash2 size={16} /></button>
                        </div>
                    </div>
                ))}
            </div>
             <button type="button" onClick={() => append({ description: '', quantity: 1, estimatedCost: 0 })} className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg border-dashed border-2 ${isDarkMode ? 'border-slate-600 hover:bg-slate-700' : 'border-slate-300 hover:bg-slate-100'}`}>
                <Plus size={16}/> Add Another Item
            </button>
            
             <div className="pt-4 border-t border-slate-700/50 flex justify-between items-center">
                <div>
                    <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Total Estimated Cost</p>
                    <p className={`text-2xl font-bold ${themeClasses.textGradient}`}>{formatCurrency(totalEstimatedCost, currency)}</p>
                </div>
                <button type="submit" className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                    Submit Request
                </button>
            </div>
        </form>
    );
};

export default CreateRequisitionModal;
