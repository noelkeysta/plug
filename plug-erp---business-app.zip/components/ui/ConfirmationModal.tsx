
import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { AlertTriangle } from 'lucide-react';

interface ConfirmationModalProps {
  onConfirm: () => void;
  onCancel: () => void;
  title: string;
  message: string;
  confirmText?: string;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ onConfirm, onCancel, title, message, confirmText = 'Confirm' }) => {
  const { themeClasses, isDarkMode } = useTheme();

  return (
    <div className="space-y-4 text-center">
        <div className="mx-auto w-fit p-3 rounded-full bg-amber-500/20 mb-4">
          <AlertTriangle className="w-10 h-10 text-amber-400" />
        </div>
        <h3 className="text-xl font-bold">{title}</h3>
        <p className={`${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            {message}
        </p>
        <div className="flex justify-center gap-4 pt-4">
            <button
                onClick={onCancel}
                className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 border-2 ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
            >
                Cancel
            </button>
            <button
                onClick={onConfirm}
                className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
            >
                {confirmText}
            </button>
      </div>
    </div>
  );
};

export default ConfirmationModal;
