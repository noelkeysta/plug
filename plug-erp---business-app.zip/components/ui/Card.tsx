
import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

const Card: React.FC<CardProps> = ({ children, className = '', onClick }) => {
  const { themeClasses } = useTheme();

  return (
    <div
      onClick={onClick}
      className={`${themeClasses.card} rounded-3xl p-6 ${className}`}
    >
      {children}
    </div>
  );
};

export default Card;
