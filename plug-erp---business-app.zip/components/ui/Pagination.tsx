import React from 'react';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  itemsCount: number;
  itemsPerPage: number;
}

const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  onPageChange,
  itemsCount,
  itemsPerPage
}) => {
  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  const startItem = itemsCount > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0;
  const endItem = Math.min(currentPage * itemsPerPage, itemsCount);

  return (
    <div className="p-4 flex flex-wrap justify-between items-center gap-4">
      <span className="text-sm text-slate-400">
        Showing {startItem} to {endItem} of {itemsCount} results
      </span>
      {totalPages > 1 && (
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrevious}
            disabled={currentPage === 1}
            className="px-3 py-1 rounded disabled:opacity-50 disabled:cursor-not-allowed transition-colors hover:bg-slate-500/20"
          >
            Prev
          </button>
          <span className="text-sm font-semibold">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={handleNext}
            disabled={currentPage === totalPages}
            className="px-3 py-1 rounded disabled:opacity-50 disabled:cursor-not-allowed transition-colors hover:bg-slate-500/20"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default Pagination;
