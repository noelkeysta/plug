
import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, subtitle }) => {
  const { themeClasses } = useTheme();
  return (
    <div className="flex flex-wrap items-center justify-between gap-4">
      <h1 className={`text-4xl md:text-5xl font-bold ${themeClasses.textGradient}`}>
        {title}
      </h1>
      {subtitle && (
        <div className={`px-4 py-2 rounded-full text-sm font-medium ${themeClasses.statusBadge}`}>
          {subtitle}
        </div>
      )}
    </div>
  );
};

export default PageHeader;
