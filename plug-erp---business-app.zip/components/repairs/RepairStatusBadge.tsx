
import React from 'react';
import { RepairStatus } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';

interface RepairStatusBadgeProps {
    status: RepairStatus;
}

const RepairStatusBadge: React.FC<RepairStatusBadgeProps> = ({ status }) => {
    const { isDarkMode } = useTheme();

    const statusClasses: Record<RepairStatus, string> = {
        [RepairStatus.PENDING]: isDarkMode ? 'bg-yellow-500/30 text-yellow-300' : 'bg-yellow-100 text-yellow-700',
        [RepairStatus.IN_PROGRESS]: isDarkMode ? 'bg-blue-500/30 text-blue-300' : 'bg-blue-100 text-blue-700',
        [RepairStatus.COMPLETED]: isDarkMode ? 'bg-emerald-500/30 text-emerald-300' : 'bg-emerald-100 text-emerald-700',
        [RepairStatus.CANCELLED]: isDarkMode ? 'bg-red-500/30 text-red-300' : 'bg-red-100 text-red-700',
        [RepairStatus.CLOSED]: isDarkMode ? 'bg-slate-500/30 text-slate-300' : 'bg-slate-200 text-slate-600',
    };

    return (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusClasses[status]}`}>
            {status}
        </span>
    );
};

export default RepairStatusBadge;
