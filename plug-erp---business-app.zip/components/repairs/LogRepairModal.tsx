
import React, { useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addRepairJob } from '../../services/mockDataService';
import { RepairJob, User, UserRole, RepairStatus } from '../../types';
import { useData } from '../../contexts/DataContext';

interface LogRepairModalProps {
  onClose: () => void;
  user: User | null;
}

const repairSchema = z.object({
  customerName: z.string().min(3, 'Customer name is required'),
  contactInfo: z.string().min(3, 'Contact info (phone/email) is required'),
  deviceDescription: z.string().min(5, 'Device description must be at least 5 characters'),
  issueDescription: z.string().min(10, 'Issue description must be at least 10 characters'),
  quote: z.number().positive('Quote must be a positive number'),
});

type RepairFormData = z.infer<typeof repairSchema>;

const LogRepairModal: React.FC<LogRepairModalProps> = ({ onClose, user }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currency } = useCurrency();
  const { data, refreshData } = useData();
  const { notifySuccess } = useNotifier();

  const { register, handleSubmit, formState: { errors } } = useForm<RepairFormData>({
    resolver: zodResolver(repairSchema),
    defaultValues: {
      customerName: '',
      contactInfo: '',
      deviceDescription: '',
      issueDescription: '',
      quote: undefined,
    }
  });

  const onSubmit = (formData: RepairFormData) => {
    if (user && data) {
      const newJob = addRepairJob({
        ...formData,
        createdById: user.id,
        status: RepairStatus.PENDING,
      }, user.id);
      
      if (newJob) {
        notifySuccess(`Repair job #${newJob.id} for ${newJob.customerName} logged successfully!`);
        refreshData();
        onClose();
      }
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="customerName" className={labelClasses}>Customer Name</label>
          <input type="text" id="customerName" {...register('customerName')} className={inputClasses} />
          {errors.customerName && <p className={errorClasses}>{errors.customerName.message}</p>}
        </div>
        <div>
          <label htmlFor="contactInfo" className={labelClasses}>Contact Info</label>
          <input type="text" id="contactInfo" {...register('contactInfo')} className={inputClasses} />
          {errors.contactInfo && <p className={errorClasses}>{errors.contactInfo.message}</p>}
        </div>
      </div>
      <div>
        <label htmlFor="deviceDescription" className={labelClasses}>Device Description</label>
        <input type="text" id="deviceDescription" {...register('deviceDescription')} className={inputClasses} placeholder="e.g., iPhone 13 Pro, Blue" />
        {errors.deviceDescription && <p className={errorClasses}>{errors.deviceDescription.message}</p>}
      </div>
      <div>
        <label htmlFor="issueDescription" className={labelClasses}>Issue Description</label>
        <textarea id="issueDescription" {...register('issueDescription')} rows={3} className={inputClasses} placeholder="e.g., Screen is cracked, battery drains quickly..." />
        {errors.issueDescription && <p className={errorClasses}>{errors.issueDescription.message}</p>}
      </div>
       <div className="grid grid-cols-1">
        <div>
            <label htmlFor="quote" className={labelClasses}>Repair Quote ({currency.symbol})</label>
            <input type="number" step="0.01" id="quote" {...register('quote', { valueAsNumber: true })} className={inputClasses} />
            {errors.quote && <p className={errorClasses}>{errors.quote.message}</p>}
        </div>
      </div>
      <div className="flex justify-end pt-4">
        <button
          type="submit"
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Log Repair Job
        </button>
      </div>
    </form>
  );
};

export default LogRepairModal;