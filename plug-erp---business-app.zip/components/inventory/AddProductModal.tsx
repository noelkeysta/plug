
import React, { useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addProduct } from '../../services/mockDataService';
import { User, Product } from '../../types';
import { useData } from '../../contexts/DataContext';

interface AddProductModalProps {
  onClose: () => void;
  user: User | null;
}

const productSchema = z.object({
  name: z.string().min(3, 'Product name must be at least 3 characters'),
  category: z.string().min(3, 'Category must be at least 3 characters'),
  stock: z.number().int().min(0, 'Initial stock cannot be negative'),
  price: z.number().positive('Price must be a positive number'),
  cost: z.number().positive('Cost must be a positive number'),
  supplierId: z.number(),
});

type ProductFormData = z.infer<typeof productSchema>;

const AddProductModal: React.FC<AddProductModalProps> = ({ onClose, user }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currency } = useCurrency();
  const { data, refreshData } = useData();
  const suppliers = data?.suppliers || [];
  const { notifySuccess } = useNotifier();

  const { register, handleSubmit, formState: { errors } } = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: '',
      category: '',
      stock: 0,
      price: undefined,
      cost: undefined,
      supplierId: suppliers[0]?.id || 1,
    }
  });

  const onSubmit = (formData: ProductFormData) => {
    if (user) {
      const { stock, ...productData } = formData;
      const newProduct = addProduct(productData, stock, user.id);
      if (newProduct) {
        refreshData();
        notifySuccess(`Product "${newProduct.name}" added successfully!`);
      }
      onClose();
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label htmlFor="name" className={labelClasses}>Product Name</label>
        <input type="text" id="name" {...register('name')} className={inputClasses} />
        {errors.name && <p className={errorClasses}>{errors.name.message}</p>}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label htmlFor="category" className={labelClasses}>Category</label>
            <input type="text" id="category" {...register('category')} className={inputClasses} />
            {errors.category && <p className={errorClasses}>{errors.category.message}</p>}
        </div>
        <div>
            <label htmlFor="stock" className={labelClasses}>Initial Stock</label>
            <input type="number" id="stock" {...register('stock', { valueAsNumber: true })} className={inputClasses} />
            {errors.stock && <p className={errorClasses}>{errors.stock.message}</p>}
        </div>
      </div>
       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label htmlFor="price" className={labelClasses}>Price ({currency.symbol})</label>
            <input type="number" step="0.01" id="price" {...register('price', { valueAsNumber: true })} className={inputClasses} />
            {errors.price && <p className={errorClasses}>{errors.price.message}</p>}
        </div>
        <div>
            <label htmlFor="cost" className={labelClasses}>Cost ({currency.symbol})</label>
            <input type="number" step="0.01" id="cost" {...register('cost', { valueAsNumber: true })} className={inputClasses} />
            {errors.cost && <p className={errorClasses}>{errors.cost.message}</p>}
        </div>
      </div>
      <div>
        <label htmlFor="supplierId" className={labelClasses}>Supplier</label>
        <select id="supplierId" {...register('supplierId', { valueAsNumber: true })} className={inputClasses}>
          {suppliers.map(s => <option key={s.id} value={s.id} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{s.name}</option>)}
        </select>
        {errors.supplierId && <p className={errorClasses}>{errors.supplierId.message}</p>}
      </div>

      <div className="flex justify-end pt-4">
        <button
          type="submit"
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Add Product
        </button>
      </div>
    </form>
  );
};

export default AddProductModal;
