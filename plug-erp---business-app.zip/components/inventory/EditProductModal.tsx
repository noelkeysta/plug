
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { updateProductPrice } from '../../services/mockDataService';
import { User, Product } from '../../types';
import { useData } from '../../contexts/DataContext';
import { formatCurrency } from '../../utils/formatters';

interface EditProductModalProps {
  onClose: () => void;
  user: User | null;
  product: Product;
}

const productPriceSchema = z.object({
  price: z.number().positive('Price must be a positive number'),
});

type ProductPriceFormData = z.infer<typeof productPriceSchema>;

const EditProductModal: React.FC<EditProductModalProps> = ({ onClose, user, product }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currency } = useCurrency();
  const { refreshData } = useData();
  const { notifySuccess } = useNotifier();

  const { register, handleSubmit, formState: { errors } } = useForm<ProductPriceFormData>({
    resolver: zodResolver(productPriceSchema),
    defaultValues: {
      price: product.price,
    }
  });

  const onSubmit = (formData: ProductPriceFormData) => {
    if (user && product) {
      const updatedProduct = updateProductPrice(product.id, formData.price, user.id);
      if (updatedProduct) {
        refreshData();
        notifySuccess(`Price for "${updatedProduct.name}" updated successfully!`);
      }
      onClose();
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="p-4 rounded-lg bg-black/10">
        <p className={labelClasses}>Product Name</p>
        <p>{product.name}</p>
        <p className={`${labelClasses} mt-2`}>Current Cost</p>
        <p>{formatCurrency(product.cost, currency)}</p>
      </div>

      <div>
          <label htmlFor="price" className={labelClasses}>New Price ({currency.symbol})</label>
          <input type="number" step="0.01" id="price" {...register('price', { valueAsNumber: true })} className={inputClasses} autoFocus/>
          {errors.price && <p className={errorClasses}>{errors.price.message}</p>}
      </div>

      <div className={`flex justify-end pt-4 border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}>
        <button
          type="submit"
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Update Price
        </button>
      </div>
    </form>
  );
};

export default EditProductModal;
