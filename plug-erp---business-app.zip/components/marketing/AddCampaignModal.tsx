
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addMarketingCampaign } from '../../services/mockDataService';
import { useData } from '../../contexts/DataContext';

interface AddCampaignModalProps {
    onClose: () => void;
}

const campaignSchema = z.object({
  name: z.string().min(3, 'Campaign name is required'),
  type: z.enum(['Social Media', 'Email', 'Local Ad', 'Sponsorship']),
  budget: z.number().positive('Budget must be a positive number'),
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().min(1, 'End date is required'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
});

type CampaignFormData = z.infer<typeof campaignSchema>;

const AddCampaignModal: React.FC<AddCampaignModalProps> = ({ onClose }) => {
    const { isDarkMode, themeClasses } = useTheme();
    const { currentUser } = useAuth();
    const { refreshData } = useData();
    const { notifySuccess } = useNotifier();

    const { register, handleSubmit, formState: { errors } } = useForm<CampaignFormData>({
        resolver: zodResolver(campaignSchema),
    });

    const onSubmit = (formData: CampaignFormData) => {
        if (!currentUser) return;
        const result = addMarketingCampaign({
            ...formData,
            startDate: new Date(formData.startDate),
            endDate: new Date(formData.endDate),
        }, currentUser.id);
        
        if (result) {
            notifySuccess('Marketing campaign created successfully!');
            refreshData();
            onClose();
        }
    };
    
    const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
    const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
    const errorClasses = "text-red-400 text-xs mt-1";

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
                <label htmlFor="name" className={labelClasses}>Campaign Name</label>
                <input type="text" id="name" {...register('name')} className={inputClasses} autoFocus />
                {errors.name && <p className={errorClasses}>{errors.name.message}</p>}
            </div>
             <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="type" className={labelClasses}>Campaign Type</label>
                    <select id="type" {...register('type')} className={inputClasses}>
                        <option>Social Media</option>
                        <option>Email</option>
                        <option>Local Ad</option>
                        <option>Sponsorship</option>
                    </select>
                </div>
                <div>
                    <label htmlFor="budget" className={labelClasses}>Budget</label>
                    <input type="number" id="budget" {...register('budget', { valueAsNumber: true })} className={inputClasses} />
                    {errors.budget && <p className={errorClasses}>{errors.budget.message}</p>}
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="startDate" className={labelClasses}>Start Date</label>
                    <input type="date" id="startDate" {...register('startDate')} className={inputClasses} />
                    {errors.startDate && <p className={errorClasses}>{errors.startDate.message}</p>}
                </div>
                <div>
                    <label htmlFor="endDate" className={labelClasses}>End Date</label>
                    <input type="date" id="endDate" {...register('endDate')} className={inputClasses} />
                    {errors.endDate && <p className={errorClasses}>{errors.endDate.message}</p>}
                </div>
            </div>
             <div>
                <label htmlFor="description" className={labelClasses}>Description</label>
                <textarea id="description" {...register('description')} rows={3} className={inputClasses} />
                {errors.description && <p className={errorClasses}>{errors.description.message}</p>}
            </div>
            <div className="flex justify-end pt-4">
                <button type="submit" className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                    Create Campaign
                </button>
            </div>
        </form>
    );
};

export default AddCampaignModal;
