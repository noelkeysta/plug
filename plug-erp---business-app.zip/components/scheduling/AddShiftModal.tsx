
import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useData } from '../../contexts/DataContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addShift } from '../../services/mockDataService';
import set from 'date-fns/set';

interface AddShiftModalProps {
    onClose: () => void;
}

const shiftSchema = z.object({
    employeeId: z.number().min(1, 'Employee is required'),
    date: z.string().min(1, 'Date is required'),
    startTime: z.string().min(1, 'Start time is required'),
    endTime: z.string().min(1, 'End time is required'),
});

type ShiftFormData = z.infer<typeof shiftSchema>;

const AddShiftModal: React.FC<AddShiftModalProps> = ({ onClose }) => {
    const { isDarkMode, themeClasses } = useTheme();
    const { currentUser } = useAuth();
    const { data, refreshData } = useData();
    const { users = [] } = data || {};
    const { notifySuccess, notifyError } = useNotifier();

    const { register, handleSubmit, formState: { errors } } = useForm<ShiftFormData>({
        resolver: zodResolver(shiftSchema),
    });

    const onSubmit = (formData: ShiftFormData) => {
        if (!currentUser) return;
        const [startHour, startMinute] = formData.startTime.split(':').map(Number);
        const [endHour, endMinute] = formData.endTime.split(':').map(Number);

        const startDate = set(new Date(formData.date), { hours: startHour, minutes: startMinute });
        const endDate = set(new Date(formData.date), { hours: endHour, minutes: endMinute });

        if (endDate <= startDate) {
            notifyError('End time must be after start time.');
            return;
        }

        const result = addShift({
            employeeId: formData.employeeId,
            start: startDate,
            end: endDate,
        }, currentUser.id);

        if(result) {
            notifySuccess('Shift added successfully!');
            refreshData();
            onClose();
        }
    };
    
    const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
    const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
    const errorClasses = "text-red-400 text-xs mt-1";

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
                <label htmlFor="employeeId" className={labelClasses}>Employee</label>
                <select id="employeeId" {...register('employeeId', { valueAsNumber: true })} className={inputClasses}>
                    {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
                {errors.employeeId && <p className={errorClasses}>{errors.employeeId.message}</p>}
            </div>
            <div>
                <label htmlFor="date" className={labelClasses}>Date</label>
                <input type="date" id="date" {...register('date')} className={inputClasses} />
                {errors.date && <p className={errorClasses}>{errors.date.message}</p>}
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="startTime" className={labelClasses}>Start Time</label>
                    <input type="time" id="startTime" {...register('startTime')} className={inputClasses} />
                    {errors.startTime && <p className={errorClasses}>{errors.startTime.message}</p>}
                </div>
                <div>
                    <label htmlFor="endTime" className={labelClasses}>End Time</label>
                    <input type="time" id="endTime" {...register('endTime')} className={inputClasses} />
                    {errors.endTime && <p className={errorClasses}>{errors.endTime.message}</p>}
                </div>
            </div>
            <div className="flex justify-end pt-4">
                <button type="submit" className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}>
                    Add Shift
                </button>
            </div>
        </form>
    );
};

export default AddShiftModal;