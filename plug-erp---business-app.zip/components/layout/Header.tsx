
import React, { useState, useEffect, useRef } from 'react';
import { Menu, Search, Moon, Sun, ChevronDown, Landmark, LogOut } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useSearch } from '../../contexts/SearchContext';
import { useDebounce } from '../../hooks/useDebounce';
import { useCurrency } from '../../contexts/CurrencyContext';
import NotificationsDropdown from './NotificationsDropdown';

interface HeaderProps {
  toggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar }) => {
  const { themeClasses, toggleTheme, isDarkMode } = useTheme();
  const { currentUser, logout } = useAuth();
  const { setSearchQuery } = useSearch();
  const { currency, setCurrency, currencies } = useCurrency();
  const [localQuery, setLocalQuery] = useState('');
  const debouncedQuery = useDebounce(localQuery, 500);

  const [isUserMenuOpen, setUserMenuOpen] = useState(false);
  const [isCurrencyMenuOpen, setCurrencyMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const currencyMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setSearchQuery(debouncedQuery);
  }, [debouncedQuery, setSearchQuery]);
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
            setUserMenuOpen(false);
        }
        if (currencyMenuRef.current && !currencyMenuRef.current.contains(event.target as Node)) {
            setCurrencyMenuOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    setUserMenuOpen(false);
    logout();
  }

  return (
    <header className="sticky top-0 z-20 p-6 flex items-center justify-between backdrop-blur-sm">
      <div className="flex items-center space-x-4">
        <button
          onClick={toggleSidebar}
          className={`p-3 rounded-full lg:hidden ${themeClasses.card} hover:scale-110 transition-all duration-300`}
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="relative hidden sm:block">
          <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`} />
          <input
            type="text"
            placeholder="Search anything..."
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            className={`${themeClasses.card} ${themeClasses.searchInput}`}
          />
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <div className="relative" ref={userMenuRef}>
           <button onClick={() => setUserMenuOpen(!isUserMenuOpen)} className={`flex items-center space-x-2 p-2 pr-3 rounded-full ${themeClasses.card}`}>
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold shadow-lg text-sm">
              {currentUser?.avatar}
            </div>
            <span className="font-semibold hidden md:inline text-sm">{currentUser?.name}</span>
            <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${isUserMenuOpen ? 'rotate-180' : ''}`} />
          </button>
          {isUserMenuOpen && (
            <div className={`absolute right-0 mt-2 w-56 rounded-2xl ${themeClasses.card} shadow-lg p-2 z-30`}>
               <div className="my-1" />
               <button
                  onClick={handleLogout}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm flex items-center ${isDarkMode ? 'text-red-400 hover:bg-red-500/10' : 'text-red-600 hover:bg-red-500/10'}`}
                >
                  <LogOut className="w-4 h-4 mr-2" /> Logout
                </button>
            </div>
          )}
        </div>
        
        <div className="relative" ref={currencyMenuRef}>
          <button onClick={() => setCurrencyMenuOpen(!isCurrencyMenuOpen)} className={`p-3 rounded-full ${themeClasses.card} hover:scale-110 transition-all duration-300`}>
            <Landmark className="w-5 h-5" />
          </button>
          {isCurrencyMenuOpen && (
            <div className={`absolute right-0 mt-2 w-48 rounded-2xl ${themeClasses.card} shadow-lg p-2 z-30`}>
              <p className={`px-3 py-2 text-xs font-semibold ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Select Currency</p>
              {currencies.map(c => (
                <button
                  key={c.code}
                  onClick={() => { setCurrency(c); setCurrencyMenuOpen(false); }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm flex items-center ${
                    currency.code === c.code
                    ? `${isDarkMode ? 'bg-amber-500/20 text-amber-300' : 'bg-blue-500/10 text-blue-700'}` 
                    : `${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-black/5'}`
                  }`}
                >
                  <span className="font-bold w-6">{c.symbol}</span> {c.name}
                </button>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={toggleTheme}
          className={`p-3 rounded-full ${themeClasses.card} hover:scale-110 transition-all duration-300 group`}
        >
          {isDarkMode ? 
            <Sun className="w-5 h-5 text-amber-400 group-hover:rotate-180 transition-transform duration-500" /> : 
            <Moon className="w-5 h-5 text-blue-600 group-hover:rotate-180 transition-transform duration-500" />
          }
        </button>
        
        <NotificationsDropdown />
      </div>
    </header>
  );
};
export default Header;