
import React from 'react';
import { NavLink } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useSettings } from '../../contexts/SettingsContext';
import { MENU_ITEMS } from '../../constants';

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar }) => {
  const { themeClasses, isDarkMode } = useTheme();
  const { currentUser } = useAuth();
  const { settings } = useSettings();

  const filteredMenuItems = MENU_ITEMS.filter(item => 
    currentUser && item.allowedRoles.includes(currentUser.role)
  );
  
  return (
    <aside className={`
      ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 w-72
      ${themeClasses.sidebar} rounded-none lg:rounded-r-3xl
      transition-all duration-300 ease-in-out
      flex flex-col p-6
    `}>
      <div className="flex-shrink-0 mb-12">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 bg-clip-text text-transparent drop-shadow-lg">
          {settings.companyName}
        </h1>
        <p className={`text-sm mt-2 ${isDarkMode ? 'text-blue-400' : 'text-blue-700'} font-medium`}>
          ERP System
        </p>
      </div>

      <div className="flex-grow overflow-y-auto -mr-4 pr-4">
        <nav className="space-y-2">
          {filteredMenuItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.id}
                to={item.path}
                end={item.path === '/'}
                onClick={() => { if (window.innerWidth < 1024) toggleSidebar(); }}
                className={({ isActive }) => `
                  w-full flex items-center py-4 px-5 rounded-2xl transition-all duration-300 group
                  ${isActive 
                    ? `${isDarkMode 
                        ? 'bg-gradient-to-r from-amber-500/20 to-blue-500/20 text-amber-300 shadow-lg shadow-amber-500/10' 
                        : 'bg-blue-100 text-blue-700 font-bold shadow-lg shadow-blue-500/20'
                      } ${isDarkMode ? 'border border-amber-500/30' : ''}` 
                    : `hover:bg-gradient-to-r ${isDarkMode 
                        ? 'hover:from-amber-500/10 hover:to-blue-500/10 hover:text-amber-400' 
                        : 'hover:from-blue-500/5 hover:to-teal-500/5 hover:text-blue-600'
                      } hover:scale-105`
                  }
                `}
              >
                <Icon className="w-5 h-5 group-hover:scale-110 transition-transform duration-200" />
                <span className="ml-4 font-semibold">{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {currentUser && (
        <div className={`w-full flex-shrink-0 pt-4 mt-4 flex items-center p-3 rounded-2xl ${themeClasses.card} border-none`}>
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold shadow-lg">
            {currentUser.avatar}
          </div>
          <div className="ml-3 overflow-hidden">
            <p className="font-semibold text-sm truncate">{currentUser.name}</p>
            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'} truncate`}>{currentUser.role}</p>
          </div>
        </div>
      )}
    </aside>
  );
};
export default Sidebar;
