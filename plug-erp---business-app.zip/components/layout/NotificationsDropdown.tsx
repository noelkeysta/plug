
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, AlertCircle, CheckCircle, Package, MessageSquare } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { useData } from '../../contexts/DataContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { formatDistanceToNow } from 'date-fns';
import { Notification, NotificationType } from '../../types';

const NotificationsDropdown: React.FC = () => {
    const { themeClasses, isDarkMode } = useTheme();
    const { data } = useData();
    const { markAsRead, markAllAsRead } = useNotifier();
    const navigate = useNavigate();
    const notifications = data?.notifications || [];

    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const unreadCount = notifications.filter(n => !n.isRead).length;

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const getNotificationIcon = (type: Notification['type']) => {
        switch (type) {
            case NotificationType.LOW_STOCK: return <AlertCircle className="text-yellow-400" />;
            case NotificationType.OUT_OF_STOCK: return <AlertCircle className="text-red-400" />;
            case NotificationType.PO_SHIPPED: return <Package className="text-blue-400" />;
            case NotificationType.PENDING_PO: return <Package className="text-yellow-500" />;
            case NotificationType.PO_RECEIVED: return <CheckCircle className="text-emerald-400" />;
            case NotificationType.PAYROLL_PROCESSED: return <CheckCircle className="text-emerald-400" />;
            case NotificationType.CHAT_MESSAGE: return <MessageSquare className="text-cyan-400" />;
            default: return <Bell />;
        }
    };
    
    const handleNotificationClick = (notification: Notification) => {
        markAsRead(notification.id);
        setIsOpen(false);
        if (notification.type === NotificationType.CHAT_MESSAGE && notification.relatedId) {
            navigate(`/chat/${notification.relatedId}`);
        }
    }

    return (
        <div className="relative" ref={dropdownRef}>
            <button 
                onClick={() => setIsOpen(!isOpen)}
                className={`p-3 rounded-full ${themeClasses.card} hover:scale-110 transition-all duration-300 relative`}
            >
                <Bell className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'animate-bounce' : ''}`} />
                {unreadCount > 0 && (
                     <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                        {unreadCount}
                     </span>
                )}
            </button>
            {isOpen && (
                <div className={`absolute right-0 mt-2 w-80 rounded-2xl ${themeClasses.card} shadow-lg p-2 z-30`}>
                    <div className="flex justify-between items-center px-2 py-2">
                        <p className="font-bold">Notifications</p>
                        {unreadCount > 0 && (
                            <button onClick={() => { markAllAsRead(); }} className="text-xs font-semibold text-amber-400 hover:underline">
                                Mark all as read
                            </button>
                        )}
                    </div>
                    <div className="max-h-80 overflow-y-auto space-y-1">
                        {notifications.length > 0 ? notifications.slice(0, 5).map(n => (
                            <div 
                                key={n.id} 
                                onClick={() => handleNotificationClick(n)}
                                className={`p-3 rounded-lg flex items-start gap-3 cursor-pointer ${n.isRead ? 'opacity-60' : 'font-semibold'} ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-black/5'}`}
                            >
                                <div className="mt-1 flex-shrink-0">{getNotificationIcon(n.type)}</div>
                                <div>
                                    <p className="text-sm leading-tight">
                                        {n.actorName && <span className="font-semibold">{n.actorName}: </span>}
                                        {n.message}
                                    </p>
                                    <p className={`text-xs mt-1 ${n.isRead ? 'opacity-80' : 'opacity-60'} font-normal`}>
                                        {formatDistanceToNow(n.timestamp, { addSuffix: true })}
                                    </p>
                                </div>
                            </div>
                        )) : (
                            <div className="text-center p-8 text-slate-500">
                                <p>No notifications yet.</p>
                            </div>
                        )}
                    </div>
                    <div className="pt-2 mt-1 border-t border-slate-700/50">
                        <button onClick={() => { setIsOpen(false); navigate('/notifications'); }} className="w-full text-center py-2 text-sm font-semibold text-amber-400 hover:bg-white/5 rounded-lg">
                            View All Notifications
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default NotificationsDropdown;
