
import React from 'react';
import { useDashboardSettings } from '../../contexts/DashboardSettingsContext';
import { useTheme } from '../../contexts/ThemeContext';

interface CustomizeDashboardModalProps {
  onClose: () => void;
}

const CustomizeDashboardModal: React.FC<CustomizeDashboardModalProps> = ({ onClose }) => {
  const { kpiSettings, toggleKpiVisibility, availableKpis } = useDashboardSettings();
  const { isDarkMode, themeClasses } = useTheme();

  return (
    <div className="space-y-4">
        <p className="text-sm text-slate-400">
            Select which KPIs to display on your dashboard. Changes are saved automatically.
        </p>
        <div className="space-y-3">
            {availableKpis.map(kpi => (
                <div key={kpi.id} className={`p-3 rounded-lg flex items-center justify-between ${isDarkMode ? 'bg-slate-700/50' : 'bg-slate-100'}`}>
                    <span className="font-semibold">{kpi.title}</span>
                    <label htmlFor={`toggle-${kpi.id}`} className="relative inline-flex items-center cursor-pointer">
                        <input
                            type="checkbox"
                            id={`toggle-${kpi.id}`}
                            className="sr-only peer"
                            checked={kpiSettings.visibility[kpi.id] ?? true}
                            onChange={() => toggleKpiVisibility(kpi.id)}
                        />
                        <div className="w-11 h-6 bg-slate-500 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gradient-to-r from-amber-500 to-blue-500"></div>
                    </label>
                </div>
            ))}
        </div>
        <div className="flex justify-end pt-4">
            <button
                onClick={onClose}
                className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
            >
                Done
            </button>
      </div>
    </div>
  );
};

export default CustomizeDashboardModal;
