
import React from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { UserRole } from '../../types';
import Card from '../ui/Card';
import { CheckCircle, Zap, Archive, Users, Truck, ShoppingCart, PieChart, Wrench, Briefcase, BarChart, SlidersHorizontal, ArrowRight } from 'lucide-react';

const roleFocusMap = {
  [UserRole.ADMINISTRATOR]: {
    title: 'Administrator Focus',
    icon: SlidersHorizontal,
    tasks: [
      { text: 'Oversee all operational modules', path: '/reports' },
      { text: 'Manage user roles and system settings', path: '/systems' },
      { text: 'Review high-level reports and audit logs', path: '/systems' }
    ]
  },
  [UserRole.GENERAL_MANAGER]: {
    title: 'General Manager Focus',
    icon: Briefcase,
    tasks: [
      { text: 'Monitor dashboard KPIs for business health', path: '/' },
      { text: 'Review sales, finance, and inventory reports', path: '/reports' },
      { text: 'Oversee purchasing and supplier relations', path: '/purchasing' }
    ]
  },
  [UserRole.SALES_MANAGER]: {
    title: 'Sales Manager Focus',
    icon: BarChart,
    tasks: [
      { text: 'Analyze sales team performance', path: '/reports' },
      { text: 'Manage customer relationships', path: '/customers' },
      { text: 'Oversee Point of Sale operations', path: '/sales' }
    ]
  },
  [UserRole.INVENTORY_MANAGER]: {
    title: 'Inventory Manager Focus',
    icon: Archive,
    tasks: [
      { text: 'Monitor stock levels and prevent stockouts', path: '/inventory' },
      { text: 'Manage purchase orders and supplier deliveries', path: '/purchasing' },
      { text: 'Conduct inventory valuation and audits', path: '/reports' }
    ]
  },
  [UserRole.ACCOUNTANT]: {
    title: 'Accountant Focus',
    icon: PieChart,
    tasks: [
      { text: 'Log and categorize all business expenses', path: '/finance' },
      { text: 'Process monthly payroll', path: '/payroll' },
      { text: 'Analyze financial statements and profitability', path: '/reports' }
    ]
  },
  [UserRole.SALES_ASSOCIATE]: {
    title: 'Sales Associate Focus',
    icon: Zap,
    tasks: [
      { text: 'Process customer sales accurately and efficiently', path: '/sales' },
      { text: 'Manage cash and card transactions', path: '/sales' },
      { text: 'Assist customers and log repair jobs', path: '/repairs' }
    ]
  },
};

const RoleFocusWidget: React.FC = () => {
  const { themeClasses, isDarkMode } = useTheme();
  const { currentUser } = useAuth();
  
  if (!currentUser) return null;

  const focus = roleFocusMap[currentUser.role];
  
  if (!focus) return null;

  const Icon = focus.icon;

  return (
    <Card className="h-full">
      <div className="flex items-center gap-3 mb-6">
        <Icon className={`w-6 h-6 ${themeClasses.textGradient}`} />
        <h3 className={`text-xl font-bold ${themeClasses.textGradient}`}>
          {focus.title}
        </h3>
      </div>
      <ul className="space-y-3">
        {focus.tasks.map((task, index) => (
          <li key={index}>
            <Link to={task.path} className={`flex items-start gap-3 p-2 rounded-lg group transition-colors ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-black/5'}`}>
              <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="flex-grow">{task.text}</span>
              <ArrowRight className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition-colors opacity-0 group-hover:opacity-100" />
            </Link>
          </li>
        ))}
      </ul>
    </Card>
  );
};

export default RoleFocusWidget;
