
import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
import { useData } from '../../contexts/DataContext';
import { Notification, NotificationType, PurchaseOrderStatus } from '../../types';
import Card from '../ui/Card';
import { AlertTriangle, PackageCheck, Package, ArrowRight } from 'lucide-react';

const AlertsWidget: React.FC = () => {
    const { themeClasses, isDarkMode } = useTheme();
    const { data } = useData();
    const { notifications = [], purchaseOrders = [], products = [] } = data || {};

    const alerts = useMemo(() => {
        const lowStockAlerts = notifications
            .filter(n => (n.type === NotificationType.LOW_STOCK || n.type === NotificationType.OUT_OF_STOCK) && !n.isRead)
            .map(n => ({
                id: `notif-${n.id}`,
                type: 'low-stock',
                message: n.message,
                path: `/inventory?product=${n.relatedId}`
            }));

        const pendingPoAlerts = purchaseOrders
            .filter(po => po.status === PurchaseOrderStatus.PENDING || po.status === PurchaseOrderStatus.SHIPPED)
            .map(po => ({
                id: `po-${po.id}`,
                type: 'pending-po',
                message: `PO ${po.id} is ${po.status}`,
                path: `/purchasing?po=${po.id}`
            }));
            
        return [...lowStockAlerts, ...pendingPoAlerts].slice(0, 5);
    }, [notifications, purchaseOrders, products]);
    
    const getAlertIcon = (type: string) => {
        switch(type) {
            case 'low-stock': return <AlertTriangle className="text-yellow-400 w-5 h-5" />;
            case 'pending-po': return <Package className="text-blue-400 w-5 h-5" />;
            default: return <AlertTriangle className="text-slate-400 w-5 h-5" />;
        }
    };

    return (
        <Card className="h-full">
            <h3 className={`text-xl font-bold mb-4 ${themeClasses.textGradient}`}>
                Critical Alerts
            </h3>
            <div className="space-y-2">
                {alerts.length > 0 ? (
                    alerts.map(alert => (
                        <Link to={alert.path} key={alert.id} className={`block p-3 rounded-lg transition-colors duration-200 ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-black/5'}`}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    {getAlertIcon(alert.type)}
                                    <span className="font-semibold">{alert.message}</span>
                                </div>
                                <ArrowRight className="w-5 h-5 text-slate-500" />
                            </div>
                        </Link>
                    ))
                ) : (
                    <div className="text-center text-slate-500 py-10">
                        <PackageCheck className="w-12 h-12 mx-auto mb-2" />
                        <p className="font-semibold">All Clear!</p>
                        <p className="text-sm">No critical alerts at this time.</p>
                    </div>
                )}
            </div>
        </Card>
    );
};

export default AlertsWidget;
