import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import Card from '../ui/Card';
import { formatCurrency } from '../../utils/formatters';

export interface SalesData {
  name: string;
  total: number;
}

interface SalesChartProps {
  data: SalesData[];
  title: string;
}

const SalesChart: React.FC<SalesChartProps> = ({ data, title }) => {
  const { themeClasses, isDarkMode } = useTheme();
  const { currency } = useCurrency();

  const maxValue = Math.max(...data.map(d => d.total), 1); // Avoid division by zero
  const chartHeight = 250;
  const barWidth = 40;
  const barMargin = 20;
  const chartWidth = data.length * (barWidth + barMargin);

  const formatShortCurrency = (value: number) => {
    if (value >= 1000000) return `${currency.symbol}${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${currency.symbol}${(value / 1000).toFixed(1)}k`;
    return formatCurrency(value, currency);
  }

  return (
    <Card>
      <h3 className={`text-xl font-bold mb-6 ${themeClasses.textGradient}`}>
        {title}
      </h3>
      <div className="overflow-x-auto pb-4">
        <svg width={chartWidth} height={chartHeight} aria-label="Sales chart showing revenue">
          <g>
            {data.map((d, i) => {
              const barHeight = d.total > 0 ? (d.total / maxValue) * (chartHeight - 40) : 0;
              const x = i * (barWidth + barMargin);
              const y = chartHeight - barHeight - 20;

              return (
                <g key={d.name} className="group">
                  <title>{d.name}: {formatCurrency(d.total, currency)}</title>
                  <rect
                    x={x}
                    y={y}
                    width={barWidth}
                    height={barHeight}
                    rx="4"
                    className={`${themeClasses.progressBar} transition-all duration-300 group-hover:opacity-80`}
                  />
                  <text
                    x={x + barWidth / 2}
                    y={y - 8}
                    textAnchor="middle"
                    className={`text-xs font-bold transition-all duration-300 opacity-0 group-hover:opacity-100 ${isDarkMode ? 'fill-white' : 'fill-slate-800'}`}
                  >
                    {formatShortCurrency(d.total)}
                  </text>
                  <text
                    x={x + barWidth / 2}
                    y={chartHeight}
                    textAnchor="middle"
                    className={`text-xs font-semibold ${isDarkMode ? 'fill-slate-400' : 'fill-slate-600'}`}
                  >
                    {d.name}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>
      </div>
    </Card>
  );
};

export default SalesChart;