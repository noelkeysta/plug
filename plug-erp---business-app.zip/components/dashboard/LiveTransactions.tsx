import React from 'react';
import { ShoppingCart, CornerDownLeft } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import Card from '../ui/Card';
import { Transaction, TransactionType, Product } from '../../types';
import { formatDistanceToNow } from 'date-fns';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';

interface LiveTransactionsProps {
  transactions: Transaction[];
  productMap: Record<string, Product>;
}

const LiveTransactions: React.FC<LiveTransactionsProps> = ({ transactions, productMap }) => {
  const { themeClasses, isDarkMode } = useTheme();
  const { currency } = useCurrency();
  
  const getTransactionIcon = (type: TransactionType) => {
    return type === 'sale' ? ShoppingCart : CornerDownLeft;
  };
  
  const getTransactionColor = (type: TransactionType) => {
    return type === 'sale' ? (isDarkMode ? 'text-amber-400' : 'text-blue-600') : (isDarkMode ? 'text-blue-400' : 'text-teal-600');
  };

  const recentTransactions = transactions.slice(0, 5);

  return (
    <Card>
      <div className="flex items-center justify-between mb-6">
        <h3 className={`text-xl font-bold ${themeClasses.textGradient}`}>
          Live Transactions
        </h3>
        <div className={`w-3 h-3 rounded-full ${isDarkMode ? 'bg-amber-400' : 'bg-blue-500'} animate-pulse`}></div>
      </div>
      <div className="space-y-4">
        {recentTransactions.map((tx) => {
          const Icon = getTransactionIcon(tx.type);
          const firstItemName = productMap[tx.items[0]?.productId]?.name || 'Unknown Item';
          
          return (
            <div key={tx.id} className={`flex items-center p-4 rounded-2xl transition-all duration-300 hover:scale-105 ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-slate-100'}`}>
              <div className={`p-3 rounded-full mr-4 ${isDarkMode ? 'bg-slate-700/50' : 'bg-slate-200/60'}`}>
                <Icon className={`w-5 h-5 ${getTransactionColor(tx.type)}`} />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-base capitalize">{tx.type} #{tx.id}</p>
                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{firstItemName}{tx.items.length > 1 ? ` +${tx.items.length - 1} more` : ''}</p>
                <p className={`text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>{formatDistanceToNow(tx.timestamp, { addSuffix: true })}</p>
              </div>
              <p className={`font-bold text-lg ${tx.type === 'sale' ? 'text-emerald-400' : 'text-red-400'}`}>
                {tx.type === 'sale' ? '+' : '-'}{formatCurrency(Math.abs(tx.totalAmount), currency)}
              </p>
            </div>
          );
        })}
      </div>
    </Card>
  );
};

export default LiveTransactions;
