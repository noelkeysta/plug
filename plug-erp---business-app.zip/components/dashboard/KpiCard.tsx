
import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import Card from '../ui/Card';

interface KpiCardProps {
  title: string;
  value: string;
  change: string;
  positive: boolean;
  icon: LucideIcon;
}

const KpiCard: React.FC<KpiCardProps> = ({ title, value, change, positive, icon: Icon }) => {
  const { themeClasses, isDarkMode } = useTheme();

  return (
    <Card className="group hover:transform hover:scale-105 hover:-translate-y-2 transition-all duration-500 shadow-lg hover:shadow-2xl cursor-pointer">
      <div className="flex items-center justify-between mb-4">
        <h3 className={`text-lg font-semibold ${isDarkMode ? 'text-slate-400 group-hover:text-white' : 'text-slate-500 group-hover:text-slate-900'}`}>
          {title}
        </h3>
        <div className={`p-3 rounded-full ${themeClasses.kpiIconBg} group-hover:scale-110 transition-transform duration-300`}>
          <Icon className={`w-6 h-6 ${themeClasses.kpiIconText}`} />
        </div>
      </div>
      <p className={`text-4xl font-bold mb-3 ${themeClasses.textGradient}`}>
        {value}
      </p>
      <div className={`flex items-center ${positive ? 'text-emerald-400' : 'text-red-400'}`}>
        {positive ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
        <span className="ml-2 font-semibold">{change}</span>
      </div>
    </Card>
  );
};

export default KpiCard;
