
import React from 'react';
import Card from '../ui/Card';
import { useTheme } from '../../contexts/ThemeContext';
import { Product } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';

interface TopProductsProps {
  topProducts: (Product & { unitsSold: number; revenue: number; progress: number })[];
  title: string;
}

const TopProducts: React.FC<TopProductsProps> = ({ topProducts, title }) => {
  const { themeClasses, isDarkMode } = useTheme();
  const { currency } = useCurrency();

  return (
    <Card className="h-full">
      <h3 className={`text-xl font-bold mb-6 ${themeClasses.textGradient}`}>
        {title}
      </h3>
      <div className="space-y-4">
        {topProducts.length === 0 ? (
           <div className="text-center text-slate-500 py-10">
                <p>No product sales data for this period.</p>
            </div>
        ) : topProducts.slice(0, 4).map((product) => (
          <div key={product.id} className={`p-3 rounded-2xl transition-all duration-300 ${isDarkMode ? 'hover:bg-white/5' : 'hover:bg-slate-100'}`}>
            <div className="flex justify-between items-center mb-2">
              <div>
                <p className="font-semibold text-base">{product.name}</p>
                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {product.unitsSold} units sold
                </p>
              </div>
              <div className="text-right">
                <p className={`font-bold text-base ${themeClasses.textGradient}`}>
                  {formatCurrency(product.revenue, currency)}
                </p>
                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Revenue
                </p>
              </div>
            </div>
            <div className={`w-full ${themeClasses.progressBg} rounded-full h-2 overflow-hidden`}>
              <div
                className={`${themeClasses.progressBar} h-2 rounded-full transition-all duration-1000 shadow-sm`}
                style={{ width: `${product.progress}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default TopProducts;
