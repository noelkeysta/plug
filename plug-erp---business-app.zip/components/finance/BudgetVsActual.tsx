
import React, { useMemo } from 'react';
import { Budget, Expense, ExpenseCategory } from '../../types';
import Card from '../ui/Card';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';

interface BudgetVsActualProps {
    budgets: Budget[];
    expenses: Expense[];
    onCategoryClick: (category: ExpenseCategory | 'Salaries') => void;
}

const BudgetVsActual: React.FC<BudgetVsActualProps> = ({ budgets, expenses, onCategoryClick }) => {
    const { themeClasses, isDarkMode } = useTheme();
    const { currency } = useCurrency();
    
    const actuals = useMemo(() => {
        return expenses.reduce((acc, expense) => {
            const categoryKey = expense.category === ExpenseCategory.SALARIES ? 'Salaries' : expense.category;
            acc[categoryKey] = (acc[categoryKey] || 0) + expense.amount;
            return acc;
        }, {} as Record<string, number>);
    }, [expenses]);
    
    const budgetData = useMemo(() => {
        return budgets.map(budget => {
            const actualAmount = actuals[budget.category] || 0;
            const percentage = budget.amount > 0 ? (actualAmount / budget.amount) * 100 : 0;
            return {
                ...budget,
                actual: actualAmount,
                percentage: Math.min(percentage, 100),
                overage: Math.max(0, percentage - 100),
            };
        }).sort((a,b) => b.amount - a.amount);
    }, [budgets, actuals]);

    return (
        <Card className="h-full">
            <h3 className={`text-xl font-bold mb-6 ${themeClasses.textGradient}`}>Monthly Budget vs Actuals</h3>
            <div className="space-y-5">
                {budgetData.map(item => {
                    const overageWidth = item.overage > 0 ? Math.min(item.overage, 100) : 0;
                    let barColor = themeClasses.progressBar;
                    if (item.percentage > 90) barColor = 'bg-yellow-500';
                    if (item.percentage >= 100) barColor = 'bg-red-500';

                    return (
                        <div key={item.category} onClick={() => onCategoryClick(item.category)} className="cursor-pointer group">
                            <div className="flex justify-between items-baseline mb-1 text-sm">
                                <span className="font-semibold group-hover:text-amber-400 transition-colors">{item.category}</span>
                                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-500'}>{formatCurrency(item.actual, currency)} / {formatCurrency(item.amount, currency)}</span>
                            </div>
                             <div className={`w-full ${themeClasses.progressBg} rounded-full h-3 relative overflow-hidden`}>
                                <div
                                    className={`${barColor} h-3 rounded-full absolute left-0 top-0 transition-all duration-500 group-hover:scale-y-150 origin-bottom`}
                                    style={{ width: `${item.percentage}%` }}
                                />
                                {overageWidth > 0 && (
                                     <div
                                        className="bg-red-500/50 h-3 rounded-r-full absolute left-0 top-0 animate-pulse"
                                        style={{ width: `${item.percentage}%` }}
                                    />
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </Card>
    );
};

export default BudgetVsActual;
