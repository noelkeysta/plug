
import React from 'react';
import type { LucideIcon } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import Card from '../ui/Card';

interface FinancialSummaryCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  description?: string;
  colorClass: string;
}

const FinancialSummaryCard: React.FC<FinancialSummaryCardProps> = ({ title, value, icon: Icon, description, colorClass }) => {
  const { themeClasses, isDarkMode } = useTheme();

  return (
    <Card className="flex items-center gap-6 p-6 group hover:transform hover:scale-105 transition-all duration-300">
      <div className={`p-4 rounded-full ${colorClass}/20 group-hover:scale-110 transition-transform duration-300`}>
        <Icon className={`w-8 h-8 ${colorClass}`} />
      </div>
      <div>
        <p className="text-slate-400 text-lg font-medium">{title}</p>
        <p className={`text-3xl font-bold ${themeClasses.textGradient}`}>{value}</p>
        {description && <p className="text-xs text-slate-500 mt-1">{description}</p>}
      </div>
    </Card>
  );
};

export default FinancialSummaryCard;
