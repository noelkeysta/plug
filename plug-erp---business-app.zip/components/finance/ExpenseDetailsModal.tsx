
import React from 'react';
import { Expense, ExpenseCategory } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { format } from 'date-fns';

interface ExpenseDetailsModalProps {
  category: ExpenseCategory | 'Salaries';
  allExpenses: Expense[];
}

const ExpenseDetailsModal: React.FC<ExpenseDetailsModalProps> = ({ category, allExpenses }) => {
  const { isDarkMode } = useTheme();
  const { currency } = useCurrency();

  const categoryExpenses = allExpenses.filter(e => {
    if (category === 'Salaries') return e.category === ExpenseCategory.SALARIES;
    return e.category === category;
  });

  return (
    <div className="max-h-[60vh] flex flex-col">
        <div className="overflow-y-auto pr-2 -mr-4">
            <table className="w-full text-left text-sm">
                <thead className={`sticky top-0 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`}>
                    <tr className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
                        <th className="p-2">Date</th>
                        <th className="p-2">Description</th>
                        <th className="p-2 text-right">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    {categoryExpenses.map((expense) => (
                        <tr key={expense.id} className={`border-b ${isDarkMode ? 'border-slate-800/50' : 'border-slate-200'}`}>
                            <td className="p-2 whitespace-nowrap">{format(new Date(expense.date), 'dd MMM yyyy')}</td>
                            <td className="p-2">{expense.description}</td>
                            <td className="p-2 text-right font-mono font-semibold">{formatCurrency(expense.amount, currency)}</td>
                        </tr>
                    ))}
                    {categoryExpenses.length === 0 && (
                        <tr>
                            <td colSpan={3} className="text-center p-8 text-slate-500">
                                No expenses recorded for this category in the selected period.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    </div>
  );
};

export default ExpenseDetailsModal;
