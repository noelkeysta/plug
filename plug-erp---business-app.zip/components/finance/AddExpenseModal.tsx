
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useAuth } from '../../contexts/AuthContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addExpense } from '../../services/mockDataService';
import { ExpenseCategory } from '../../types';
import { useData } from '../../contexts/DataContext';

interface AddExpenseModalProps {
  onClose: () => void;
}

const expenseSchema = z.object({
  description: z.string().min(3, 'Description must be at least 3 characters'),
  category: z.nativeEnum(ExpenseCategory),
  amount: z.number().positive('Amount must be a positive number'),
});

type ExpenseFormData = z.infer<typeof expenseSchema>;

const AddExpenseModal: React.FC<AddExpenseModalProps> = ({ onClose }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currency } = useCurrency();
  const { currentUser } = useAuth();
  const { notifySuccess } = useNotifier();
  const { refreshData } = useData();

  const { register, handleSubmit, formState: { errors } } = useForm<ExpenseFormData>({
    resolver: zodResolver(expenseSchema),
    defaultValues: {
      description: '',
      category: ExpenseCategory.OTHER,
      amount: undefined,
    }
  });

  const onSubmit = (data: ExpenseFormData) => {
    if (currentUser) {
      const newExpense = addExpense({ ...data, recordedById: currentUser.id });
      if (newExpense) {
        refreshData();
        notifySuccess('Expense logged successfully!');
      }
      onClose();
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label htmlFor="description" className={labelClasses}>Description</label>
        <input type="text" id="description" {...register('description')} className={inputClasses} />
        {errors.description && <p className={errorClasses}>{errors.description.message}</p>}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="category" className={labelClasses}>Category</label>
          <select id="category" {...register('category')} className={inputClasses}>
            {Object.values(ExpenseCategory).map(cat => (
              <option key={cat} value={cat} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{cat}</option>
            ))}
          </select>
          {errors.category && <p className={errorClasses}>{errors.category.message}</p>}
        </div>
        <div>
          <label htmlFor="amount" className={labelClasses}>Amount ({currency.symbol})</label>
          <input type="number" step="0.01" id="amount" {...register('amount', { valueAsNumber: true })} className={inputClasses} />
          {errors.amount && <p className={errorClasses}>{errors.amount.message}</p>}
        </div>
      </div>
      
      <div className="flex justify-end pt-4">
        <button
          type="submit"
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Log Expense
        </button>
      </div>
    </form>
  );
};

export default AddExpenseModal;
