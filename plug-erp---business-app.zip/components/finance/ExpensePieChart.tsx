import React, { useMemo } from 'react';
import { Expense } from '../../types';
import Card from '../ui/Card';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';

interface ExpensePieChartProps {
    expenses: Expense[];
}

const COLORS = [
    '#3b82f6', // blue-500
    '#f59e0b', // amber-500
    '#10b981', // emerald-500
    '#ec4899', // pink-500
    '#8b5cf6', // violet-500
    '#6366f1', // indigo-500
    '#ef4444', // red-500
];

const PieChartSlice: React.FC<{ slice: any, cx: number, cy: number, radius: number }> = ({ slice, cx, cy, radius }) => {
    const { path, color } = slice;
    return <path d={path} fill={color} />;
};

const ExpensePieChart: React.FC<ExpensePieChartProps> = ({ expenses }) => {
    const { themeClasses, isDarkMode } = useTheme();
    const { currency } = useCurrency();

    const chartData = useMemo(() => {
        const breakdown = expenses.reduce((acc, expense) => {
            acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
            return acc;
        }, {} as Record<string, number>);

        return Object.entries(breakdown)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value);
    }, [expenses]);
    
    const totalExpenses = useMemo(() => chartData.reduce((sum, item) => sum + item.value, 0), [chartData]);

    const getCoordinatesForPercent = (percent: number, radius: number) => {
        const x = radius * Math.cos(2 * Math.PI * percent);
        const y = radius * Math.sin(2 * Math.PI * percent);
        return [x, y];
    };

    const slices = useMemo(() => {
        if (totalExpenses === 0) return [];
        let cumulativePercent = 0;
        return chartData.map((item, index) => {
            const percent = item.value / totalExpenses;
            const [startX, startY] = getCoordinatesForPercent(cumulativePercent, 90);
            cumulativePercent += percent;
            const [endX, endY] = getCoordinatesForPercent(cumulativePercent, 90);
            const largeArcFlag = percent > 0.5 ? 1 : 0;
            const path = [
                `M ${startX} ${startY}`, // Move
                `A 90 90 0 ${largeArcFlag} 1 ${endX} ${endY}`, // Arc
                `L 0 0`, // Line to center
            ].join(' ');

            return {
                ...item,
                path,
                color: COLORS[index % COLORS.length]
            };
        });
    }, [chartData, totalExpenses]);

    return (
        <Card className="h-full">
            <h3 className={`text-xl font-bold mb-6 ${themeClasses.textGradient}`}>Expense Breakdown</h3>
            {totalExpenses > 0 ? (
                <div className="flex flex-col items-center">
                    <svg viewBox="-100 -100 200 200" width="200" height="200" style={{ transform: 'rotate(-90deg)' }}>
                        {slices.map((slice, i) => <PieChartSlice key={i} slice={slice} cx={100} cy={100} radius={90} />)}
                    </svg>
                    <div className="w-full mt-6 space-y-2 text-sm">
                        {slices.map((slice, index) => (
                            <div key={index} className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: slice.color }}></div>
                                    <span className={isDarkMode ? 'text-slate-300' : 'text-slate-700'}>{slice.name}</span>
                                </div>
                                <div className="font-semibold text-right">
                                    <span className={isDarkMode ? 'text-white' : 'text-black'}>
                                        {((slice.value / totalExpenses) * 100).toFixed(1)}%
                                    </span>
                                    <span className="text-xs text-slate-400 ml-2">
                                        ({formatCurrency(slice.value, currency)})
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            ) : (
                <div className="flex items-center justify-center h-64 text-slate-500">
                    <p>No expense data available.</p>
                </div>
            )}
        </Card>
    );
};

export default ExpensePieChart;