

import React, { useMemo } from 'react';
import { Account, LedgerEntry } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { format } from 'date-fns';

interface AccountLedgerModalProps {
  account: Account;
  ledger: LedgerEntry[];
}

const AccountLedgerModal: React.FC<AccountLedgerModalProps> = ({ account, ledger }) => {
  const { isDarkMode } = useTheme();
  const { currency } = useCurrency();

  const accountLedger = useMemo(() => {
    // Filter for entries related to this account and sort them chronologically (oldest first)
    return ledger
      .filter(entry => entry.accountId === account.id)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }, [account, ledger]);

  const ledgerWithBalance = useMemo(() => {
    // Calculate a forward-running balance
    let runningBalance = 0;
    return accountLedger.map((entry) => {
        runningBalance += entry.amount;
        return { ...entry, balance: runningBalance };
    });
  }, [accountLedger]);


  return (
    <div className="max-h-[70vh] flex flex-col">
        <div className="overflow-y-auto pr-2 -mr-4">
            <table className="w-full text-left text-sm">
            <thead className={`sticky top-0 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`}>
                <tr className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
                <th className="p-2">Date</th>
                <th className="p-2">Description</th>
                <th className="p-2">Batch ID</th>
                <th className="p-2 text-right">Debit</th>
                <th className="p-2 text-right">Credit</th>
                <th className="p-2 text-right">Balance</th>
                </tr>
            </thead>
            <tbody>
                {ledgerWithBalance.map((entry) => {
                const isDebit = entry.amount > 0;
                return (
                    <tr key={entry.id} className={`border-b ${isDarkMode ? 'border-slate-800/50' : 'border-slate-200'}`}>
                        <td className="p-2 whitespace-nowrap">{format(new Date(entry.timestamp), 'dd-MM-yy HH:mm')}</td>
                        <td className="p-2">{entry.description}</td>
                        <td className="p-2 font-mono text-xs">{entry.batchId}</td>
                        <td className={`p-2 text-right font-mono ${isDebit ? 'text-emerald-400' : ''}`}>
                            {isDebit ? formatCurrency(entry.amount, currency) : ''}
                        </td>
                        <td className={`p-2 text-right font-mono ${!isDebit ? 'text-red-400' : ''}`}>
                            {!isDebit ? formatCurrency(Math.abs(entry.amount), currency) : ''}
                        </td>
                        <td className="p-2 text-right font-mono font-semibold">{formatCurrency(entry.balance, currency)}</td>
                    </tr>
                );
                })}
            </tbody>
            </table>
        </div>
    </div>
  );
};

export default AccountLedgerModal;
