
import React, { useMemo } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useAuth } from '../../contexts/AuthContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addJournalEntry } from '../../services/mockDataService';
import { useData } from '../../contexts/DataContext';
import { Plus, Trash2 } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface AddJournalEntryModalProps {
  onClose: () => void;
}

const entryLineSchema = z.object({
  accountId: z.string().min(1, 'Account is required'),
  debit: z.string(),
  credit: z.string(),
});

const journalEntrySchema = z.object({
    description: z.string().min(3, "Description is required"),
    lines: z.array(entryLineSchema).min(2, 'At least two lines are required for a journal entry.'),
}).refine(data => {
    // Cannot have both debit and credit on the same line
    return data.lines.every(line => !(line.debit && line.credit));
}, { message: "Each line must have a debit OR a credit, not both.", path: ['lines'] })
.refine(data => {
    // Must have a value on each line
    return data.lines.every(line => (line.debit || line.credit));
}, { message: "Each line must have a debit or credit value.", path: ['lines'] });

type JournalEntryFormData = z.infer<typeof journalEntrySchema>;

const AddJournalEntryModal: React.FC<AddJournalEntryModalProps> = ({ onClose }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currency } = useCurrency();
  const { currentUser } = useAuth();
  const { data, refreshData } = useData();
  const { accounts = [] } = data || {};
  const { notifySuccess, notifyError } = useNotifier();

  const { register, control, handleSubmit, formState: { errors }, watch } = useForm<JournalEntryFormData>({
    resolver: zodResolver(journalEntrySchema),
    defaultValues: {
      description: '',
      lines: [
        { accountId: '', debit: '', credit: '' },
        { accountId: '', debit: '', credit: '' },
      ],
    },
  });

  const { fields, append, remove } = useFieldArray({ control, name: "lines" });
  const lines = watch('lines');

  const { totalDebit, totalCredit, isBalanced } = useMemo(() => {
    const totals = lines.reduce((acc, line) => {
        acc.debit += parseFloat(line.debit) || 0;
        acc.credit += parseFloat(line.credit) || 0;
        return acc;
    }, { debit: 0, credit: 0 });

    return {
        totalDebit: totals.debit,
        totalCredit: totals.credit,
        isBalanced: Math.abs(totals.debit - totals.credit) < 0.01,
    }
  }, [lines]);

  const onSubmit = (formData: JournalEntryFormData) => {
    if (!currentUser) return;
    if (!isBalanced) {
        notifyError("Journal entry must be balanced (Total Debits must equal Total Credits).");
        return;
    }

    const ledgerEntries = formData.lines.map(line => ({
        accountId: line.accountId,
        amount: parseFloat(line.debit) || -parseFloat(line.credit),
    }));

    const result = addJournalEntry(ledgerEntries, formData.description, currentUser.id);
    if(result) {
        notifySuccess("Journal entry created successfully!");
        refreshData();
        onClose();
    } else {
        notifyError("Failed to create journal entry.");
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label htmlFor="description" className={labelClasses}>Description</label>
        <input type="text" id="description" {...register('description')} className={inputClasses} autoFocus />
        {errors.description && <p className={errorClasses}>{errors.description.message}</p>}
      </div>

      <div className="space-y-2">
        <div className="grid grid-cols-12 gap-2 font-semibold">
            <span className="col-span-6">Account</span>
            <span className="col-span-3 text-right">Debit</span>
            <span className="col-span-3 text-right">Credit</span>
        </div>
        {fields.map((field, index) => (
          <div key={field.id} className="grid grid-cols-12 gap-2 items-start">
            <select {...register(`lines.${index}.accountId`)} className={`${inputClasses} col-span-6`}>
              <option value="" className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>Select Account</option>
              {accounts.map(acc => <option key={acc.id} value={acc.id} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{acc.id} - {acc.name}</option>)}
            </select>
            <input type="number" step="0.01" {...register(`lines.${index}.debit`)} className={`${inputClasses} col-span-3 text-right`} placeholder="0.00" />
            <input type="number" step="0.01" {...register(`lines.${index}.credit`)} className={`${inputClasses} col-span-2 text-right`} placeholder="0.00" />
            <button type="button" onClick={() => remove(index)} className="p-2 text-red-400 hover:text-red-300"><Trash2 size={16} /></button>
            {errors.lines?.[index] && <p className={`${errorClasses} col-span-12`}>{errors.lines?.[index]?.message}</p>}
          </div>
        ))}
        {errors.lines && typeof errors.lines.message === 'string' && <p className={errorClasses}>{errors.lines.message}</p>}
      </div>
      
      <button type="button" onClick={() => append({ accountId: '', debit: '', credit: '' })} className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg border-dashed border-2 ${isDarkMode ? 'border-slate-600 hover:bg-slate-700' : 'border-slate-300 hover:bg-slate-100'}`}>
          <Plus size={16}/> Add Line
      </button>

       <div className={`p-4 rounded-lg grid grid-cols-2 gap-4 mt-4 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
            <div className="text-right">
                <p className="text-sm text-slate-400">Total Debits</p>
                <p className="font-bold text-lg">{formatCurrency(totalDebit, currency)}</p>
            </div>
            <div className="text-right">
                <p className="text-sm text-slate-400">Total Credits</p>
                <p className="font-bold text-lg">{formatCurrency(totalCredit, currency)}</p>
            </div>
            <div className={`col-span-2 text-center text-sm font-semibold ${isBalanced ? 'text-emerald-400' : 'text-yellow-400'}`}>
                {isBalanced ? 'Balanced' : `Out of balance by ${formatCurrency(Math.abs(totalDebit - totalCredit), currency)}`}
            </div>
       </div>

      <div className="flex justify-end pt-4">
        <button type="submit" disabled={!isBalanced} className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button} disabled:opacity-50 disabled:cursor-not-allowed`}>
          Post Entry
        </button>
      </div>
    </form>
  );
};

export default AddJournalEntryModal;
