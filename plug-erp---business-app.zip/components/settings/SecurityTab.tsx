
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { updateUserPassword } from '../../services/mockDataService';

const passwordSchema = z.object({
  oldPassword: z.string().min(1, 'Old password is required'),
  newPassword: z.string().min(8, 'New password must be at least 8 characters'),
  confirmPassword: z.string()
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type PasswordFormData = z.infer<typeof passwordSchema>;

const SecurityTab: React.FC = () => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currentUser } = useAuth();
  const { notifySuccess, notifyError } = useNotifier();
  
  const { register, handleSubmit, formState: { errors }, reset } = useForm<PasswordFormData>({
    resolver: zodResolver(passwordSchema),
  });

  const onSubmit = (data: PasswordFormData) => {
    if (!currentUser) return;
    
    // In a real app, you would validate the oldPassword against the server.
    // For this mock, we'll just pretend it's always correct.
    const result = updateUserPassword(currentUser.id, currentUser.id);

    if (result) {
        notifySuccess('Password updated successfully!');
        reset();
    } else {
        notifyError('Failed to update password.');
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <h3 className={`text-xl font-bold ${themeClasses.textGradient}`}>Change Password</h3>
        <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
          For your security, we recommend choosing a strong, unique password.
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <label htmlFor="oldPassword" className={labelClasses}>Current Password</label>
          <input type="password" id="oldPassword" {...register('oldPassword')} className={inputClasses} />
          {errors.oldPassword && <p className={errorClasses}>{errors.oldPassword.message}</p>}
        </div>
        <div>
          <label htmlFor="newPassword" className={labelClasses}>New Password</label>
          <input type="password" id="newPassword" {...register('newPassword')} className={inputClasses} />
          {errors.newPassword && <p className={errorClasses}>{errors.newPassword.message}</p>}
        </div>
        <div>
          <label htmlFor="confirmPassword" className={labelClasses}>Confirm New Password</label>
          <input type="password" id="confirmPassword" {...register('confirmPassword')} className={inputClasses} />
          {errors.confirmPassword && <p className={errorClasses}>{errors.confirmPassword.message}</p>}
        </div>
      </div>
      
      <div className="flex justify-end pt-4 border-t border-slate-700/50">
        <button
          type="submit"
          className={`px-6 py-3 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Update Password
        </button>
      </div>
    </form>
  );
};

export default SecurityTab;
