
import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';

const PreferencesTab: React.FC = () => {
  const { themeClasses, isDarkMode } = useTheme();

  return (
    <div className="space-y-6">
      <div>
        <h3 className={`text-xl font-bold ${themeClasses.textGradient}`}>Interface Preferences</h3>
        <p className={`text-sm mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
          Customize the look and feel of your workspace.
        </p>
      </div>

      <div className="text-center p-8 border-2 border-dashed rounded-2xl border-slate-700/50">
          <p className="font-semibold">More preferences coming soon!</p>
          <p className="text-sm text-slate-500">Future options will include language settings, notification controls, and more.</p>
      </div>
    </div>
  );
};

export default PreferencesTab;
