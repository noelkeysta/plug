
import React from 'react';
import { MessageSquarePlus } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

const ChatWelcome: React.FC = () => {
  const { themeClasses } = useTheme();

  return (
    <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
      <MessageSquarePlus size={64} className={`mb-4 ${themeClasses.textGradient}`} />
      <h2 className="text-2xl font-bold">Welcome to Chat</h2>
      <p className="text-slate-400 mt-2">
        Select a conversation from the sidebar or start a new one to begin messaging.
      </p>
    </div>
  );
};

export default ChatWelcome;
