
import React, { useState } from 'react';
import { Message, User, MessageStatus } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { format } from 'date-fns';
import { Check, CheckCheck, MoreHorizontal, Edit, Trash } from 'lucide-react';
import { editMessage, deleteMessage } from '../../services/mockDataService';
import { useData } from '../../contexts/DataContext';

interface MessageBubbleProps {
  message: Message;
  isOwnMessage: boolean;
  sender: User;
  showAvatar: boolean;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isOwnMessage, sender, showAvatar }) => {
  const { isDarkMode } = useTheme();
  const { refreshData } = useData();
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(message.text);
  const [isMenuOpen, setMenuOpen] = useState(false);

  const handleEdit = () => {
    editMessage(message.id, editText);
    refreshData();
    setIsEditing(false);
    setMenuOpen(false);
  };
  
  const handleDelete = () => {
    deleteMessage(message.id);
    refreshData();
  };

  const statusIcon = message.status === MessageStatus.READ 
    ? <CheckCheck size={16} className="text-blue-400" />
    : <Check size={16} />;

  const bubbleClasses = isOwnMessage
    ? 'bg-blue-600 text-white'
    : `${isDarkMode ? 'bg-slate-700' : 'bg-slate-200'}`;
  
  const alignmentClasses = isOwnMessage
    ? 'items-end'
    : 'items-start';

  if (message.text === '[Message deleted]') {
      return (
           <div className={`flex items-end gap-3 max-w-xl mx-2 ${isOwnMessage ? 'flex-row-reverse' : ''}`}>
             <div className="w-8 flex-shrink-0" />
            <div className={`px-4 py-2 rounded-2xl italic text-sm ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                Message deleted
            </div>
        </div>
      )
  }

  return (
    <div className={`flex flex-col ${alignmentClasses}`}>
      <div className={`flex items-end gap-3 max-w-xl ${isOwnMessage ? 'flex-row-reverse' : ''}`}>
        {!isOwnMessage && showAvatar ? (
          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
            {sender?.avatar}
          </div>
        ) : <div className="w-8 flex-shrink-0" />}
        
        <div className="relative group">
            {isEditing ? (
                 <div className="flex items-center gap-2">
                    <input 
                        type="text" 
                        value={editText} 
                        onChange={(e) => setEditText(e.target.value)} 
                        className={`p-2 rounded-lg border bg-transparent text-sm ${isDarkMode ? 'border-slate-600 text-white' : 'border-slate-500 text-black'}`}
                        onKeyDown={(e) => e.key === 'Enter' && handleEdit()}
                        autoFocus
                    />
                    <button onClick={handleEdit} className="px-3 py-1 text-xs rounded-full bg-emerald-500 text-white">Save</button>
                    <button onClick={() => setIsEditing(false)} className="px-3 py-1 text-xs rounded-full bg-slate-500 text-white">Cancel</button>
                </div>
            ) : (
                <div className={`${bubbleClasses} rounded-2xl ${message.imageUrl && !message.text ? 'p-1' : 'px-4 py-2'}`}>
                    {message.imageUrl && (
                        <img src={message.imageUrl} alt="Attachment" className="max-w-xs max-h-64 rounded-xl" />
                    )}
                    {message.text && (
                        <p className={`${message.imageUrl ? 'mt-2' : ''}`}>{message.text}</p>
                    )}
                </div>
            )}

            {isOwnMessage && !isEditing && !message.imageUrl && (
                <div className="absolute top-1/2 -translate-y-1/2 -left-8 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => setMenuOpen(!isMenuOpen)} className="p-1 rounded-full hover:bg-slate-500/20"><MoreHorizontal size={16} /></button>
                    {isMenuOpen && (
                        <div className={`absolute bottom-full mb-1 -left-2 w-28 rounded-lg p-1 ${isDarkMode ? 'bg-slate-900' : 'bg-white'} shadow-lg border ${isDarkMode ? 'border-slate-700' : 'border-slate-200'}`}>
                           <button onClick={() => { setIsEditing(true); setMenuOpen(false); }} className={`w-full text-left flex items-center gap-2 p-1.5 text-xs rounded-md ${isDarkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-100'}`}><Edit size={14}/> Edit</button>
                           <button onClick={handleDelete} className={`w-full text-left flex items-center gap-2 p-1.5 text-xs rounded-md text-red-500 ${isDarkMode ? 'hover:bg-red-500/10' : 'hover:bg-red-100'}`}><Trash size={14}/> Delete</button>
                        </div>
                    )}
                </div>
            )}
        </div>
      </div>
      <div className={`text-xs mt-1 ${isOwnMessage ? 'text-right pr-11' : 'text-left pl-11'} ${isDarkMode ? 'text-slate-500' : 'text-slate-400'} flex items-center gap-1 ${isOwnMessage ? 'flex-row-reverse' : ''}`}>
        <span>{format(new Date(message.timestamp), 'p')}</span>
        {isOwnMessage && statusIcon}
        {message.isEdited && <span>(edited)</span>}
      </div>
    </div>
  );
};

export default MessageBubble;
