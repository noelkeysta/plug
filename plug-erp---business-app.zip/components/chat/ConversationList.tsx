
import React, { useState } from 'react';
import { Conversation, User } from '../../types';
import ConversationListItem from './ConversationListItem';
import { PlusCircle } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import Modal from '../ui/Modal';
import NewChatModal from './NewChatModal';

interface ConversationListProps {
  conversations: Conversation[];
  currentUser: User;
  userMap: Record<number, User>;
  selectedConversationId: string | null;
  onSelectConversation: (id: string) => void;
}

const ConversationList: React.FC<ConversationListProps> = ({ conversations, currentUser, userMap, selectedConversationId, onSelectConversation }) => {
  const { themeClasses } = useTheme();
  const [isNewChatModalOpen, setNewChatModalOpen] = useState(false);

  return (
    <>
      <div className="flex justify-between items-center mb-4 px-2">
        <h2 className={`text-2xl font-bold ${themeClasses.textGradient}`}>Chats</h2>
        <button onClick={() => setNewChatModalOpen(true)} className="p-2 rounded-full hover:bg-slate-700/50">
          <PlusCircle />
        </button>
      </div>
      <div className="flex-grow overflow-y-auto -mr-2 pr-2">
        <div className="space-y-1">
          {conversations.map(conv => (
            <ConversationListItem
              key={conv.id}
              conversation={conv}
              currentUser={currentUser}
              userMap={userMap}
              isSelected={conv.id === selectedConversationId}
              onClick={() => onSelectConversation(conv.id)}
            />
          ))}
        </div>
      </div>
       <Modal isOpen={isNewChatModalOpen} onClose={() => setNewChatModalOpen(false)} title="New Chat">
        <NewChatModal 
            currentUser={currentUser} 
            onClose={() => setNewChatModalOpen(false)}
            onConversationCreated={(id) => {
                onSelectConversation(id);
                setNewChatModalOpen(false);
            }}
        />
      </Modal>
    </>
  );
};

export default ConversationList;
