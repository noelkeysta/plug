
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { Conversation, Message, User } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import MessageBubble from './MessageBubble';
import MessageInput from './MessageInput';
import { sendMessage, markConversationAsRead } from '../../services/mockDataService';
import { useData } from '../../contexts/DataContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { Search } from 'lucide-react';

interface ChatWindowProps {
  conversation: Conversation;
  messages: Message[];
  currentUser: User;
  userMap: Record<number, User>;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ conversation, messages, currentUser, userMap }) => {
  const { themeClasses, isDarkMode } = useTheme();
  const { refreshData } = useData();
  const { notifyInfo } = useNotifier();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const displayName = useMemo(() => {
    if (conversation.type === 'group') return conversation.name;
    const otherUserId = conversation.participants.find(p => p !== currentUser.id);
    return otherUserId ? userMap[otherUserId]?.name : 'Unknown';
  }, [conversation, currentUser, userMap]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);
  
  useEffect(() => {
      if (conversation.unreadCounts[currentUser.id] > 0) {
        markConversationAsRead(currentUser.id, conversation.id);
        refreshData();
      }
  }, [currentUser.id, conversation.id, conversation.unreadCounts, refreshData]);

  const handleSendMessage = (content: { text?: string; imageUrl?: string }) => {
    sendMessage(currentUser.id, conversation.id, content);
    refreshData();
    
    const otherParticipant = conversation.participants.find(p => p !== currentUser.id);
    if(otherParticipant && conversation.type === 'direct') {
        setIsTyping(true);
        setTimeout(() => {
            setIsTyping(false);
            const replyText = "This is an automated reply for demo purposes."
            sendMessage(otherParticipant, conversation.id, { text: replyText });
            refreshData();
        }, 1500 + Math.random() * 1000);
    }
  };

  const filteredMessages = useMemo(() => {
    if (!searchTerm) return messages;
    return messages.filter(msg => msg.text.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [messages, searchTerm]);
  
  return (
    <div className="flex-1 flex flex-col h-full">
      <header className={`p-4 border-b ${themeClasses.sidebar} rounded-none flex-shrink-0 flex justify-between items-center`}>
        <div>
            <h3 className="font-bold text-lg">{displayName}</h3>
            {isTyping && <p className="text-xs text-slate-400 animate-pulse">typing...</p>}
        </div>
        <div className="relative">
            <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400`} />
            <input 
                type="text"
                placeholder="Search messages..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className={`pl-9 pr-3 py-1.5 rounded-full text-sm border-none focus:outline-none focus:ring-1 focus:ring-amber-500/50 placeholder-gray-400 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-200'}`}
            />
        </div>
      </header>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {filteredMessages.map((msg, index) => {
          const prevMsg = filteredMessages[index - 1];
          const showAvatar = !prevMsg || prevMsg.senderId !== msg.senderId;
          return (
            <MessageBubble
              key={msg.id}
              message={msg}
              isOwnMessage={msg.senderId === currentUser.id}
              sender={userMap[msg.senderId]}
              showAvatar={showAvatar}
            />
          );
        })}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 flex-shrink-0">
        <MessageInput onSendMessage={handleSendMessage} />
      </div>
    </div>
  );
};

export default ChatWindow;
