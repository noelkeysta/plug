
import React, { useState, useRef } from 'react';
import { Send, Paperclip, Smile, X } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { useNotifier } from '../../contexts/NotificationContext';

interface MessageInputProps {
  onSendMessage: (content: { text?: string; imageUrl?: string }) => void;
}

const MessageInput: React.FC<MessageInputProps> = ({ onSendMessage }) => {
  const { isDarkMode } = useTheme();
  const { notifyInfo } = useNotifier();
  const [text, setText] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim() || imagePreview) {
      onSendMessage({ text: text.trim(), imageUrl: imagePreview || undefined });
      setText('');
      setImagePreview(null);
    }
  };
  
  const handleAttachmentClick = () => {
      fileInputRef.current?.click();
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file && file.type.startsWith('image/')) {
          const reader = new FileReader();
          reader.onloadend = () => {
              setImagePreview(reader.result as string);
          };
          reader.readAsDataURL(file);
      } else if (file) {
          notifyInfo("Only image files are supported for attachments in this demo.");
      }
      if(e.target) e.target.value = '';
  };
  
  const handleEmojiClick = () => {
      setText(prev => prev + '👍');
  }

  return (
    <div>
        {imagePreview && (
            <div className="relative w-24 h-24 mb-2 p-1 border rounded-lg bg-slate-800/50">
                <img src={imagePreview} alt="Preview" className="w-full h-full object-cover rounded" />
                <button 
                    onClick={() => setImagePreview(null)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5"
                >
                    <X size={14} />
                </button>
            </div>
        )}
        <form onSubmit={handleSubmit} className="flex items-center gap-3">
            <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
            <button type="button" onClick={handleAttachmentClick} className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`}>
                <Paperclip />
            </button>
            <button type="button" onClick={handleEmojiClick} className={`p-2 rounded-full ${isDarkMode ? 'hover:bg-slate-700' : 'hover:bg-slate-200'}`}>
                <Smile />
            </button>
            <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type a message..."
                className={`flex-grow px-4 py-3 rounded-full border-none focus:outline-none focus:ring-2 focus:ring-amber-500/50 placeholder-gray-400 ${isDarkMode ? 'bg-slate-700' : 'bg-slate-200'}`}
            />
            <button type="submit" className="p-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50" disabled={!text.trim() && !imagePreview}>
                <Send />
            </button>
        </form>
    </div>
  );
};

export default MessageInput;
