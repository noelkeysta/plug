
import React, { useMemo } from 'react';
import { Conversation, User } from '../../types';
import { Users } from 'lucide-react';
import { format } from 'date-fns';

interface ConversationListItemProps {
  conversation: Conversation;
  currentUser: User;
  userMap: Record<number, User>;
  isSelected: boolean;
  onClick: () => void;
}

const ConversationListItem: React.FC<ConversationListItemProps> = ({ conversation, currentUser, userMap, isSelected, onClick }) => {
  const { displayName, avatarInitial } = useMemo(() => {
    if (conversation.type === 'group') {
      return { displayName: conversation.name || 'Group Chat', avatarInitial: '#' };
    }
    const otherParticipantId = conversation.participants.find(p => p !== currentUser.id);
    const otherUser = otherParticipantId ? userMap[otherParticipantId] : null;
    return { 
      displayName: otherUser?.name || 'Unknown User', 
      avatarInitial: otherUser?.avatar || '?' 
    };
  }, [conversation, currentUser, userMap]);

  const lastMessageText = useMemo(() => {
    if (!conversation.lastMessage) return 'No messages yet';
    const sender = conversation.lastMessage.senderId === currentUser.id ? 'You: ' : '';
    return `${sender}${conversation.lastMessage.text}`;
  }, [conversation.lastMessage, currentUser.id]);

  const lastMessageTimestamp = useMemo(() => {
    if (!conversation.lastMessage) return '';
    return format(new Date(conversation.lastMessage.timestamp), 'p');
  }, [conversation.lastMessage]);

  return (
    <div
      onClick={onClick}
      className={`flex items-center p-3 rounded-2xl cursor-pointer transition-colors duration-200 ${
        isSelected ? 'bg-amber-500/10' : 'hover:bg-slate-500/10'
      }`}
    >
      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold text-xl flex-shrink-0 mr-4">
        {conversation.type === 'group' ? <Users size={24} /> : avatarInitial}
      </div>
      <div className="flex-grow overflow-hidden">
        <div className="flex justify-between items-center">
          <p className="font-bold truncate">{displayName}</p>
          <p className="text-xs text-slate-400 flex-shrink-0 ml-2">{lastMessageTimestamp}</p>
        </div>
        <p className="text-sm text-slate-400 truncate">{lastMessageText}</p>
      </div>
    </div>
  );
};

export default ConversationListItem;
