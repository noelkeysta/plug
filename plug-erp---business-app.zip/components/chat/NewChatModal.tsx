
import React, { useState, useMemo } from 'react';
import { User } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { useData } from '../../contexts/DataContext';
import { createConversation } from '../../services/mockDataService';
import { Search } from 'lucide-react';

interface NewChatModalProps {
    currentUser: User;
    onClose: () => void;
    onConversationCreated: (conversationId: string) => void;
}

const NewChatModal: React.FC<NewChatModalProps> = ({ currentUser, onClose, onConversationCreated }) => {
    const { isDarkMode, themeClasses } = useTheme();
    const { data, refreshData } = useData();
    const { users = [] } = data || {};
    
    const [selectedUserIds, setSelectedUserIds] = useState<Set<number>>(new Set());
    const [groupName, setGroupName] = useState('');
    const [searchQuery, setSearchQuery] = useState('');

    const otherUsers = useMemo(() => {
        return users.filter(u => u.id !== currentUser.id && u.name.toLowerCase().includes(searchQuery.toLowerCase()));
    }, [users, currentUser.id, searchQuery]);

    const handleUserToggle = (userId: number) => {
        setSelectedUserIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(userId)) {
                newSet.delete(userId);
            } else {
                newSet.add(userId);
            }
            return newSet;
        });
    };

    const handleCreateChat = () => {
        const participantIds = [currentUser.id, ...Array.from(selectedUserIds)];
        const isGroup = participantIds.length > 2;
        if (isGroup && !groupName.trim()) {
            alert('Please enter a group name.');
            return;
        }
        const newConversation = createConversation(currentUser.id, participantIds, groupName.trim() || undefined);
        if (newConversation) {
            refreshData();
            onConversationCreated(newConversation.id);
        }
    };

    const isGroup = selectedUserIds.size > 1;

    return (
        <div className="flex flex-col space-y-4 max-h-[60vh]">
            <div className="relative">
                <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`} />
                <input
                    type="text"
                    placeholder="Search for users..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className={`w-full pl-10 pr-4 py-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
                />
            </div>
            
            {isGroup && (
                <div>
                    <label htmlFor="groupName" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Group Name</label>
                    <input
                        type="text"
                        id="groupName"
                        value={groupName}
                        onChange={e => setGroupName(e.target.value)}
                        className={`w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
                        placeholder="My Awesome Team"
                    />
                </div>
            )}

            <div className="flex-grow overflow-y-auto -mr-2 pr-2 space-y-2">
                {otherUsers.map(user => (
                    <div
                        key={user.id}
                        onClick={() => handleUserToggle(user.id)}
                        className={`p-3 rounded-lg flex items-center cursor-pointer transition-colors ${
                            selectedUserIds.has(user.id) ? (isDarkMode ? 'bg-amber-500/20' : 'bg-blue-100') : (isDarkMode ? 'hover:bg-slate-700/50' : 'hover:bg-slate-100')
                        }`}
                    >
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-amber-500 to-blue-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0 mr-3">
                            {user.avatar}
                        </div>
                        <p className="font-semibold">{user.name}</p>
                    </div>
                ))}
            </div>

            <div className="flex justify-end pt-4">
                <button
                    onClick={handleCreateChat}
                    disabled={selectedUserIds.size === 0}
                    className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button} disabled:opacity-50`}
                >
                    {isGroup ? 'Create Group Chat' : 'Start Chat'}
                </button>
            </div>
        </div>
    );
};

export default NewChatModal;
