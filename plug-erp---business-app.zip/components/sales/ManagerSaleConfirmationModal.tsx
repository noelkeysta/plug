
import React, { useState, useMemo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { AlertTriangle } from 'lucide-react';
import { UserRole } from '../../types';

interface ManagerSaleConfirmationModalProps {
  onConfirm: (managerId: number) => void;
  onCancel: () => void;
}

const ManagerSaleConfirmationModal: React.FC<ManagerSaleConfirmationModalProps> = ({ onConfirm, onCancel }) => {
  const { themeClasses, isDarkMode } = useTheme();
  const { users } = useAuth();
  
  const managers = useMemo(() => users.filter(u => [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER].includes(u.role)), [users]);
  const [selectedManagerId, setSelectedManagerId] = useState<number | null>(managers.length > 0 ? managers[0].id : null);
  
  const handleConfirm = () => {
    if (selectedManagerId) {
      onConfirm(selectedManagerId);
    }
  };

  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;

  return (
    <div className="space-y-4 text-center">
        <div className="mx-auto w-fit p-3 rounded-full bg-amber-500/20 mb-4">
          <AlertTriangle className="w-10 h-10 text-amber-400" />
        </div>
        <h3 className="text-xl font-bold">Manager Approval Required</h3>
        <p className={`${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            This sale requires manager approval due to a price override or large discount. Please select the approving manager.
        </p>
        
        <div className="text-left">
             <label htmlFor="manager-select" className={`text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Approving Manager</label>
             <select 
                id="manager-select"
                value={selectedManagerId || ''}
                onChange={e => setSelectedManagerId(Number(e.target.value))}
                className={inputClasses}
             >
                {managers.map(manager => (
                    <option key={manager.id} value={manager.id} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{manager.name}</option>
                ))}
             </select>
        </div>

        <div className="flex justify-center gap-4 pt-4">
            <button
                onClick={onCancel}
                className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 border-2 ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
            >
                Cancel
            </button>
            <button
                onClick={handleConfirm}
                disabled={!selectedManagerId}
                className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button} disabled:opacity-50 disabled:cursor-not-allowed`}
            >
                Confirm Sale
            </button>
      </div>
    </div>
  );
};

export default ManagerSaleConfirmationModal;
