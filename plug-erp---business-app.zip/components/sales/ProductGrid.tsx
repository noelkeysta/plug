import React, { useState, useMemo } from 'react';
import { Product, InventoryItem } from '../../types';
import Card from '../ui/Card';
import { useTheme } from '../../contexts/ThemeContext';
import { Search } from 'lucide-react';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';


interface ProductGridProps {
    products: Product[];
    inventoryItems: InventoryItem[];
    onProductSelect: (product: Product, stock: number) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, inventoryItems, onProductSelect }) => {
    const { isDarkMode, themeClasses } = useTheme();
    const { currency } = useCurrency();
    const [searchQuery, setSearchQuery] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('All');

    const uniqueCategories = useMemo(() => ['All', ...new Set(products.map(p => p.category))], [products]);

    const productStockMap = useMemo(() => {
        return inventoryItems.reduce((acc, item) => {
            if (item.status === 'available') {
                acc[item.productId] = (acc[item.productId] || 0) + 1;
            }
            return acc;
        }, {} as Record<string, number>);
    }, [inventoryItems]);

    const filteredProducts = useMemo(() => {
        return products
            .map(p => ({ ...p, stock: productStockMap[p.id] || 0 }))
            .filter(p => {
                const matchesCategory = categoryFilter === 'All' || p.category === categoryFilter;
                const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
                return matchesCategory && matchesSearch;
            });
    }, [products, searchQuery, categoryFilter, productStockMap]);

    return (
        <div className="flex flex-col h-full">
            <Card className="!p-4 mb-4 flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-grow w-full md:w-auto">
                    <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`} />
                    <input
                        type="text"
                        placeholder="Search products..."
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className={`w-full pl-10 pr-4 py-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
                    />
                </div>
                <div className="flex-grow w-full md:w-auto">
                     <select 
                        value={categoryFilter}
                        onChange={e => setCategoryFilter(e.target.value)}
                        className={`w-full p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
                     >
                        {uniqueCategories.map(cat => <option key={cat} value={cat} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{cat}</option>)}
                    </select>
                </div>
            </Card>
            <div className="flex-grow overflow-y-auto pr-2">
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filteredProducts.map(product => (
                        <Card 
                            key={product.id}
                            className={`
                                !p-3 flex flex-col text-center items-center justify-between
                                transition-all duration-200 transform
                                ${product.stock > 0 ? 'cursor-pointer hover:scale-105 hover:shadow-xl' : 'opacity-50 cursor-not-allowed'}
                            `}
                            onClick={() => product.stock > 0 && onProductSelect(product, product.stock)}
                        >
                            <div>
                                <p className="font-bold text-sm leading-tight">{product.name}</p>
                                <p className={`text-xs mt-1 ${themeClasses.textGradient}`}>{product.category}</p>
                            </div>
                            <div className="mt-2">
                                <p className={`font-semibold text-lg ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`}>{formatCurrency(product.price, currency)}</p>
                                <p className={`text-xs ${product.stock > 10 ? 'text-emerald-400' : product.stock <= 0 ? 'text-red-400' : 'text-yellow-400'}`}>
                                    {product.stock > 0 ? `${product.stock} in stock` : 'Out of Stock'}
                                </p>
                            </div>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
}
export default ProductGrid;