import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { SerializedCartItem, User, UserRole, Product } from '../../types';
import { AlertCircle } from 'lucide-react';

interface EditPriceModalProps {
    item: SerializedCartItem;
    productMap: Record<string, Product>;
    onClose: () => void;
    onUpdatePrice: (serialNumber: string, newPrice: number) => void;
    currentUser: User | null;
}

const priceSchema = z.object({
  price: z.number().min(0, 'Price cannot be negative'),
});

type PriceFormData = z.infer<typeof priceSchema>;

const EditPriceModal: React.FC<EditPriceModalProps> = ({ item, productMap, onClose, onUpdatePrice, currentUser }) => {
    const { isDarkMode, themeClasses } = useTheme();
    const { currency } = useCurrency();
    const product = productMap[item.productId];

    const { register, handleSubmit, watch, formState: { errors } } = useForm<PriceFormData>({
        resolver: zodResolver(priceSchema),
        defaultValues: { price: item.finalPrice }
    });
    
    const newPrice = watch('price');
    const isReduction = newPrice < product.price;
    const isManager = currentUser && [UserRole.ADMINISTRATOR, UserRole.GENERAL_MANAGER, UserRole.SALES_MANAGER].includes(currentUser.role);
    const canSubmit = !isReduction || (isReduction && isManager);
    
    const onSubmit = (data: PriceFormData) => {
        if (!canSubmit) {
            // This case should be prevented by disabled button, but as a safeguard.
            return;
        }
        onUpdatePrice(item.serialNumber, data.price);
    };

    const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
    const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
    const errorClasses = "text-red-400 text-xs mt-1";

    if (!product) return null;

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className={`p-4 rounded-lg ${isDarkMode ? 'bg-slate-800/50' : 'bg-slate-100'}`}>
                <p className={labelClasses}>Product</p>
                <p className="font-semibold">{product.name}</p>
                <p className={`${labelClasses} mt-2`}>Original Price</p>
                <p className="font-semibold">{formatCurrency(product.price, currency)}</p>
            </div>
            
            <div>
                <label htmlFor="price" className={labelClasses}>New Price ({currency.symbol})</label>
                <input type="number" step="any" id="price" {...register('price', { valueAsNumber: true })} className={inputClasses} autoFocus />
                {errors.price && <p className={errorClasses}>{errors.price.message}</p>}
            </div>

            {isReduction && !isManager && (
                 <div className="flex items-start gap-2 p-3 rounded-lg bg-yellow-500/10 text-yellow-400">
                    <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">
                        A manager must approve this sale at checkout because the price has been reduced. You can proceed with the change now.
                    </p>
                </div>
            )}
            
            <div className="flex justify-end pt-4 border-t border-slate-700/20">
                <button type="submit" className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button} disabled:opacity-50 disabled:cursor-not-allowed`}>
                    Update Price
                </button>
            </div>
        </form>
    );
};

export default EditPriceModal;
