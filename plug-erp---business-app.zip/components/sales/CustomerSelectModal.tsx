import React, { useState, useMemo } from 'react';
import { Customer } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { Search, UserPlus, Home } from 'lucide-react';

interface CustomerSelectModalProps {
    customers: Customer[];
    onClose: () => void;
    onSelectCustomer: (customer: Customer | null) => void;
    onAddNewCustomerClick: () => void;
}

const CustomerSelectModal: React.FC<CustomerSelectModalProps> = ({ customers, onClose, onSelectCustomer, onAddNewCustomerClick }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const { isDarkMode, themeClasses } = useTheme();
    const { currency } = useCurrency();

    const filteredCustomers = useMemo(() => {
        return customers.filter(c =>
            c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            c.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
            c.phone.toLowerCase().includes(searchQuery.toLowerCase()) ||
            `C${c.id}`.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [customers, searchQuery]);

    const inputClasses = `w-full pl-10 pr-4 py-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`;
    const walkInCustomer = useMemo(() => customers.find(c => c.tier === 'Walk-in'), [customers]);

    return (
        <div className="flex flex-col space-y-4 max-h-[60vh]">
            <div className="relative">
                <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`} />
                <input
                    type="text"
                    placeholder="Search by name, email, phone, or ID..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className={inputClasses}
                    autoFocus
                />
            </div>
            <div className="grid grid-cols-2 gap-3">
                 <button
                    onClick={() => onAddNewCustomerClick()}
                    className={`w-full flex items-center justify-center gap-2 p-3 rounded-lg border-2 border-dashed transition-colors ${isDarkMode ? 'border-amber-500/30 text-amber-300 hover:bg-amber-500/10' : 'border-blue-500/30 text-blue-700 hover:bg-blue-100'}`}
                >
                    <UserPlus size={20} />
                    <span className="font-semibold">Add New Customer</span>
                </button>
                <button
                    onClick={() => onSelectCustomer(walkInCustomer || null)}
                    className={`w-full flex items-center justify-center gap-2 p-3 rounded-lg border-2 border-dashed transition-colors ${isDarkMode ? 'border-slate-600 hover:bg-slate-700/50' : 'border-slate-300 hover:bg-slate-100'}`}
                >
                    <Home size={20} />
                    <span className="font-semibold">Use Walk-in</span>
                </button>
            </div>
            <div className="flex-grow overflow-y-auto -mr-2 pr-2 space-y-2">
                {filteredCustomers.filter(c => c.tier !== 'Walk-in').map(customer => (
                    <div
                        key={customer.id}
                        onClick={() => onSelectCustomer(customer)}
                        className={`p-3 rounded-lg flex justify-between items-center cursor-pointer transition-all ${isDarkMode ? 'hover:bg-slate-700/50' : 'hover:bg-slate-100'}`}
                    >
                        <div>
                            <p className="font-semibold">{customer.name}</p>
                            <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                                {customer.tier} &bull; {customer.email}
                            </p>
                        </div>
                        <div className="text-right">
                            <p className={`text-sm font-medium ${customer.creditLimit > 0 ? (isDarkMode ? 'text-emerald-400' : 'text-emerald-600') : (isDarkMode ? 'text-slate-500' : 'text-slate-400')}`}>
                                {formatCurrency(customer.creditLimit, currency)}
                            </p>
                            <p className="text-xs text-slate-500">Credit Limit</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CustomerSelectModal;