import React from 'react';
import { Transaction, Customer, User, AppSettings, Product } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { format } from 'date-fns';
import { Printer, ShoppingBag } from 'lucide-react';

interface ReceiptProps {
  transaction: Transaction;
  products: Product[];
  customer: Customer | null;
  cashier: User;
  settings: AppSettings;
  onNewSale: () => void;
}

const Receipt: React.FC<ReceiptProps> = ({ transaction, products, customer, cashier, settings, onNewSale }) => {
  const { themeClasses, isDarkMode } = useTheme();
  const { currency } = useCurrency();

  const handlePrint = () => {
    window.print();
  };

  const getProductName = (productId: string) => {
    return products.find(p => p.id === productId)?.name || 'Unknown Product';
  };
  
  const subtotal = transaction.items.reduce((sum, item) => sum + item.price, 0);
  const discountAmount = subtotal * ((transaction.discount || 0) / 100);
  const discountedSubtotal = subtotal - discountAmount;
  const taxAmount = discountedSubtotal * (settings.taxRate / 100);

  return (
    <div className="text-sm">
      <div id="receipt-print-area" className={`${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
        <div className="text-center mb-6">
          <ShoppingBag className={`mx-auto w-12 h-12 mb-2 ${themeClasses.textGradient}`} />
          <h2 className="text-xl font-bold">{settings.companyName}</h2>
          <p>{settings.address}</p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4 pb-4 border-b border-dashed border-slate-500/50">
          <div>
            <p className="font-bold">Transaction ID:</p>
            <p>#{transaction.id}</p>
          </div>
          <div className="text-right">
            <p className="font-bold">Date:</p>
            <p>{format(new Date(transaction.timestamp), 'dd MMM yyyy, HH:mm')}</p>
          </div>
          <div>
            <p className="font-bold">Cashier:</p>
            <p>{cashier.name}</p>
          </div>
          <div className="text-right">
            <p className="font-bold">Customer:</p>
            <p>{customer?.name || 'Walk-in Customer'}</p>
          </div>
        </div>

        <div className="space-y-3 mb-4">
          <div className="grid grid-cols-12 gap-2 font-bold">
            <p className="col-span-8">Item</p>
            <p className="col-span-4 text-right">Price</p>
          </div>
          {transaction.items.map((item, index) => (
            <div key={item.serialNumber + index} className="grid grid-cols-12 gap-2">
              <div className="col-span-8">
                <p>{getProductName(item.productId)}</p>
                <p className="text-xs text-slate-500 font-mono">SN: {item.serialNumber}</p>
              </div>
              <p className="col-span-4 text-right font-mono">{formatCurrency(item.price, currency)}</p>
            </div>
          ))}
        </div>

        <div className="space-y-1 pt-4 border-t border-dashed border-slate-500/50">
          <div className="flex justify-between">
            <p>Subtotal</p>
            <p className="font-mono">{formatCurrency(subtotal, currency)}</p>
          </div>
          {transaction.discount && transaction.discount > 0 && (
            <div className="flex justify-between">
              <p>Discount ({transaction.discount}%)</p>
              <p className="font-mono text-red-400">-{formatCurrency(discountAmount, currency)}</p>
            </div>
          )}
          <div className="flex justify-between">
            <p>Tax ({settings.taxRate}%)</p>
            <p className="font-mono">{formatCurrency(taxAmount, currency)}</p>
          </div>
          <div className="flex justify-between font-bold text-lg mt-2 pt-2 border-t border-slate-500/50">
            <p>Total</p>
            <p className="font-mono">{formatCurrency(transaction.totalAmount, currency)}</p>
          </div>
        </div>
      </div>
      <div className="print-hide mt-6 flex justify-end gap-3">
        <button
          onClick={handlePrint}
          className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 border-2 ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
        >
          <Printer size={16} /> Print
        </button>
        <button
          onClick={onNewSale}
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          New Sale
        </button>
      </div>
      <style>{`
        @media print {
          body * {
            visibility: hidden;
            background: transparent !important;
            color: #000 !important;
            box-shadow: none !important;
            text-shadow: none !important;
          }
          #receipt-print-area, #receipt-print-area * {
            visibility: visible;
          }
          #receipt-print-area {
            position: absolute;
            left: 0;
            top: 0;
            margin: 20px;
            width: calc(100% - 40px);
          }
          .font-mono {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace !important;
          }
        }
      `}</style>
    </div>
  );
};

export default Receipt;