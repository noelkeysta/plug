import React, { useMemo } from 'react';
import { Product, InventoryItem, SerializedCartItem } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { CheckCircle } from 'lucide-react';

interface SerialNumberSelectModalProps {
    isOpen: boolean;
    product: Product | null;
    inventoryItems: InventoryItem[];
    cartItems: SerializedCartItem[];
    onClose: () => void;
    onSerialSelect: (product: Product, serialNumber: string) => void;
}

const SerialNumberSelectModal: React.FC<SerialNumberSelectModalProps> = ({ product, inventoryItems, cartItems, onSerialSelect, onClose }) => {
    const { isDarkMode } = useTheme();

    const availableSerials = useMemo(() => {
        if (!product) return [];
        const cartSerials = new Set(cartItems.map(item => item.serialNumber));
        return inventoryItems.filter(item => 
            item.productId === product.id && 
            item.status === 'available' &&
            !cartSerials.has(item.id)
        );
    }, [product, inventoryItems, cartItems]);

    if (!product) return null;

    return (
        <div className="flex flex-col space-y-4 max-h-[60vh]">
            <p className="text-slate-400">Select an available serial number for this product.</p>
            <div className="flex-grow overflow-y-auto -mr-2 pr-2 space-y-2">
                {availableSerials.length > 0 ? (
                    availableSerials.map(item => (
                        <div
                            key={item.id}
                            onClick={() => onSerialSelect(product, item.id)}
                            className={`p-3 rounded-lg flex justify-between items-center cursor-pointer transition-all ${isDarkMode ? 'hover:bg-slate-700/50' : 'hover:bg-slate-100'}`}
                        >
                            <span className="font-mono">{item.id}</span>
                            <CheckCircle className={`w-5 h-5 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-500'}`} />
                        </div>
                    ))
                ) : (
                    <div className={`p-4 rounded-lg text-center ${isDarkMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
                        <p className="font-semibold">No Available Units</p>
                        <p className="text-sm text-slate-400">All available units of this product are already in the cart or sold.</p>
                    </div>
                )}
            </div>
             <div className="flex justify-end pt-4">
                <button onClick={onClose} className="px-6 py-2 font-semibold">Cancel</button>
            </div>
        </div>
    );
};

export default SerialNumberSelectModal;