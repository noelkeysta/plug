import React from 'react';
import { Customer, SerializedCartItem, Product } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { X, Trash2, Receipt, User, Edit3, CreditCard, DollarSign, Smartphone } from 'lucide-react';

interface OrderSummaryProps {
    items: SerializedCartItem[];
    taxRate: number;
    discount: number;
    selectedCustomer: Customer | null;
    productMap: Record<string, Product>;
    onRemoveItem: (serialNumber: string) => void;
    onClearCart: () => void;
    onCompleteSale: (paymentMethod: 'Cash' | 'Credit' | 'Card' | 'Mobile Money') => void;
    onSelectCustomerClick: () => void;
    onDiscountChange: (discount: number) => void;
    onEditPrice: (item: SerializedCartItem) => void;
}

const OrderSummary: React.FC<OrderSummaryProps> = ({ items, taxRate, discount, selectedCustomer, productMap, onRemoveItem, onClearCart, onCompleteSale, onSelectCustomerClick, onDiscountChange, onEditPrice }) => {
    const { themeClasses, isDarkMode } = useTheme();
    const { currency } = useCurrency();

    const subtotal = items.reduce((sum, item) => sum + item.finalPrice, 0);
    const discountAmount = subtotal * (discount / 100);
    const discountedSubtotal = subtotal - discountAmount;
    const taxAmount = discountedSubtotal * (taxRate / 100);
    const total = discountedSubtotal + taxAmount;
    
    const availableCredit = selectedCustomer ? selectedCustomer.creditLimit - selectedCustomer.creditUsed : 0;
    const canChargeToAccount = selectedCustomer !== null && selectedCustomer.creditLimit > 0 && total <= availableCredit;

    const chargeDisabledReason = () => {
        if (!selectedCustomer || selectedCustomer.creditLimit <= 0) return 'Customer has no credit account.';
        if (total > availableCredit) return 'Order total exceeds available credit.';
        return '';
    };

    return (
        <div className="flex flex-col h-full">
            <div className="flex justify-between items-center mb-4">
                <h2 className={`text-2xl font-bold ${themeClasses.textGradient}`}>Current Order</h2>
                {items.length > 0 && (
                    <button onClick={onClearCart} className={`text-xs flex items-center gap-1 ${isDarkMode ? 'text-red-400 hover:text-red-300' : 'text-red-600 hover:text-red-500'}`}>
                        <Trash2 size={14} /> Clear All
                    </button>
                )}
            </div>
            
            <div className="flex-grow overflow-y-auto -mr-2 pr-2 custom-scrollbar">
                {items.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center text-slate-500">
                        <Receipt size={48} className="mb-4" />
                        <p className="font-semibold">Your cart is empty</p>
                        <p className="text-sm">Click on a product to add it to the order.</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {items.map(item => {
                            const product = productMap[item.productId];
                            if (!product) return null;
                            const hasOverride = item.finalPrice !== product.price;
                            return (
                                <div key={item.serialNumber} className={`p-3 rounded-2xl flex items-center gap-3 ${isDarkMode ? 'bg-white/5' : 'bg-black/5'}`}>
                                    <div className="flex-grow overflow-hidden">
                                        <p className="font-semibold leading-tight truncate">{product.name}</p>
                                        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>SN: {item.serialNumber}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-semibold">{formatCurrency(item.finalPrice, currency)}</p>
                                        {hasOverride && <p className="text-xs text-slate-500 line-through">{formatCurrency(product.price, currency)}</p>}
                                    </div>
                                    <button onClick={() => onEditPrice(item)} className={`p-1 rounded-full ${isDarkMode ? 'hover:bg-amber-500/20 text-amber-400' : 'hover:bg-amber-200 text-amber-500'}`}><Edit3 size={16} /></button>
                                    <button onClick={() => onRemoveItem(item.serialNumber)} className={`p-1 rounded-full ${isDarkMode ? 'hover:bg-red-500/20 text-red-400' : 'hover:bg-red-200 text-red-500'}`}><X size={16} /></button>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {items.length > 0 && (
                <div className="pt-4 mt-auto">
                    <div className={`p-4 rounded-2xl mb-4 flex justify-between items-center ${isDarkMode ? 'bg-white/5' : 'bg-black/5'}`}>
                        <div className='flex items-center gap-3'>
                            <User className={`${themeClasses.kpiIconText}`}/>
                            <div>
                                <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Customer</p>
                                <p className="font-semibold">{selectedCustomer?.name || 'Walk-in Customer'}</p>
                            </div>
                        </div>
                        <button onClick={onSelectCustomerClick} className={`text-sm font-semibold flex items-center gap-1 ${isDarkMode ? 'text-amber-400 hover:text-amber-300' : 'text-blue-600 hover:text-blue-500'}`}>
                            <Edit3 size={14} /> Change
                        </button>
                    </div>

                    <div className="border-t border-slate-700/20 pt-4 space-y-2">
                        <div className="flex justify-between text-base">
                            <span>Subtotal</span>
                            <span className="font-medium">{formatCurrency(subtotal, currency)}</span>
                        </div>
                        <div className="flex justify-between items-center text-base">
                            <span>Discount (%)</span>
                            <input 
                                type="number"
                                value={discount}
                                onChange={e => onDiscountChange(parseFloat(e.target.value))}
                                className={`w-20 p-1 text-right rounded-md border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
                                placeholder="0"
                            />
                        </div>
                         {discount > 0 && (
                            <div className="flex justify-between text-red-400 text-base">
                                <span>Discount Amount</span>
                                <span className="font-medium">-{formatCurrency(discountAmount, currency)}</span>
                            </div>
                        )}
                        <div className={`flex justify-between text-base ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                            <span>Tax ({taxRate.toFixed(2)}%)</span>
                            <span className="font-medium">{formatCurrency(taxAmount, currency)}</span>
                        </div>
                        <div className="flex justify-between text-2xl font-bold pt-2 border-t border-slate-700/20">
                            <span className={`${themeClasses.textGradient}`}>Total</span>
                            <span>{formatCurrency(total, currency)}</span>
                        </div>
                        <div className="pt-4 space-y-3">
                            <div className="grid grid-cols-3 gap-3">
                                <button 
                                    onClick={() => onCompleteSale('Cash')} 
                                    className={`w-full py-3 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-transform duration-200 hover:scale-105 ${themeClasses.button}`}
                                >
                                    <DollarSign size={20} /> Cash
                                </button>
                                <button 
                                    onClick={() => onCompleteSale('Card')} 
                                    className={`w-full py-3 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-transform duration-200 hover:scale-105 ${themeClasses.button}`}
                                >
                                    <CreditCard size={20} /> Card
                                </button>
                                <button 
                                    onClick={() => onCompleteSale('Mobile Money')} 
                                    className={`w-full py-3 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-transform duration-200 hover:scale-105 ${themeClasses.button}`}
                                >
                                    <Smartphone size={20} /> Mobile
                                </button>
                            </div>
                             <button 
                                onClick={() => onCompleteSale('Credit')}
                                disabled={!canChargeToAccount}
                                title={chargeDisabledReason()}
                                className={`w-full py-3 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-colors duration-200 border-2 ${isDarkMode ? 'border-slate-600' : 'border-slate-300'} disabled:opacity-50 disabled:cursor-not-allowed disabled:text-slate-600 disabled:bg-transparent ${!canChargeToAccount ? '' : isDarkMode ? 'hover:bg-amber-500/10 hover:border-amber-500/20' : 'hover:bg-blue-500/10 hover:border-blue-200'}`}
                            >
                                Charge to Account
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OrderSummary;
