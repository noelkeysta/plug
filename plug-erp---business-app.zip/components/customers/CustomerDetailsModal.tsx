
import React, { useMemo, useState } from 'react';
import { Customer, Transaction, Product } from '../../types';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { formatCurrency } from '../../utils/formatters';
import { format } from 'date-fns';
import { Search } from 'lucide-react';

interface CustomerDetailsModalProps {
    customer: Customer & { totalSpent: number };
    transactions: Transaction[];
    products: Product[];
}

const CustomerDetailsModal: React.FC<CustomerDetailsModalProps> = ({ customer, transactions, products }) => {
    const { isDarkMode } = useTheme();
    const { currency } = useCurrency();
    const [searchQuery, setSearchQuery] = useState('');

    const customerTransactions = useMemo(() => {
        let filtered = transactions.filter(t => t.customerId === customer.id);
        if (searchQuery) {
            filtered = filtered.filter(t => 
                t.id.toString().includes(searchQuery) ||
                t.items.some(item => products.find(p => p.id === item.productId)?.name.toLowerCase().includes(searchQuery.toLowerCase()))
            );
        }
        return filtered.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }, [transactions, customer.id, searchQuery, products]);

    return (
        <div className="max-h-[70vh] flex flex-col space-y-4">
            <div className={`p-4 rounded-lg grid grid-cols-2 md:grid-cols-4 gap-4 ${isDarkMode ? 'bg-slate-800/50' : 'bg-slate-100'}`}>
                <div>
                    <p className="text-sm text-slate-400">Total Spent</p>
                    <p className="font-semibold text-lg">{formatCurrency(customer.totalSpent, currency)}</p>
                </div>
                <div>
                    <p className="text-sm text-slate-400">Credit Limit</p>
                    <p className="font-semibold text-lg">{formatCurrency(customer.creditLimit, currency)}</p>
                </div>
                <div>
                    <p className="text-sm text-slate-400">Credit Used</p>
                    <p className="font-semibold text-lg">{formatCurrency(customer.creditUsed, currency)}</p>
                </div>
                 <div>
                    <p className="text-sm text-slate-400">Member Since</p>
                    <p className="font-semibold text-lg">{format(new Date(customer.joinDate), 'dd MMM yyyy')}</p>
                </div>
            </div>

            <div className="relative">
                <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDarkMode ? 'text-amber-400' : 'text-blue-600'}`} />
                <input
                    type="text"
                    placeholder="Search transactions by ID or product name..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className={`w-full pl-10 pr-4 py-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600' : 'border-slate-300'}`}
                />
            </div>

            <div className="flex-grow overflow-y-auto pr-2 -mr-4">
                <table className="w-full text-left text-sm">
                    <thead className={`sticky top-0 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`}>
                        <tr className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-blue-200/40'}`}>
                            <th className="p-2">Date</th>
                            <th className="p-2">Transaction ID</th>
                            <th className="p-2">Items</th>
                            <th className="p-2 text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {customerTransactions.map(t => (
                            <tr key={t.id} className={`border-b ${isDarkMode ? 'border-slate-800/50' : 'border-slate-200'}`}>
                                <td className="p-2 whitespace-nowrap">{format(new Date(t.timestamp), 'dd-MM-yy HH:mm')}</td>
                                <td className="p-2 font-mono">#{t.id}</td>
                                <td className="p-2">{t.items.length}</td>
                                <td className="p-2 text-right font-mono font-semibold">{formatCurrency(t.totalAmount, currency)}</td>
                            </tr>
                        ))}
                         {customerTransactions.length === 0 && (
                            <tr>
                                <td colSpan={4} className="text-center p-8 text-slate-500">
                                    No transactions found for this customer.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default CustomerDetailsModal;
