
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addCustomer } from '../../services/mockDataService';
import { User } from '../../types';

interface AddCustomerModalProps {
  onClose: () => void;
  user: User | null;
}

const customerSchema = z.object({
  name: z.string().min(3, 'Customer name must be at least 3 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().min(9, 'Please enter a valid phone number'),
  creditLimit: z.number().min(0, 'Credit limit must be zero or more').optional(),
});

type CustomerFormData = z.infer<typeof customerSchema>;

const AddCustomerModal: React.FC<AddCustomerModalProps> = ({ onClose, user }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { notifySuccess } = useNotifier();

  const { register, handleSubmit, formState: { errors } } = useForm<CustomerFormData>({
    resolver: zodResolver(customerSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      creditLimit: 0,
    }
  });

  const onSubmit = (formData: CustomerFormData) => {
    if (user) {
      const newCustomer = addCustomer({ ...formData, creditLimit: formData.creditLimit || 0 }, user.id);
      if (newCustomer) {
        notifySuccess(`Customer "${newCustomer.name}" added successfully!`);
      }
      onClose();
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label htmlFor="name" className={labelClasses}>Full Name</label>
        <input type="text" id="name" {...register('name')} className={inputClasses} autoFocus />
        {errors.name && <p className={errorClasses}>{errors.name.message}</p>}
      </div>
       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label htmlFor="email" className={labelClasses}>Email Address</label>
            <input type="email" id="email" {...register('email')} className={inputClasses} />
            {errors.email && <p className={errorClasses}>{errors.email.message}</p>}
        </div>
        <div>
            <label htmlFor="phone" className={labelClasses}>Phone Number</label>
            <input type="tel" id="phone" {...register('phone')} className={inputClasses} />
            {errors.phone && <p className={errorClasses}>{errors.phone.message}</p>}
        </div>
      </div>
      <div>
        <label htmlFor="creditLimit" className={labelClasses}>Credit Limit</label>
        <input type="number" id="creditLimit" {...register('creditLimit', { valueAsNumber: true })} className={inputClasses} />
        {errors.creditLimit && <p className={errorClasses}>{errors.creditLimit.message}</p>}
      </div>
      
      <div className="flex justify-end items-center gap-4 pt-4">
        <button type="button" onClick={onClose} className="font-semibold">Cancel</button>
        <button
          type="submit"
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Add Customer
        </button>
      </div>
    </form>
  );
};

export default AddCustomerModal;
