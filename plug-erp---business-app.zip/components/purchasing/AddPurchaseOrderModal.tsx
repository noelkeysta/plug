
import React, { useMemo } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addPurchaseOrder } from '../../services/mockDataService';
import { User } from '../../types';
import { useData } from '../../contexts/DataContext';
import { X, Plus } from 'lucide-react';

interface AddPurchaseOrderModalProps {
  onClose: () => void;
  user: User | null;
}

const orderItemSchema = z.object({
    productId: z.string().min(1, 'Product must be selected'),
    quantity: z.number().positive('Quantity must be positive'),
    cost: z.number().positive(),
});

const purchaseOrderSchema = z.object({
    supplierId: z.number().min(1, 'A supplier must be selected.'),
    expectedDeliveryDate: z.string().min(1, 'Expected delivery date is required.'),
    items: z.array(orderItemSchema).min(1, 'At least one item must be added to the order.'),
});

type PurchaseOrderFormData = z.infer<typeof purchaseOrderSchema>;

const AddPurchaseOrderModal: React.FC<AddPurchaseOrderModalProps> = ({ onClose, user }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { currency } = useCurrency();
  const { data, refreshData } = useData();
  const { suppliers, products } = data || { suppliers: [], products: [] };
  const { notifySuccess, notifyInfo } = useNotifier();

  const { register, control, handleSubmit, formState: { errors }, watch, setValue } = useForm<PurchaseOrderFormData>({
    resolver: zodResolver(purchaseOrderSchema),
    defaultValues: {
      supplierId: suppliers[0]?.id || 0,
      expectedDeliveryDate: '',
      items: [],
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "items"
  });

  const supplierId = watch('supplierId');
  const items = watch('items') || [];

  const availableProducts = useMemo(() => {
    return products.filter(p => p.supplierId === supplierId && !items.some(item => item.productId === p.id));
  }, [products, supplierId, items]);

  const totalCost = useMemo(() => {
    return items.reduce((sum, item) => sum + (Number(item.cost) * Number(item.quantity)), 0);
  }, [items]);

  const handleAddItem = () => {
    if (availableProducts.length > 0) {
      const product = availableProducts[0];
      append({ productId: product.id, quantity: 1, cost: product.cost });
    }
  };
  
  const handleProductChange = (index: number, productId: string) => {
    const newProduct = products.find(p => p.id === productId);
    if(newProduct) {
        setValue(`items.${index}.cost`, newProduct.cost);
        setValue(`items.${index}.productId`, newProduct.id);
    }
  };

  const onSubmit = (formData: PurchaseOrderFormData) => {
    if (user) {
      const newOrder = addPurchaseOrder({
        ...formData,
        expectedDeliveryDate: new Date(formData.expectedDeliveryDate),
        totalCost
      }, user.id);
      if (newOrder) {
        refreshData();
        notifySuccess(`Purchase Order ${newOrder.id} created successfully!`);
      }
      onClose();
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  const { onChange: supplierIdOnChange, ...supplierIdProps } = register('supplierId', { valueAsNumber: true });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="supplierId" className={labelClasses}>Supplier</label>
          <select 
            {...supplierIdProps}
            id="supplierId" 
            className={inputClasses} 
            onChange={e => {
                supplierIdOnChange(e);
                if (items.length > 0) {
                    notifyInfo('Item list cleared due to supplier change.');
                }
                setValue('items', []);
            }}
          >
            {suppliers.map(s => <option key={s.id} value={s.id} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{s.name}</option>)}
          </select>
          {errors.supplierId && <p className={errorClasses}>{errors.supplierId.message}</p>}
        </div>
        <div>
          <label htmlFor="expectedDeliveryDate" className={labelClasses}>Expected Delivery</label>
          <input type="date" id="expectedDeliveryDate" {...register('expectedDeliveryDate')} className={inputClasses} />
          {errors.expectedDeliveryDate && <p className={errorClasses}>{errors.expectedDeliveryDate.message}</p>}
        </div>
      </div>
      
      <div className="space-y-2">
        <label className={labelClasses}>Items</label>
        {fields.map((field, index) => (
          <div key={field.id} className="p-2 rounded-lg bg-black/10">
            <div className="flex items-center gap-2">
                <select 
                    {...register(`items.${index}.productId`)} 
                    onChange={e => handleProductChange(index, e.target.value)}
                    className={`${inputClasses} flex-grow`}
                >
                {products.filter(p => p.supplierId === supplierId).map(p => (
                    <option key={p.id} value={p.id} disabled={items.some(i => i.productId === p.id && i.productId !== field.productId)} className={isDarkMode ? 'bg-slate-800' : 'bg-white'}>{p.name}</option>
                ))}
                </select>
                <input type="number" placeholder="Qty" {...register(`items.${index}.quantity`, { valueAsNumber: true })} className={`${inputClasses} w-20`} />
                <button type="button" onClick={() => remove(index)} className="p-2 rounded-full hover:bg-red-500/20 text-red-400">
                <X size={16} />
                </button>
            </div>
            {errors.items?.[index]?.quantity && <p className={errorClasses}>{errors.items[index]?.quantity?.message}</p>}
          </div>
        ))}
        {errors.items && typeof errors.items.message === 'string' && <p className={errorClasses}>{errors.items.message}</p>}
      </div>

      <button type="button" onClick={handleAddItem} disabled={availableProducts.length === 0} className={`w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg border-dashed border-2 ${isDarkMode ? 'border-slate-600 hover:bg-slate-700' : 'border-slate-300 hover:bg-slate-100'} transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}>
        <Plus size={16} />
        Add Item
      </button>

      <div className="pt-4 border-t border-slate-700/50 flex justify-between items-center">
        <div>
            <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Total Cost</p>
            <p className={`text-2xl font-bold ${themeClasses.textGradient}`}>{currency.symbol}{totalCost.toFixed(2)}</p>
        </div>
        <button
          type="submit"
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Create Purchase Order
        </button>
      </div>
    </form>
  );
};

export default AddPurchaseOrderModal;
