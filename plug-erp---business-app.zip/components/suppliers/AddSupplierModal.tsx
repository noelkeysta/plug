
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTheme } from '../../contexts/ThemeContext';
import { useNotifier } from '../../contexts/NotificationContext';
import { addSupplier } from '../../services/mockDataService';
import { User } from '../../types';
import { useData } from '../../contexts/DataContext';

interface AddSupplierModalProps {
  onClose: () => void;
  user: User | null;
}

const supplierSchema = z.object({
  name: z.string().min(3, 'Supplier name must be at least 3 characters'),
  contact: z.string().email('Please enter a valid email address'),
});

type SupplierFormData = z.infer<typeof supplierSchema>;

const AddSupplierModal: React.FC<AddSupplierModalProps> = ({ onClose, user }) => {
  const { isDarkMode, themeClasses } = useTheme();
  const { notifySuccess } = useNotifier();
  const { refreshData } = useData();

  const { register, handleSubmit, formState: { errors } } = useForm<SupplierFormData>({
    resolver: zodResolver(supplierSchema),
    defaultValues: {
      name: '',
      contact: '',
    }
  });

  const onSubmit = (data: SupplierFormData) => {
    if (user) {
      const newSupplier = addSupplier(data, user.id);
      if (newSupplier) {
        refreshData();
        notifySuccess(`Supplier "${newSupplier.name}" added successfully!`);
      }
      onClose();
    }
  };
  
  const labelClasses = `text-sm font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`;
  const inputClasses = `w-full mt-1 p-2 rounded-lg border bg-transparent ${isDarkMode ? 'border-slate-600 text-white focus:border-amber-500' : 'border-slate-300 text-black focus:border-blue-500'} focus:outline-none focus:ring-0`;
  const errorClasses = "text-red-400 text-xs mt-1";

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label htmlFor="name" className={labelClasses}>Supplier Name</label>
        <input type="text" id="name" {...register('name')} className={inputClasses} />
        {errors.name && <p className={errorClasses}>{errors.name.message}</p>}
      </div>
      <div>
        <label htmlFor="contact" className={labelClasses}>Contact Email</label>
        <input type="email" id="contact" {...register('contact')} className={inputClasses} />
        {errors.contact && <p className={errorClasses}>{errors.contact.message}</p>}
      </div>
      
      <div className="flex justify-end pt-4">
        <button
          type="submit"
          className={`px-6 py-2 rounded-full font-semibold transition-transform duration-300 hover:scale-105 ${themeClasses.button}`}
        >
          Add Supplier
        </button>
      </div>
    </form>
  );
};

export default AddSupplierModal;
