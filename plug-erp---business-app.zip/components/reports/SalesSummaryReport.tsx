import React, { useMemo } from 'react';
import { Transaction, Product, TransactionType } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useTheme } from '../../contexts/ThemeContext';
import { formatCurrency } from '../../utils/formatters';
import { format, isWithinInterval } from 'date-fns';
import Card from '../ui/Card';

interface SalesSummaryReportProps {
    transactions: Transaction[], 
    products: Product[], 
    dateRange: {start: Date, end: Date}, 
    filters: {cashierId: string, categoryId: string}
}

const SalesSummaryReport: React.FC<SalesSummaryReportProps> = ({ transactions, products, dateRange, filters }) => {
    const { currency } = useCurrency();
    const { isDarkMode } = useTheme();
    const productCategoryMap = useMemo(() => products.reduce((acc, product) => ({ ...acc, [product.id]: product.category }), {} as Record<string, string>), [products]);

    const filteredTransactions = useMemo(() => transactions.filter(t => {
        if (t.type !== TransactionType.SALE || !isWithinInterval(new Date(t.timestamp), dateRange)) return false;
        if (filters.cashierId !== 'all' && t.cashierId !== Number(filters.cashierId)) return false;
        if (filters.categoryId !== 'all' && !t.items.some(item => productCategoryMap[item.productId] === filters.categoryId)) return false;
        return true;
    }).sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()), [transactions, dateRange, filters, productCategoryMap]);
    
    const totalRevenue = filteredTransactions.reduce((sum, t) => sum + t.totalAmount, 0);

    return (
        <Card className="!p-0 overflow-hidden card-print">
            <div className="p-6">
                <h3 className="text-xl font-bold text-gradient-print">Sales from {format(dateRange.start, 'dd MMM yyyy')} to {format(dateRange.end, 'dd MMM yyyy')}</h3>
                <div className="grid grid-cols-2 gap-4 mt-4">
                    <div><p className={`${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Total Revenue</p><p className="text-2xl font-bold">{formatCurrency(totalRevenue, currency)}</p></div>
                    <div><p className={`${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Total Sales</p><p className="text-2xl font-bold">{filteredTransactions.length}</p></div>
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-slate-200'}`}>
                        <tr>
                            <th className="p-4">ID</th>
                            <th className="p-4">Date</th>
                            <th className="p-4">Items</th>
                            <th className="p-4 text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTransactions.map(t => (
                            <tr key={t.id} className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                <td className="p-4 font-mono">#{t.id}</td>
                                <td className="p-4">{format(new Date(t.timestamp), 'dd MMM yyyy, HH:mm')}</td>
                                <td className="p-4">{t.items.length}</td>
                                <td className="p-4 text-right font-semibold">{formatCurrency(t.totalAmount, currency)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
}

export default SalesSummaryReport;
