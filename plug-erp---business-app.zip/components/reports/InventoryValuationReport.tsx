import React, { useMemo } from 'react';
import { Product, InventoryItem } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useTheme } from '../../contexts/ThemeContext';
import { formatCurrency } from '../../utils/formatters';
import Card from '../ui/Card';

interface InventoryValuationReportProps {
    products: Product[],
    inventoryItems: InventoryItem[], 
    filters: { supplierId: string }
}

const InventoryValuationReport: React.FC<InventoryValuationReportProps> = ({ products, inventoryItems, filters }) => {
    const { currency } = useCurrency();
    const { isDarkMode } = useTheme();
    const productStockMap = useMemo(() => (inventoryItems || []).reduce((acc, item) => { if (item.status === 'available') { acc[item.productId] = (acc[item.productId] || 0) + 1; } return acc; }, {} as Record<string, number>), [inventoryItems]);
    const productsWithStock = useMemo(() => 
        products
            .filter(p => filters.supplierId === 'all' || p.supplierId === Number(filters.supplierId))
            .map(p => ({...p, stock: productStockMap[p.id] || 0})), 
        [products, productStockMap, filters.supplierId]);
    const totalValue = productsWithStock.reduce((sum, p) => sum + (p.stock * p.cost), 0);
    return (
        <Card className="!p-0 overflow-hidden card-print">
            <div className="p-6">
                <h3 className="text-xl font-bold text-gradient-print">Inventory Valuation</h3>
                <div>
                    <p className={`${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Total Value (at cost)</p>
                    <p className="text-2xl font-bold">{formatCurrency(totalValue, currency)}</p>
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-slate-200'}`}>
                        <tr>
                            <th className="p-4">Product</th>
                            <th className="p-4 text-right">Stock</th>
                            <th className="p-4 text-right">Cost/Unit</th>
                            <th className="p-4 text-right">Total Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        {productsWithStock.map(p => (
                            <tr key={p.id} className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                <td className="p-4 font-semibold">{p.name}</td>
                                <td className="p-4 text-right">{p.stock}</td>
                                <td className="p-4 text-right">{formatCurrency(p.cost, currency)}</td>
                                <td className="p-4 text-right font-semibold">{formatCurrency(p.stock * p.cost, currency)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
}

export default InventoryValuationReport;
