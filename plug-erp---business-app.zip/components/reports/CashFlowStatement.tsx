import React, { useMemo } from 'react';
import { LedgerEntry, Account, AccountType } from '../../types';
import Card from '../ui/Card';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useTheme } from '../../contexts/ThemeContext';
import { formatCurrency } from '../../utils/formatters';
import { format, isWithinInterval } from 'date-fns';
import sub from 'date-fns/sub';

interface CashFlowStatementProps {
  ledger: LedgerEntry[];
  accounts: Account[];
  dateRange: { start: Date; end: Date };
}

const CashFlowStatement: React.FC<CashFlowStatementProps> = ({ ledger, accounts, dateRange }) => {
    const { currency } = useCurrency();
    const { isDarkMode } = useTheme();

    const reportData = useMemo(() => {
        const periodLedger = ledger.filter(entry => isWithinInterval(new Date(entry.timestamp), dateRange));
        const previousPeriodStart = sub(dateRange.start, { days: 1 });
        
        const getBalanceAsOf = (date: Date, accountId: string) => {
            return ledger.filter(e => e.accountId === accountId && new Date(e.timestamp) <= date)
                         .reduce((sum, e) => sum + e.amount, 0);
        };
        
        const getBalanceForPeriod = (accountId: string) => {
             return periodLedger.filter(e => e.accountId === accountId)
                                .reduce((sum, e) => sum + e.amount, 0);
        }

        // --- Operating Activities ---
        const totalRevenue = getBalanceForPeriod(accounts.filter(a => a.type === AccountType.REVENUE).map(a => a.id).join());
        const totalExpenses = getBalanceForPeriod(accounts.filter(a => a.type === AccountType.COST_OF_GOODS_SOLD || a.type === AccountType.EXPENSE).map(a => a.id).join());
        const netIncome = -(totalRevenue + totalExpenses);

        const depreciation = Math.abs(getBalanceForPeriod('6080')); // Depreciation expense
        const loanFeeAmortization = Math.abs(getBalanceForPeriod('6100'));

        const changeInAR = -(getBalanceAsOf(dateRange.end, '1100') - getBalanceAsOf(previousPeriodStart, '1100'));
        const changeInInventory = -(getBalanceAsOf(dateRange.end, '1200') - getBalanceAsOf(previousPeriodStart, '1200'));
        const changeInPrepaid = -(getBalanceAsOf(dateRange.end, '1400') - getBalanceAsOf(previousPeriodStart, '1400'));
        const changeInAP = getBalanceAsOf(dateRange.end, '2100') - getBalanceAsOf(previousPeriodStart, '2100');
        const changeInTaxPayable = getBalanceAsOf(dateRange.end, '2500') - getBalanceAsOf(previousPeriodStart, '2500');
        const changeInWarranty = getBalanceAsOf(dateRange.end, '2400') - getBalanceAsOf(previousPeriodStart, '2400');
        
        const cashFromOps = netIncome + depreciation + loanFeeAmortization + changeInAR + changeInInventory + changeInPrepaid - changeInAP - changeInTaxPayable - changeInWarranty;

        // --- Investing Activities ---
        const changeInPPE = -getBalanceForPeriod('1510');
        const cashFromInvesting = changeInPPE;

        // --- Financing Activities ---
        const changeInLoan = -getBalanceForPeriod('2010');
        const changeInCapital = -getBalanceForPeriod('3000');
        const cashFromFinancing = changeInLoan + changeInCapital;

        const netCashChange = cashFromOps + cashFromInvesting + cashFromFinancing;
        const beginningCash = getBalanceAsOf(previousPeriodStart, '1010');
        const endingCash = getBalanceAsOf(dateRange.end, '1010');

        return {
            operating: [
                { name: 'Net Income', value: netIncome },
                { name: 'Depreciation & Amortization', value: depreciation + loanFeeAmortization },
                { name: 'Change in Accounts Receivable', value: changeInAR },
                { name: 'Change in Inventory', value: changeInInventory },
                { name: 'Change in Prepaid Expenses', value: changeInPrepaid },
                { name: 'Change in Accounts Payable', value: -changeInAP },
                { name: 'Change in Tax/Warranty Payable', value: -(changeInTaxPayable + changeInWarranty) },
            ],
            investing: [
                { name: 'Purchase of Equipment', value: changeInPPE }
            ],
            financing: [
                { name: 'Loan Activity (Repayments)', value: changeInLoan },
                { name: 'Owner Capital Injection', value: changeInCapital }
            ],
            cashFromOps, cashFromInvesting, cashFromFinancing,
            netCashChange, beginningCash, endingCash,
        };
    }, [ledger, accounts, dateRange]);

    const LineItem: React.FC<{ label: string; amount: number; isSubtotal?: boolean; isTotal?: boolean; isIndent?: boolean, isNegative?: boolean }> = ({ label, amount, isSubtotal = false, isTotal = false, isIndent=false }) => (
        <div className={`flex justify-between py-2 ${isSubtotal || isTotal ? `font-bold` : ''} ${isTotal ? 'text-lg' : ''} ${isIndent ? 'pl-6' : ''}`}>
            <span>{label}</span>
            <span className={`font-mono ${amount < 0 ? (isDarkMode ? 'text-red-400' : 'text-red-600') : ''}`}>{amount < 0 ? `(${formatCurrency(Math.abs(amount), currency)})` : formatCurrency(amount, currency)}</span>
        </div>
    );
    
    const Section: React.FC<{title: string, items: {name: string, value: number}[], total: number}> = ({title, items, total}) => (
        <>
            <div className={`py-2 mt-4 font-bold border-b-2 ${isDarkMode ? 'border-amber-400' : 'border-blue-600'}`}>{title}</div>
            {items.filter(i => Math.round(i.value) !== 0).map(item => (
                <LineItem key={item.name} label={item.name} amount={item.value} isIndent />
            ))}
            <LineItem label={`Net Cash from ${title}`} amount={total} isSubtotal />
        </>
    )

    return (
        <Card className="card-print">
            <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-gradient-print">Statement of Cash Flows</h1>
                <p className={isDarkMode ? 'text-slate-400' : 'text-slate-500'}>For the period {format(dateRange.start, 'dd MMM yyyy')} to {format(dateRange.end, 'dd MMM yyyy')}</p>
            </div>
            
            <div className="max-w-2xl mx-auto">
                <Section title="Operating Activities" items={reportData.operating} total={reportData.cashFromOps} />
                <Section title="Investing Activities" items={reportData.investing} total={reportData.cashFromInvesting} />
                <Section title="Financing Activities" items={reportData.financing} total={reportData.cashFromFinancing} />

                <LineItem label="Net Change in Cash" amount={reportData.netCashChange} isTotal />
                <LineItem label="Beginning Cash Balance" amount={reportData.beginningCash} />
                <LineItem label="Ending Cash Balance" amount={reportData.endingCash} isSubtotal />
            </div>
        </Card>
    );
};

export default CashFlowStatement;
