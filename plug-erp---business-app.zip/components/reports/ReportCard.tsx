import React from 'react';
import type { LucideIcon } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import Card from '../ui/Card';
import { ArrowRight } from 'lucide-react';

interface ReportCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  onClick: () => void;
}

const ReportCard: React.FC<ReportCardProps> = ({ title, description, icon: Icon, onClick }) => {
  const { themeClasses, isDarkMode } = useTheme();

  return (
    <Card 
        className="group hover:transform hover:scale-105 hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col"
        onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div className={`p-3 rounded-full ${themeClasses.kpiIconBg} mb-4`}>
          <Icon className={`w-7 h-7 ${themeClasses.kpiIconText}`} />
        </div>
      </div>
      <div className="flex-grow">
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className={`text-sm ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{description}</p>
      </div>
      <div className="mt-4 flex items-center justify-end text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <span className={`${themeClasses.textGradient}`}>View Report</span>
        <ArrowRight className={`w-4 h-4 ml-2 ${isDarkMode ? 'text-amber-400' : 'text-blue-500'}`} />
      </div>
    </Card>
  );
};

export default ReportCard;
