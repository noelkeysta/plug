
import React, { useMemo } from 'react';
import { LedgerEntry, Account, AccountType } from '../../types';
import Card from '../ui/Card';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useTheme } from '../../contexts/ThemeContext';
import { formatCurrency } from '../../utils/formatters';
import { format, isWithinInterval } from 'date-fns';

interface IncomeStatementProps {
  ledger: LedgerEntry[];
  accounts: Account[];
  dateRange: { start: Date; end: Date };
}

const IncomeStatement: React.FC<IncomeStatementProps> = ({ ledger, accounts, dateRange }) => {
    const { currency } = useCurrency();
    const { isDarkMode } = useTheme();

    const accountMap = useMemo(() => accounts.reduce((map, acc) => {
        map[acc.id] = acc;
        return map;
    }, {} as Record<string, Account>), [accounts]);

    const reportData = useMemo(() => {
        const periodLedger = ledger.filter(entry => isWithinInterval(new Date(entry.timestamp), dateRange));
        
        const getBalanceForAccountIds = (accountIds: string[]) => {
            const balance = periodLedger
                .filter(e => accountIds.includes(e.accountId))
                .reduce((sum, e) => sum + e.amount, 0);
            return Math.abs(balance);
        };
        
        const revenue = getBalanceForAccountIds(accounts.filter(a => a.type === AccountType.REVENUE).map(a => a.id));
        const cogs = getBalanceForAccountIds(accounts.filter(a => a.type === AccountType.COST_OF_GOODS_SOLD).map(a => a.id));
        
        const operatingExpenseAccountIds = ['6010', '6020', '6030', '6040', '6050', '6060', '6065', '6080', '6090', '6900'];
        const detailedOperatingExpenses = operatingExpenseAccountIds.map(id => ({
            name: accountMap[id]?.name || 'Unknown Expense',
            amount: getBalanceForAccountIds([id])
        })).filter(exp => exp.amount > 0);

        const totalOperatingExpenses = detailedOperatingExpenses.reduce((sum, exp) => sum + exp.amount, 0);
        
        const interestExpense = getBalanceForAccountIds(['6070']);
        const loanFeeAmortization = getBalanceForAccountIds(['6100']);
        const incomeTax = getBalanceForAccountIds(['6800']);

        const grossProfit = revenue - cogs;
        const operatingProfit = grossProfit - totalOperatingExpenses;
        const profitBeforeTax = operatingProfit - interestExpense - loanFeeAmortization;
        const netIncome = profitBeforeTax - incomeTax;

        return { revenue, cogs, grossProfit, detailedOperatingExpenses, totalOperatingExpenses, operatingProfit, interestExpense, loanFeeAmortization, profitBeforeTax, incomeTax, netIncome };
    }, [ledger, accounts, dateRange, accountMap]);

    const LineItem: React.FC<{ label: string; amount: number; isSubtotal?: boolean; isTotal?: boolean; isIndent?: boolean, isNegative?: boolean }> = ({ label, amount, isSubtotal = false, isTotal = false, isIndent=false, isNegative = false }) => (
        <div className={`flex justify-between py-2 ${isSubtotal || isTotal ? `border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-300'} font-bold` : ''} ${isIndent ? 'pl-6' : ''}`}>
            <span>{label}</span>
            <span className={`font-mono ${isNegative ? (isDarkMode ? 'text-red-400' : 'text-red-600') : ''}`}>{isNegative ? '-' : ''}{formatCurrency(amount, currency)}</span>
        </div>
    );
    
    return (
        <Card className="card-print">
            <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-gradient-print">Income Statement</h1>
                <p className={isDarkMode ? 'text-slate-400' : 'text-slate-500'}>For the period {format(dateRange.start, 'dd MMM yyyy')} to {format(dateRange.end, 'dd MMM yyyy')}</p>
            </div>
            
            <div className="max-w-2xl mx-auto">
                <LineItem label="Sales Revenue" amount={reportData.revenue} />
                <LineItem label="Cost of Goods Sold" amount={reportData.cogs} isIndent isNegative />
                <LineItem label="Gross Profit" amount={reportData.grossProfit} isSubtotal />

                <div className="py-2 mt-4 font-bold">Operating Expenses</div>
                {reportData.detailedOperatingExpenses.map(exp => (
                    <LineItem key={exp.name} label={exp.name} amount={exp.amount} isIndent isNegative />
                ))}
                <LineItem label="Total Operating Expenses" amount={reportData.totalOperatingExpenses} isSubtotal isNegative/>
                <LineItem label="Operating Profit" amount={reportData.operatingProfit} isSubtotal />
                
                <LineItem label="Interest Expense" amount={reportData.interestExpense} isIndent isNegative />
                <LineItem label="Loan Fee Amortization" amount={reportData.loanFeeAmortization} isIndent isNegative />
                <LineItem label="Profit Before Tax" amount={reportData.profitBeforeTax} isSubtotal />
                
                <LineItem label="Income Tax" amount={reportData.incomeTax} isIndent isNegative />
                <LineItem label="Profit for the Year" amount={reportData.netIncome} isTotal />
            </div>
        </Card>
    );
};

export default IncomeStatement;
