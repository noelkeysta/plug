import React, { useMemo } from 'react';
import { Expense } from '../../types';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useTheme } from '../../contexts/ThemeContext';
import { formatCurrency } from '../../utils/formatters';
import { isWithinInterval } from 'date-fns';
import Card from '../ui/Card';

interface ExpenseBreakdownReportProps {
    expenses: Expense[], 
    dateRange: { start: Date, end: Date }
}

const ExpenseBreakdownReport: React.FC<ExpenseBreakdownReportProps> = ({ expenses, dateRange }) => {
    const { currency } = useCurrency();
    const { isDarkMode } = useTheme();
    const filteredExpenses = useMemo(() => expenses.filter(e => isWithinInterval(new Date(e.date), dateRange)), [expenses, dateRange]);
    const expenseByCategory = useMemo(() => filteredExpenses.reduce((acc, expense) => ({ ...acc, [expense.category]: (acc[expense.category] || 0) + expense.amount }), {} as Record<string, number>), [filteredExpenses]);
    const totalExpenses = Object.values(expenseByCategory).reduce((sum, amount) => sum + amount, 0);
    return (
        <Card className="!p-0 overflow-hidden card-print">
            <div className="p-6">
                <h3 className="text-xl font-bold text-gradient-print">Expense Breakdown</h3>
                <div>
                    <p className={`${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>Total Expenses</p>
                    <p className="text-2xl font-bold">{formatCurrency(totalExpenses, currency)}</p>
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className={`border-b ${isDarkMode ? 'border-amber-500/20' : 'border-slate-200'}`}>
                        <tr>
                            <th className="p-4">Category</th>
                            <th className="p-4">Percentage</th>
                            <th className="p-4 text-right">Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {Object.entries(expenseByCategory).map(([category, amount]) => (
                            <tr key={category} className={`border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                                <td className="p-4 font-semibold">{category}</td>
                                <td className="p-4">
                                    <div className="flex items-center gap-2">
                                        <div className={`w-full bg-slate-700 rounded-full h-2.5`}>
                                            <div className="bg-gradient-to-r from-amber-500 to-blue-500 h-2.5 rounded-full" style={{width: `${(amount/totalExpenses)*100}%`}}></div>
                                        </div>
                                        <span className="text-xs font-mono w-12 text-right">{((amount/totalExpenses)*100).toFixed(1)}%</span>
                                    </div>
                                </td>
                                <td className="p-4 text-right font-semibold">{formatCurrency(amount, currency)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
}

export default ExpenseBreakdownReport;
