
import React, { useMemo } from 'react';
import { Account, AccountType, LedgerEntry } from '../../types';
import Card from '../ui/Card';
import { useCurrency } from '../../contexts/CurrencyContext';
import { useTheme } from '../../contexts/ThemeContext';
import { formatCurrency } from '../../utils/formatters';
import { format } from 'date-fns';

interface BalanceSheetProps {
  accounts: Account[];
  ledger: LedgerEntry[];
  asOfDate: Date;
}

const BalanceSheet: React.FC<BalanceSheetProps> = ({ accounts, ledger, asOfDate }) => {
    const { currency } = useCurrency();
    const { isDarkMode } = useTheme();

    const reportData = useMemo(() => {
        const endDate = new Date(asOfDate);
        endDate.setHours(23, 59, 59, 999);
        
        const periodLedger = ledger.filter(entry => new Date(entry.timestamp) <= endDate);

        // Calculate the final balance for EVERY account up to the asOfDate
        const balances = accounts.reduce((acc, account) => {
            acc[account.id] = periodLedger
                .filter(e => e.accountId === account.id)
                .reduce((sum, e) => sum + e.amount, 0);
            return acc;
        }, {} as Record<string, number>);
        
        const getBalance = (id: string) => balances[id] || 0;
        
        // Calculate Net Income for the period. Revenue has a credit balance (negative in our system), expenses have debit (positive).
        const totalRevenue = accounts.filter(a => a.type === AccountType.REVENUE).reduce((sum, a) => sum + getBalance(a.id), 0);
        const totalExpenses = accounts.filter(a => a.type === AccountType.COST_OF_GOODS_SOLD || a.type === AccountType.EXPENSE).reduce((sum, a) => sum + getBalance(a.id), 0);
        const lifetimeNetIncome = -(totalRevenue + totalExpenses);

        // Assets
        const cash = getBalance('1010');
        const accountsReceivable = getBalance('1100');
        const inventory = getBalance('1200');
        const prepaidExpenses = getBalance('1400');
        const ppe = getBalance('1510');
        const accumulatedDepreciation = getBalance('1590'); // This will be negative
        const netPpe = ppe + accumulatedDepreciation;
        const totalAssets = cash + accountsReceivable + inventory + prepaidExpenses + netPpe;

        // Liabilities
        const accountsPayable = Math.abs(getBalance('2100'));
        const loanPayable = Math.abs(getBalance('2010'));
        const warrantyProvision = Math.abs(getBalance('2400'));
        const incomeTaxPayable = Math.abs(getBalance('2500'));
        const salesTaxPayable = Math.abs(getBalance('2200'));
        const totalLiabilities = accountsPayable + loanPayable + warrantyProvision + incomeTaxPayable + salesTaxPayable;

        // Equity
        const contributedCapital = Math.abs(getBalance('3000'));
        const baseRetainedEarnings = getBalance('3100'); // This is the opening RE balance (usually 0)
        const totalRetainedEarnings = baseRetainedEarnings + lifetimeNetIncome;
        const totalEquity = contributedCapital + totalRetainedEarnings;
        
        const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;

        return {
            assets: [
                { name: 'Cash', value: cash },
                { name: 'Accounts Receivable', value: accountsReceivable },
                { name: 'Inventory', value: inventory },
                { name: 'Prepaid Expenses', value: prepaidExpenses },
                { name: 'Property, Plant & Equipment (Net)', value: netPpe },
            ],
            liabilities: [
                { name: 'Accounts Payable', value: accountsPayable },
                { name: 'Loan Payable', value: loanPayable },
                { name: 'Warranty Provision', value: warrantyProvision },
                { name: 'Sales Tax Payable', value: salesTaxPayable },
                { name: 'Income Tax Payable', value: incomeTaxPayable },
            ],
            equity: [
                 { name: 'Contributed Capital', value: contributedCapital },
                 { name: 'Retained Earnings', value: totalRetainedEarnings },
            ],
            totalAssets,
            totalLiabilities,
            totalEquity,
            totalLiabilitiesAndEquity
        };
    }, [accounts, ledger, asOfDate]);

    const Section: React.FC<{ title: string; items: {name: string, value: number}[]; total: number }> = ({ title, items, total }) => (
        <div>
            <h3 className={`text-lg font-bold py-2 border-b-2 ${isDarkMode ? 'border-amber-400' : 'border-blue-600'}`}>{title}</h3>
            {items.filter(item => Math.round(item.value) !== 0).map(item => (
                <div key={item.name} className="flex justify-between py-1">
                    <span>{item.name}</span>
                    <span className="font-mono">{formatCurrency(item.value, currency)}</span>
                </div>
            ))}
            <div className={`flex justify-between py-2 border-t ${isDarkMode ? 'border-slate-700' : 'border-slate-300'} font-bold`}>
                <span>Total {title}</span>
                <span className="font-mono">{formatCurrency(total, currency)}</span>
            </div>
        </div>
    );

    return (
        <Card className="card-print">
            <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-gradient-print">Balance Sheet</h1>
                <p className={isDarkMode ? 'text-slate-400' : 'text-slate-500'}>As of {format(asOfDate, 'dd MMMM yyyy')}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                <div className="space-y-6">
                    <Section title="Assets" items={reportData.assets} total={reportData.totalAssets} />
                </div>
                <div className="space-y-6">
                    <Section title="Liabilities" items={reportData.liabilities} total={reportData.totalLiabilities} />
                    <Section title="Equity" items={reportData.equity} total={reportData.totalEquity} />
                     <div className={`flex justify-between py-2 border-t-2 ${isDarkMode ? 'border-slate-500' : 'border-slate-300'} font-bold text-lg`}>
                        <span>Total Liabilities & Equity</span>
                        <span className="font-mono">{formatCurrency(reportData.totalLiabilitiesAndEquity, currency)}</span>
                    </div>
                </div>
            </div>
        </Card>
    );
};

export default BalanceSheet;
