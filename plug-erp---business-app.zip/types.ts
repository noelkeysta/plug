
export enum AccountType {
  ASSET = 'Asset',
  LIABILITY = 'Liability',
  EQUITY = 'Equity',
  REVENUE = 'Revenue',
  EXPENSE = 'Expense',
  COST_OF_GOODS_SOLD = 'Cost of Goods Sold',
}

export interface Account {
  id: string; // e.g., '1010', '4000'
  name: string; // e.g., 'Cash', 'Sales Revenue'
  type: AccountType;
  balance: number;
}

export interface LedgerEntry {
  id: number;
  accountId: string;
  amount: number; // Positive for debit, negative for credit
  timestamp: Date;
  description: string;
  transactionId?: number | string; // Link to sale/expense/PO etc.
  relatedAccountId: string; // The other side of the entry
  batchId?: string; // Groups related entries (e.g., a single sale's debit/credit lines)
}

export enum UserRole {
  // Full system access. Can manage users, settings, and all modules.
  ADMINISTRATOR = 'Administrator',
  // Technical support, system health, and repair management.
  IT_MANAGER = 'IT Manager',
  // General operational oversight. Access to most modules but not user management.
  GENERAL_MANAGER = 'General Manager',
  // Manages sales team, has access to sales reports and advanced POS functions.
  SALES_MANAGER = 'Sales Manager',
  // Manages inventory, suppliers, and purchasing.
  INVENTORY_MANAGER = 'Inventory Manager',
  // Manages financial records, expenses, and payroll.
  ACCOUNTANT = 'Accountant',
  // Handles transactions at the Point of Sale.
  SALES_ASSOCIATE = 'Sales Associate',
}

export interface User {
  id: number;
  name: string;
  role: UserRole;
  avatar: string; 
  salary: number;
  employeeId: string;
  password?: string; // In a real app, this would be a secure hash, not plaintext.
}

export interface InventoryItem {
  id: string; // This is the unique serial number
  productId: string;
  status: 'available' | 'sold';
  cost: number;
  addedAt: Date;
  purchaseOrderId?: string;
  soldAt?: Date;
  warrantyEndDate?: Date;
  soldToCustomerId?: number;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  cost: number; // This is the *average* or *last* cost, used for new POs. Individual item cost is in InventoryItem.
  supplierId: number;
  image: string;
}

export interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string;
  tier: 'VIP' | 'Regular' | 'Walk-in';
  creditLimit: number;
  creditUsed: number;
  joinDate: Date;
}

export interface Supplier {
  id: number;
  name: string;
  contact: string;
}

export enum TransactionType {
  SALE = 'sale',
  RETURN = 'return',
  EXPENSE = 'expense',
}

export interface Transaction {
  id: number;
  type: TransactionType;
  items: { productId: string; serialNumber: string; price: number; originalPrice: number; }[];
  totalAmount: number;
  discount?: number; // Order-level discount percentage
  timestamp: Date;
  cashierId: number;
  customerId?: number;
  paymentMethod: 'Cash' | 'Credit' | 'Card' | 'Mobile Money';
  managerApprovalId?: number;
}

export interface Currency {
    code: 'MWK' | 'USD' | 'EUR' | 'GBP';
    name: string;
    symbol: string;
}

export enum PurchaseOrderStatus {
    PENDING = 'Pending',
    SHIPPED = 'Shipped',
    RECEIVED = 'Received',
    CANCELLED = 'Cancelled',
}

export interface PurchaseOrder {
    id: string;
    supplierId: number;
    items: { productId: string; quantity: number; cost: number }[];
    totalCost: number;
    orderDate: Date;
    expectedDeliveryDate: Date;
    status: PurchaseOrderStatus;
    requisitionId?: number;
}

export enum ExpenseCategory {
    SALARIES = 'Salaries',
    RENT = 'Rent',
    UTILITIES = 'Utilities',
    MARKETING = 'Marketing',
    SUPPLIES = 'Office Supplies',
    REPAIRS = 'Repairs & Maintenance',
    FUEL_TRANSPORTATION = 'Fuel & Transportation',
    WARRANTY_CLAIMS = 'Warranty Claims',
    DEPRECIATION = 'Depreciation',
    INTEREST = 'Interest',
    BANK_FEES = 'Bank & Loan Fees',
    INCOME_TAX = 'Income Tax',
    ASSET_PURCHASE = 'Asset Purchase',
    OTHER = 'Other',
}

export interface Expense {
    id: number;
    description: string;
    category: ExpenseCategory;
    amount: number;
    date: Date;
    recordedById: number;
    requisitionId?: number;
}

export enum LogAction {
  USER_ROLE_CHANGED = 'User Role Changed',
  USER_SALARY_CHANGED = 'User Salary Changed',
  USER_PASSWORD_CHANGED = 'User Password Changed',
  SALE_COMPLETED = 'Sale Completed',
  PRICE_OVERRIDE_IN_SALE = 'Price Override in Sale',
  PRODUCT_ADDED = 'Product Added',
  PRODUCT_PRICE_UPDATED = 'Product Price Updated',
  PRODUCT_PRICES_UPDATED_FROM_MARKUP = 'Product Prices Updated from Markup',
  CUSTOMER_ADDED = 'Customer Added',
  SUPPLIER_ADDED = 'Supplier Added',
  PO_CREATED = 'Purchase Order Created',
  PO_RECEIVED = 'Purchase Order Received',
  EXPENSE_LOGGED = 'Expense Logged',
  GENERAL_JOURNAL_ENTRY_CREATED = 'General Journal Entry Created',
  SETTINGS_CHANGED = 'System Settings Changed',
  PAYROLL_PROCESSED = 'Payroll Processed',
  REPAIR_LOGGED = 'Repair Logged',
  REPAIR_STATUS_CHANGED = 'Repair Status Changed',
  // New Actions
  REQUISITION_CREATED = 'Requisition Created',
  REQUISITION_STATUS_CHANGED = 'Requisition Status Changed',
  MARKETING_CAMPAIGN_CREATED = 'Marketing Campaign Created',
  SHIFT_SCHEDULED = 'Employee Shift Scheduled',
}

export interface AuditLog {
  id: number;
  timestamp: Date;
  userId: number; 
  userName: string;
  action: LogAction;
  details: string; 
}

export interface AppSettings {
  companyName: string;
  defaultCurrency: 'MWK' | 'USD' | 'EUR' | 'GBP';
  taxRate: number;
  incomeTaxRate: number;
  address: string;
  markupPercentage: number;
}

export enum RepairStatus {
    PENDING = 'Pending',
    IN_PROGRESS = 'In Progress',
    COMPLETED = 'Completed',
    CANCELLED = 'Cancelled',
    CLOSED = 'Closed',
}

export interface RepairJob {
    id: number;
    customerName: string;
    contactInfo: string;
    deviceDescription: string;
    issueDescription: string;
    assignedToId: number;
    status: RepairStatus;
    quote: number;
    createdById: number;
    createdAt: Date;
    completedAt?: Date;
}

export interface Budget {
    category: ExpenseCategory | 'Salaries';
    amount: number;
}

export enum NotificationType {
    LOW_STOCK = 'Low Stock',
    OUT_OF_STOCK = 'Out of Stock',
    PO_SHIPPED = 'PO Shipped',
    PO_RECEIVED = 'PO Received',
    PAYROLL_PROCESSED = 'Payroll Processed',
    PENDING_PO = 'Pending PO',
    REQUISITION_PENDING = 'Requisition Pending Approval',
    REQUISITION_APPROVED = 'Requisition Approved',
    REQUISITION_REJECTED = 'Requisition Rejected',
    CHAT_MESSAGE = 'Chat Message',
}

export interface Notification {
    id: number;
    type: NotificationType;
    message: string;
    timestamp: Date;
    isRead: boolean;
    relatedId?: string | number; // e.g., productId or po.id
    actorName?: string;
}

export interface SerializedCartItem {
    productId: string;
    serialNumber: string;
    finalPrice: number;
}

// Requisitions
export enum RequisitionType {
    INVENTORY = 'Inventory',
    EXPENSE = 'Expense',
    ASSET = 'Asset',
}

export enum RequisitionStatus {
    PENDING = 'Pending',
    APPROVED = 'Approved',
    REJECTED = 'Rejected',
    ORDERED = 'Ordered', // For inventory requisitions
    COMPLETED = 'Completed', // For expense requisitions
}

export interface RequisitionItem {
    description: string;
    quantity: number;
    estimatedCost: number;
    productId?: string; // For inventory
}

export interface Requisition {
    id: number;
    requesterId: number;
    type: RequisitionType;
    status: RequisitionStatus;
    items: RequisitionItem[];
    totalEstimatedCost: number;
    description: string;
    createdAt: Date;
    approverId?: number;
    approvedAt?: Date;
    rejectionReason?: string;
    relatedPOId?: string; // Link to Purchase Order if created
}

// Marketing
export enum MarketingCampaignStatus {
    PLANNING = 'Planning',
    ACTIVE = 'Active',
    COMPLETED = 'Completed',
    CANCELLED = 'Cancelled',
}

export interface MarketingCampaign {
    id: number;
    name: string;
    type: 'Social Media' | 'Email' | 'Local Ad' | 'Sponsorship';
    status: MarketingCampaignStatus;
    budget: number;
    actualSpend: number;
    startDate: Date;
    endDate: Date;
    description: string;
    createdById: number;
}

// Scheduling
export interface Shift {
    id: number;
    employeeId: number;
    start: Date;
    end: Date;
}

// Payroll
export interface PayrollRun {
    id: number;
    date: Date;
    totalAmount: number;
    employeeCount: number;
    processedById: number;
}

// --- Chat Module Types ---
export enum MessageStatus {
  SENT = 'sent',
  DELIVERED = 'delivered',
  READ = 'read',
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: number;
  text: string;
  timestamp: Date;
  status: MessageStatus;
  isEdited?: boolean;
  imageUrl?: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  participants: number[]; // array of user IDs
  name?: string; // for group chats
  creatorId?: number;
  createdAt: Date;
  // For UI optimization
  lastMessage?: {
    text: string;
    timestamp: Date;
    senderId: number;
  };
  unreadCounts: Record<number, number>; // { [userId]: count }
}

export interface DataSnapshot {
  products: Product[];
  inventoryItems: InventoryItem[];
  customers: Customer[];
  suppliers: Supplier[];
  transactions: Transaction[];
  purchaseOrders: PurchaseOrder[];
  users: User[];
  expenses: Expense[];
  auditLogs: AuditLog[];
  settings: AppSettings;
  repairJobs: RepairJob[];
  // Financial data
  accounts: Account[];
  ledger: LedgerEntry[];
  budgets: Budget[];
  notifications: Notification[];
  // New Modules
  requisitions: Requisition[];
  marketingCampaigns: MarketingCampaign[];
  shifts: Shift[];
  payrollRuns: PayrollRun[];
  // Chat
  conversations: Conversation[];
  messages: Message[];
}
