
import { Currency } from '../types';
import { EXCHANGE_RATES } from '../constants';

export const formatCurrency = (amount: number, currency: Currency) => {
  // All data is stored in MWK, so we convert from MWK to the target currency.
  const convertedAmount = amount / EXCHANGE_RATES[currency.code];

  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.code,
    // To avoid showing too many decimal places for converted values
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(convertedAmount);
};
