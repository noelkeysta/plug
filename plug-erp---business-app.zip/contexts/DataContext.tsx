import React, { createContext, useState, useContext, useMemo, useCallback } from 'react';
import { getMockData } from '../services/mockDataService';
import { DataSnapshot } from '../types';

interface DataContextType {
  data: DataSnapshot | null;
  refreshData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<DataSnapshot | null>(() => getMockData());

  const refreshData = useCallback(() => {
    setData(getMockData());
  }, []);

  const value = useMemo(() => ({
    data,
    refreshData,
  }), [data, refreshData]);

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};