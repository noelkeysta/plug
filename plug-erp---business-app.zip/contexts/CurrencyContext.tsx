import React, { createContext, useState, useContext, useMemo, useEffect } from 'react';
import { Currency } from '../types';
import { CURRENCIES } from '../constants';
import { useData } from './DataContext';

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  currencies: Currency[];
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { data } = useData();
  const initialCurrency = useMemo(() => {
      const initialSettings = data?.settings;
      return CURRENCIES.find(c => c.code === initialSettings?.defaultCurrency) || CURRENCIES[0];
  }, [data]);

  const [currency, setCurrency] = useState<Currency>(initialCurrency);

  useEffect(() => {
    setCurrency(initialCurrency);
  }, [initialCurrency]);

  const value = useMemo(() => ({
    currency,
    setCurrency,
    currencies: CURRENCIES,
  }), [currency]);

  return (
    <CurrencyContext.Provider value={value}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = (): CurrencyContextType => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};