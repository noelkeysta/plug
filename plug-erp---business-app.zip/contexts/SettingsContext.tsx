
import React, { createContext, useState, useContext, useMemo, useCallback, useEffect } from 'react';
import { AppSettings } from '../types';
import { updateSettings as updateSettingsService } from '../services/mockDataService';
import { useData } from './DataContext';

interface SettingsContextType {
  settings: AppSettings;
  updateSettings: (newSettings: AppSettings, performingUserId: number) => void;
  refreshSettings: () => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const defaultSettings: AppSettings = {
    companyName: 'Plug Play Tech',
    defaultCurrency: 'MWK',
    taxRate: 16.5,
    incomeTaxRate: 30,
    address: 'Blantyre, Malawi',
    markupPercentage: 50,
};

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { data, refreshData } = useData();
  const settings = data?.settings || defaultSettings;

  const updateSettings = useCallback((newSettings: AppSettings, performingUserId: number) => {
    updateSettingsService(newSettings, performingUserId);
    refreshData();
  }, [refreshData]);

  const value = useMemo(() => ({
    settings,
    updateSettings,
    refreshSettings: refreshData, // Just use the global refresh function
  }), [settings, updateSettings, refreshData]);

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
