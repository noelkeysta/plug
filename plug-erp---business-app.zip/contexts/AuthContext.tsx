import React, { createContext, useState, useContext, useMemo, useCallback } from 'react';
import { User } from '../types';
import { useData } from './DataContext';

interface AuthContextType {
  currentUser: User | null;
  users: User[];
  login: (employeeId: string, password: string) => Promise<boolean>;
  loginAs: (userId: number) => void;
  logout: () => void;
  refreshUsers: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { data, refreshData } = useData();
  const users = data?.users || [];

  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const login = useCallback(async (employeeId: string, password: string): Promise<boolean> => {
    const user = users.find(u => u.employeeId.toLowerCase() === employeeId.toLowerCase());
    // NOTE: This is a temporary, insecure password check for demonstration purposes.
    // In a real application, this would be a secure API call.
    if (user && password === 'password123') {
        setCurrentUser(user);
        return true;
    }
    return false;
  }, [users]);

  const loginAs = useCallback((userId: number) => {
    const user = users.find(u => u.id === userId);
    setCurrentUser(user || null);
  }, [users]);

  const logout = useCallback(() => {
    setCurrentUser(null);
  }, []);

  const refreshUsers = useCallback(() => {
    refreshData();
  }, [refreshData]);

  const value = useMemo(() => ({
    currentUser,
    users,
    login,
    loginAs,
    logout,
    refreshUsers,
  }), [currentUser, users, login, loginAs, logout, refreshUsers]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
