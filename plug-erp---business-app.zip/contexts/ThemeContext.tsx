
import React, { createContext, useState, useContext, useMemo } from 'react';

interface ThemeContextType {
  isDarkMode: boolean;
  toggleTheme: () => void;
  themeClasses: {
    main: string;
    card: string;
    sidebar: string;
    textGradient: string;
    kpiIconBg: string;
    kpiIconText: string;
    searchInput: string;
    statusBadge: string;
    progressBg: string;
    progressBar: string;
    button: string;
  };
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState(true);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  const themeClasses = useMemo(() => {
    return isDarkMode
      ? {
          main: 'bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white',
          card: 'bg-gradient-to-br from-slate-800/90 via-blue-900/30 to-slate-800/90 backdrop-blur-xl border border-amber-500/20 shadow-lg shadow-blue-500/10',
          sidebar: 'bg-gradient-to-b from-slate-900/95 via-blue-900/30 to-slate-900/95 backdrop-blur-xl border-r border-amber-500/20',
          textGradient: 'bg-gradient-to-r from-amber-400 to-blue-400 bg-clip-text text-transparent',
          kpiIconBg: 'bg-amber-500/20',
          kpiIconText: 'text-amber-400',
          searchInput: 'pl-12 pr-4 py-3 rounded-full w-72 border-none focus:outline-none focus:ring-2 focus:ring-amber-500/50 placeholder-gray-400 transition-all duration-300 hover:w-80 focus:w-80',
          statusBadge: 'bg-amber-500/20 text-amber-300',
          progressBg: 'bg-slate-700/30',
          progressBar: 'bg-gradient-to-r from-amber-500 to-blue-500',
          button: 'bg-gradient-to-r from-amber-500 to-blue-500 text-white'
        }
      : {
          main: 'bg-slate-100 text-slate-900',
          card: 'bg-white/80 backdrop-blur-xl border border-slate-200 shadow-lg shadow-slate-200/50',
          sidebar: 'bg-white/95 backdrop-blur-xl border-r border-slate-200/80',
          textGradient: 'bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent',
          kpiIconBg: 'bg-blue-500/10',
          kpiIconText: 'text-blue-600',
          searchInput: 'pl-12 pr-4 py-3 rounded-full w-72 border-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 placeholder-gray-500 transition-all duration-300 hover:w-80 focus:w-80',
          statusBadge: 'bg-blue-500/10 text-blue-700',
          progressBg: 'bg-slate-200',
          progressBar: 'bg-gradient-to-r from-blue-500 to-teal-500',
          button: 'bg-gradient-to-r from-blue-600 to-teal-600 text-white'
        };
  }, [isDarkMode]);

  return (
    <ThemeContext.Provider value={{ isDarkMode, toggleTheme, themeClasses }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
