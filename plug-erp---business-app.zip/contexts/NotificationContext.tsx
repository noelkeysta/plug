
import React, { createContext, useContext, useCallback, useMemo } from 'react';
import toast from 'react-hot-toast';
import { useData } from './DataContext';
import { updateNotifications as updateNotificationsService } from '../services/mockDataService';

interface NotificationContextType {
  notifySuccess: (message: string) => void;
  notifyError: (message: string) => void;
  notifyInfo: (message: string) => void;
  markAsRead: (id: number) => void;
  markAllAsRead: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { data, refreshData } = useData();

  const markAsRead = useCallback((id: number) => {
    const notifications = data?.notifications || [];
    const updatedNotifications = notifications.map(n => n.id === id ? { ...n, isRead: true } : n);
    updateNotificationsService(updatedNotifications);
    refreshData();
  }, [data, refreshData]);

  const markAllAsRead = useCallback(() => {
    const notifications = data?.notifications || [];
    const unreadExist = notifications.some(n => !n.isRead);
    if(unreadExist) {
        const updatedNotifications = notifications.map(n => ({ ...n, isRead: true }));
        updateNotificationsService(updatedNotifications);
        refreshData();
    }
  }, [data, refreshData]);

  const notifySuccess = useCallback((message: string) => toast.success(message), []);
  const notifyError = useCallback((message: string) => toast.error(message), []);
  const notifyInfo = useCallback((message: string) => toast(message), []);

  const value = useMemo(() => ({
    notifySuccess,
    notifyError,
    notifyInfo,
    markAsRead,
    markAllAsRead
  }), [notifySuccess, notifyError, notifyInfo, markAsRead, markAllAsRead]);

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifier = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifier must be used within a NotificationProvider');
  }
  return context;
};
