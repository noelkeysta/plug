
import React, { createContext, useState, useContext, useMemo, useCallback, useEffect } from 'react';
import { useAuth } from './AuthContext';

// Define the shape of KPI settings
interface KpiSettings {
  order: string[];
  visibility: Record<string, boolean>;
}

interface DashboardSettingsContextType {
  kpiSettings: KpiSettings;
  setKpiOrder: (newOrder: string[]) => void;
  toggleKpiVisibility: (kpiId: string) => void;
  availableKpis: { id: string, title: string }[];
}

const DashboardSettingsContext = createContext<DashboardSettingsContextType | undefined>(undefined);

// Define all possible KPIs here
const ALL_KPIS = [
    { id: 'netRevenue', title: 'Net Revenue' },
    { id: 'grossProfitMargin', title: 'Gross Profit Margin' },
    { id: 'totalOrders', title: 'Total Orders' },
    { id: 'aov', title: 'Average Order Value' },
    { id: 'inventoryValue', title: 'Inventory Value' },
];

const DEFAULT_KPI_SETTINGS: KpiSettings = {
    order: ALL_KPIS.map(kpi => kpi.id),
    visibility: ALL_KPIS.reduce((acc, kpi) => ({ ...acc, [kpi.id]: true }), {}),
};

const getStorageKey = (userId: number) => `PLUG_ERP_DASHBOARD_SETTINGS_${userId}`;

export const DashboardSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { currentUser } = useAuth();
    const [kpiSettings, setKpiSettings] = useState<KpiSettings>(DEFAULT_KPI_SETTINGS);

    // Load settings from localStorage when user changes
    useEffect(() => {
        if (currentUser) {
            try {
                const savedSettings = localStorage.getItem(getStorageKey(currentUser.id));
                if (savedSettings) {
                    const parsed = JSON.parse(savedSettings);
                    if (parsed.order && parsed.visibility) {
                        const newVisibility = { ...DEFAULT_KPI_SETTINGS.visibility, ...parsed.visibility };
                        const currentKpiIds = new Set(ALL_KPIS.map(k => k.id));
                        const savedOrder = parsed.order.filter((id: string) => currentKpiIds.has(id));
                        const newKpis = ALL_KPIS.filter(kpi => !savedOrder.includes(kpi.id)).map(kpi => kpi.id);
                        
                        setKpiSettings({
                            order: [...savedOrder, ...newKpis],
                            visibility: newVisibility,
                        });
                    } else {
                       setKpiSettings(DEFAULT_KPI_SETTINGS);
                    }
                } else {
                    setKpiSettings(DEFAULT_KPI_SETTINGS);
                }
            } catch (error) {
                console.error("Failed to load dashboard settings:", error);
                setKpiSettings(DEFAULT_KPI_SETTINGS);
            }
        }
    }, [currentUser]);

    const saveSettings = useCallback((settings: KpiSettings) => {
        if (currentUser) {
            try {
                localStorage.setItem(getStorageKey(currentUser.id), JSON.stringify(settings));
            } catch (error) {
                console.error("Failed to save dashboard settings:", error);
            }
        }
    }, [currentUser]);

    const setKpiOrder = useCallback((newOrder: string[]) => {
        setKpiSettings(currentSettings => {
            const updatedSettings = { ...currentSettings, order: newOrder };
            saveSettings(updatedSettings);
            return updatedSettings;
        });
    }, [saveSettings]);

    const toggleKpiVisibility = useCallback((kpiId: string) => {
        setKpiSettings(currentSettings => {
            const newVisibility = { ...currentSettings.visibility, [kpiId]: !currentSettings.visibility[kpiId] };
            const updatedSettings = { ...currentSettings, visibility: newVisibility };
            saveSettings(updatedSettings);
            return updatedSettings;
        });
    }, [saveSettings]);
    
    const value = useMemo(() => ({
        kpiSettings,
        setKpiOrder,
        toggleKpiVisibility,
        availableKpis: ALL_KPIS,
    }), [kpiSettings, setKpiOrder, toggleKpiVisibility]);
    
    return (
        <DashboardSettingsContext.Provider value={value}>
            {children}
        </DashboardSettingsContext.Provider>
    );
};

export const useDashboardSettings = (): DashboardSettingsContextType => {
  const context = useContext(DashboardSettingsContext);
  if (!context) {
    throw new Error('useDashboardSettings must be used within a DashboardSettingsProvider');
  }
  return context;
};
